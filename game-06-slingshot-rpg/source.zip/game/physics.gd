class_name BallPhysics
extends RefCounted
## 跳ねる玉の物理（自前計算）。ゲーム本編・予測線の描画・自動プレイの先読みは、
## すべてこの tick() / simulate_to_rest() / predict_path() だけを通す（別計算を作らない）。
##
## 円と線分（壁）の連続衝突は、部屋の壁が軸に平行な矩形境界であることを利用し、
## 平面（無限直線）との衝突時刻を解く形に単純化している（結果は円と線分の衝突と同じ）。
## 円と円（敵・はね板・穴）は二次方程式で衝突時刻を求める。
## 仲間への接触は移動後の中心間距離で判定し、連続衝突の探索には含めない。

const FIXED_DT := 1.0 / 60.0
const FRICTION := 900.0       # px/s^2 の減速
const STOP_SPEED := 16.0      # これを下回ったら停止扱い
const MAX_SPEED := 1400.0
const MIN_SPEED := 260.0
const HOLE_PULL := 2600.0     # px/s^2 の吸い込み加速
const HOLE_CATCH := 16.0      # 穴の中心からこの距離まで来たら捕獲

# ---------------------------------------------------------------- 幾何の基礎

static func reflect(v: Vector2, n: Vector2) -> Vector2:
	return v - 2.0 * v.dot(n) * n

## 平面（壁）の連続衝突時刻。normal は部屋の内側を向く単位ベクトル。t は remaining 時間に対する割合[0,1]。
static func plane_toi(p0: Vector2, d: Vector2, normal: Vector2, point_on_line: Vector2, radius: float) -> float:
	var dist0: float = (p0 - point_on_line).dot(normal) - radius
	var closing: float = d.dot(normal)
	if closing >= -1e-9:
		return -1.0
	if dist0 <= 1e-6:
		return 0.0
	var t: float = -dist0 / closing
	if t < 0.0 or t > 1.0:
		return -1.0
	return t

## 円と円の連続衝突時刻（p0 が d だけ動く点、center は静止円、combined_radius は半径の和）。
static func circle_toi(p0: Vector2, d: Vector2, center: Vector2, combined_radius: float) -> float:
	var f: Vector2 = p0 - center
	var a: float = d.dot(d)
	var b: float = 2.0 * f.dot(d)
	var c: float = f.dot(f) - combined_radius * combined_radius
	if c <= 0.0:
		return 0.0
	if a <= 1e-12:
		return -1.0
	var disc: float = b * b - 4.0 * a * c
	if disc < 0.0:
		return -1.0
	var sq: float = sqrt(disc)
	var t: float = (-b - sq) / (2.0 * a)
	if t < 0.0 or t > 1.0:
		return -1.0
	return t

static func out_of_bounds(pos: Vector2, room: Dictionary, radius: float) -> bool:
	var b: Dictionary = room.bounds
	var margin := 6.0
	return pos.x < b.l - radius - margin or pos.x > b.r + radius + margin \
		or pos.y < b.t - radius - margin or pos.y > b.b + radius + margin

# ---------------------------------------------------------------- 1ティック分の移動

## ball: {pos, vel, radius, pierce}
## room: {walls:[{normal,point}], holes:[{pos,radius}], pads:[{pos,radius,boost,id}], bounds:{l,r,t,b}}
## enemies / allies: Array[Dictionary]（読み取りのみ。alive/pos/radius/idx/hero_idx を見る）
## hit_state: この1発の飛行中だけ有効な「すでに当てた相手」の記録（呼び出し側が1発ごとに新しく用意する）
static func tick(ball: Dictionary, room: Dictionary, enemies: Array, allies: Array, dt: float, hit_state: Dictionary) -> Dictionary:
	var pos: Vector2 = ball.pos
	var vel: Vector2 = ball.vel
	var radius: float = ball.radius
	var events: Array = []
	var stopped := false

	for h in room.get("holes", []):
		var to_hole: Vector2 = h.pos - pos
		var dist: float = to_hole.length()
		if dist < h.radius and dist > 1.0:
			vel += to_hole.normalized() * HOLE_PULL * dt

	var remaining := dt
	var iterations := 0
	while remaining > 1e-7 and iterations < 8:
		iterations += 1
		var d: Vector2 = vel * remaining
		if d.length() < 1e-9:
			break
		var best_t := 1.0
		var best_kind := ""
		var best_data = null
		for w in room.get("walls", []):
			var t: float = plane_toi(pos, d, w.normal, w.point, radius)
			if t >= 0.0 and t < best_t:
				best_t = t; best_kind = "wall"; best_data = w
		for h in room.get("holes", []):
			var t2: float = circle_toi(pos, d, h.pos, HOLE_CATCH + radius)
			if t2 >= 0.0 and t2 < best_t:
				best_t = t2; best_kind = "hole"; best_data = h
		for p in room.get("pads", []):
			var pkey: String = "pad_%d" % int(p.id)
			var t3: float = circle_toi(pos, d, p.pos, p.radius + radius)
			if t3 >= 0.0 and t3 < best_t and not hit_state.get(pkey + "_cool", false):
				best_t = t3; best_kind = "pad"; best_data = p
		for e in enemies:
			if not e.alive:
				continue
			var ekey: String = "enemy_%d" % int(e.idx)
			if ball.pierce and hit_state.get(ekey, false):
				continue
			var t4: float = circle_toi(pos, d, e.pos, e.radius + radius)
			if t4 >= 0.0 and t4 < best_t:
				best_t = t4; best_kind = "enemy"; best_data = e
		if best_kind == "":
			pos += d
			remaining = 0.0
			break
		pos += vel * (remaining * best_t)
		remaining -= remaining * best_t
		match best_kind:
			"wall":
				vel = reflect(vel, best_data.normal)
				events.append({"type": "wall", "pos": pos})
			"hole":
				pos = best_data.pos
				vel = Vector2.ZERO
				stopped = true
				events.append({"type": "hole", "pos": pos})
			"pad":
				var n: Vector2 = pos - best_data.pos
				if n.length() < 0.5:
					n = -vel.normalized()
				n = n.normalized()
				vel = reflect(vel, n) * float(best_data.boost)
				hit_state["pad_%d_cool" % int(best_data.id)] = true
				events.append({"type": "pad", "id": int(best_data.id), "pos": pos})
			"enemy":
				var ekey2: String = "enemy_%d" % int(best_data.idx)
				events.append({"type": "enemy", "idx": int(best_data.idx), "pos": pos, "speed": vel.length()})
				if ball.pierce:
					hit_state[ekey2] = true
					pos += vel.normalized() * 0.75
				else:
					var n2: Vector2 = (pos - best_data.pos)
					if n2.length() < 0.5:
						n2 = -vel.normalized()
					vel = reflect(vel, n2.normalized())
		if stopped:
			break

	# なかま技の発動はティック末尾の距離判定。仲間は反射せず、衝突時刻も解かない。
	for a in allies:
		var akey: String = "ally_%d" % int(a.hero_idx)
		if hit_state.get(akey, false):
			continue
		if pos.distance_to(a.pos) <= a.radius + radius:
			hit_state[akey] = true
			events.append({"type": "ally", "hero_idx": int(a.hero_idx), "pos": a.pos})

	if not stopped:
		var speed: float = vel.length()
		if speed > 0.0:
			var newspeed: float = max(0.0, speed - FRICTION * dt)
			if newspeed <= STOP_SPEED:
				vel = Vector2.ZERO
				stopped = true
			else:
				vel = vel.normalized() * newspeed

	return {
		"ball": {"pos": pos, "vel": vel, "radius": radius, "pierce": ball.pierce},
		"events": events,
		"stopped": stopped,
	}

# ---------------------------------------------------------------- 発射1回分の解決

## 発射してから止まるまで tick() を繰り返す。実行と自動プレイの先読みの両方から呼ぶ。
## damage_fn(enemy: Dictionary, speed: float) -> float、nakama_fn(hero_idx:int, enemies:Array) -> Array[{idx,damage}]
static func simulate_to_rest(start_ball: Dictionary, room: Dictionary, enemies_in: Array, allies_in: Array,
		max_ticks: int, damage_fn: Callable, nakama_fn: Callable, dt: float = FIXED_DT) -> Dictionary:
	var ball: Dictionary = start_ball.duplicate(true)
	var enemies: Array = []
	for e in enemies_in:
		enemies.append(e.duplicate(true))
	var allies: Array = []
	for a in allies_in:
		allies.append(a.duplicate(true))
	var hit_state := {}
	var events: Array = []
	var path: Array = [ball.pos]
	var escaped := false
	var ticks_used := 0
	for i in range(max_ticks):
		var r: Dictionary = tick(ball, room, enemies, allies, dt, hit_state)
		ball = r.ball
		ticks_used += 1
		for ev in r.events:
			if ev.type == "enemy":
				for e in enemies:
					if int(e.idx) == int(ev.idx) and e.alive:
						var dmg: float = damage_fn.call(e, float(ev.speed))
						e.hp = max(0.0, float(e.hp) - dmg)
						if e.hp <= 0.0:
							e.alive = false
						ev = ev.duplicate(true)
						ev["damage"] = dmg
						ev["enemy_alive"] = e.alive
						break
			elif ev.type == "ally":
				var combo: Array = nakama_fn.call(int(ev.hero_idx), enemies)
				ev = ev.duplicate(true)
				ev["combo"] = combo
			events.append(ev)
		path.append(ball.pos)
		if out_of_bounds(ball.pos, room, ball.radius):
			escaped = true
			break
		if r.stopped:
			break
	return {
		"ball": ball, "enemies": enemies, "events": events, "path": path,
		"escaped": escaped, "ticks": ticks_used,
	}

## 予測線用: ダメージ処理をせず、最初の衝突＋はね返り1回分だけ経路を作る（本番と同じ tick() を使う）。
static func predict_path(start_ball: Dictionary, room: Dictionary, enemies_in: Array, allies_in: Array,
		max_ticks: int, damage_fn: Callable = Callable(), nakama_fn: Callable = Callable(), dt: float = FIXED_DT) -> Dictionary:
	var ball: Dictionary = start_ball.duplicate(true)
	var enemies: Array = []
	for e in enemies_in:
		enemies.append(e.duplicate(true))
	var hit_state := {}
	var path: Array = [ball.pos]
	var hits: Array = []
	var first_hit_pos = null
	var bounces := 0
	for i in range(max_ticks):
		var r: Dictionary = tick(ball, room, enemies, allies_in, dt, hit_state)
		ball = r.ball
		path.append(ball.pos)
		for ev in r.events:
			if ev.type == "enemy" and damage_fn.is_valid():
				for e in enemies:
					if int(e.idx) == int(ev.idx) and e.alive:
						e.hp = max(0.0, float(e.hp) - float(damage_fn.call(e, float(ev.speed))))
						if e.hp <= 0.0:
							e.alive = false
						break
			elif ev.type == "ally" and nakama_fn.is_valid():
				nakama_fn.call(int(ev.hero_idx), enemies)
			if ev.type == "wall" or ev.type == "enemy" or ev.type == "pad" or ev.type == "hole":
				hits.append(ev)
				if first_hit_pos == null:
					first_hit_pos = ev.pos
				bounces += 1
		if out_of_bounds(ball.pos, room, ball.radius):
			break
		if r.stopped:
			break
		if bounces >= 2:
			break
	return {"path": path, "first_hit_pos": first_hit_pos, "hits": hits}
