extends Node2D
## ハネダマ冒険団 — 本体。BallPhysics(physics.gd) / Rooms(rooms.gd) はどちらも class_name で
## グローバル登録されているので直接参照する。

const ErrorCounter := preload("res://error_counter.gd")
const GAME_FONT := preload("res://fonts/MPLUSRounded1c-Bold-subset.ttf")
const ARENA_ART := preload("res://art/arena.png")
const BOSS_ARENA_ART := preload("res://art/arena_boss.png")
const HERO_ART := [preload("res://art/heroes_00.png"), preload("res://art/heroes_01.png"), preload("res://art/heroes_02.png"), preload("res://art/heroes_03.png")]
const ENEMY_ART := [
	[preload("res://art/enemies_00.png")], [preload("res://art/enemies_01.png")],
	[preload("res://art/enemies_02.png"), preload("res://art/enemies_03.png")],
	[preload("res://art/enemies_04.png")],
	[preload("res://art/enemies_05.png"), preload("res://art/enemies_06.png"), preload("res://art/enemies_07.png")],
]
const ELEMENT_ENEMY_ART := [preload("res://art/enemies_03.png"), preload("res://art/enemies_00.png"), preload("res://art/enemies_01.png"), preload("res://art/enemies_02.png")]
const PAD_ART := preload("res://art/devices_00.png")
const HOLE_ART := preload("res://art/devices_01.png")
const HUD_ART := preload("res://art/ui_fx_00.png")
const PANEL_ART := preload("res://art/ui_fx_01.png")
const BUTTON_ART := preload("res://art/ui_fx_02.png")
const ENEMY_BAR_ART := preload("res://art/ui_fx_03.png")
const GAUGE_ART := preload("res://art/ui_fx_04.png")
const HIT_ART := preload("res://art/ui_fx_15.png")
const WALL_ART := preload("res://art/ui_fx_06.png")
const PAD_FX_ART := preload("res://art/ui_fx_07.png")
const HOLE_FX_ART := preload("res://art/ui_fx_08.png")
const COMBO_ART := preload("res://art/ui_fx_15.png")
const DEFEAT_ART := preload("res://art/ui_fx_11.png")
const AREA_ART := preload("res://art/ui_fx_12.png")
const LINE_ART := preload("res://art/ui_fx_13.png")
const TARGET_ART := preload("res://art/ui_fx_14.png")
const AIM_ART := preload("res://art/ui_fx_15.png")

const BASE := Vector2(720, 1280)
const BEST_PATH := "user://best.json"
const BEST_TURNS_VERSION := 3
const HERO_HP_MAX := 220.0
const ROOM_CLEAR_HEAL := 40.0
const BASE_DAMAGE := 14.0
const TAME_MULT := 2.5
const NAKAMA_BASE := 11.0
const TAME_INTERVAL := 3
const ENEMY_ATTACK_DAMAGE := 10.0
const DRAG_MAX := 260.0
const CANCEL_RADIUS := 16.0
const MAX_FLIGHT_SECONDS := 6.0
const MAX_TURNS_SAFETY := 600

const FACE_Y := 1195.0
const FACE_R := 50.0
const FACE_X := [105.0, 275.0, 445.0, 615.0]

enum State { TITLE, PLAY, RESULT }

var state := State.TITLE
var logger: ErrorCounter
var rng := RandomNumberGenerator.new()
var fx_rng := RandomNumberGenerator.new()

# ---- CLI ----
var autoplay := false
var strategy := "greedy"
var demo_mode := false
var demo_wait := 0.0
var demo_aim_elapsed := 0.0
var demo_aim_duration := 0.0
var planned_shot := {}
var physics_test := false
var test_shots := 1000
var seed_val := 1
var timescale := 1.0

# ---- ノード ----
var world: Node2D
var ui_layer: CanvasLayer
var title_panel: Control
var result_panel: Control
var room_label: Label
var turn_label: Label
var hp_label: Label
var result_text: Label
var result_best: Label
var title_best: Label

# ---- 部屋・キャラの状態 ----
var rooms: Array = []
var room_idx := 0
var enemies: Array = []
var hero_balls: Array = []
var hero_hp := HERO_HP_MAX
var turn_hero := 0
var shot_this_round := [false, false, false, false]
var turn_count := 0
var tame_cd: Array = [TAME_INTERVAL, TAME_INTERVAL, TAME_INTERVAL, TAME_INTERVAL]
var tame_ready: Array = [false, false, false, false]
var tame_selected := false

var active_ball = null
var active_hit_state := {}
var flight_time := 0.0
var predicted_first_hit = null
var predicted_path: Array = []
var predicted_sample := 0
var first_hit_recorded = null
var shot_hero_idx := -1
var shot_tame_active := false

var aiming := false
var press_pos := Vector2.ZERO
var drag_pos := Vector2.ZERO

var fx_list: Array = []
var shake := 0.0

# ---- 統計 ----
var stat_shots := 0
var stat_tame_shots := 0
var stat_hits := 0
var stat_combos := 0
var stat_max_damage := 0
var stat_escaped := 0
var stat_predict_error := 0.0
var stat_predict_path_error := 0.0
var stat_predict_path_samples := 0
var stat_predict_path_unmatched := 0
var stat_flight_seconds := 0.0
var stat_decision_seconds := 0.0
var stat_room_turns := [0, 0, 0, 0, 0]
var stat_attacks := [0, 0, 0]
var attack_sequence := 0
var stat_room_reached := 0
var stat_cleared := false

var best := {"turns": 0, "room": 0, "turns_version": BEST_TURNS_VERSION}
var new_record := false

# ---------------------------------------------------------------- 起動

func _ready() -> void:
	logger = ErrorCounter.new()
	OS.add_logger(logger)
	fx_rng.randomize()
	_parse_args()
	if OS.has_feature("web"):
		var query := String(JavaScriptBridge.eval("window.location.search", true))
		demo_mode = query.trim_prefix("?").split("&").has("demo=1")
	rng.seed = seed_val
	rooms = Rooms.build()
	if physics_test:
		call_deferred("_run_physics_test")
		return
	_load_best()
	_build_world()
	_build_ui()
	get_viewport().size_changed.connect(_layout)
	_layout()
	if autoplay:
		_start_game()
	else:
		_show_title()

func _parse_args() -> void:
	var args := OS.get_cmdline_user_args()
	args.append_array(OS.get_cmdline_args())
	for a in args:
		if a == "--autoplay":
			autoplay = true
		elif a == "--physics-test":
			physics_test = true
		elif a.begins_with("--shots="):
			test_shots = int(a.get_slice("=", 1))
		elif a.begins_with("--seed="):
			seed_val = int(a.get_slice("=", 1))
		elif a.begins_with("--timescale="):
			timescale = float(a.get_slice("=", 1))
		elif a.begins_with("--strategy="):
			strategy = a.get_slice("=", 1)
		elif a == "--inject-error":
			push_error.call_deferred("inject-error: 検証用のわざとのエラー")

func _load_best() -> void:
	if FileAccess.file_exists(BEST_PATH):
		var f := FileAccess.open(BEST_PATH, FileAccess.READ)
		var parsed = JSON.parse_string(f.get_as_text())
		if typeof(parsed) == TYPE_DICTIONARY:
			best = parsed
			if not best.has("turns_version"):
				if int(best.get("room", 0)) > 0:
					best["turns"] = int(best.get("turns", 0)) + 1
				best["turns_version"] = 2
			if int(best.get("turns_version", 0)) < BEST_TURNS_VERSION:
				# 旧版は各部屋1段階。3段階版とターン数を競わせず、旧記録を別欄に保存する。
				if int(best.get("room", 0)) > 0:
					best["old_rule_turns"] = int(best.get("turns", 0))
				best["turns"] = 0
				best["room"] = 0
				best["turns_version"] = BEST_TURNS_VERSION
				_save_best()

func _save_best() -> void:
	var f := FileAccess.open(BEST_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(best))

# ---------------------------------------------------------------- 組み立て

func _build_world() -> void:
	world = Node2D.new()
	world.name = "World"
	add_child(world)
	world.draw.connect(_draw_world)

	room_label = _label(30, Color.WHITE)
	room_label.position = Vector2(24, 30)
	world.add_child(room_label)
	turn_label = _label(26, Color(0.85, 0.87, 1.0))
	turn_label.position = Vector2(24, 74)
	world.add_child(turn_label)
	hp_label = _label(26, Color(1.0, 0.75, 0.75))
	hp_label.position = Vector2(24, 104)
	world.add_child(hp_label)

func _label(size: int, col: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_override("font", GAME_FONT)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0.05, 0.05, 0.1))
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(300, 84)
	b.add_theme_font_override("font", GAME_FONT)
	b.add_theme_font_size_override("font_size", 30)
	var sb := StyleBoxTexture.new()
	sb.texture = BUTTON_ART
	sb.texture_margin_left = 30
	sb.texture_margin_right = 30
	sb.texture_margin_top = 25
	sb.texture_margin_bottom = 25
	b.add_theme_stylebox_override("normal", sb)
	var sb2 := sb.duplicate() as StyleBoxTexture
	sb2.modulate_color = Color(1.2, 1.2, 1.2)
	b.add_theme_stylebox_override("hover", sb2)
	b.add_theme_stylebox_override("pressed", sb2)
	b.add_theme_color_override("font_color", Color.WHITE)
	return b

func _overlay() -> Control:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color(0.05, 0.05, 0.12, 0.86)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(bg)
	var plate := NinePatchRect.new()
	plate.texture = PANEL_ART
	plate.patch_margin_left = 38
	plate.patch_margin_right = 38
	plate.patch_margin_top = 38
	plate.patch_margin_bottom = 38
	plate.set_anchors_preset(Control.PRESET_CENTER)
	plate.position = Vector2(-320, -300)
	plate.size = Vector2(640, 600)
	plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(plate)
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.position -= Vector2(300, 260)
	box.custom_minimum_size = Vector2(600, 1)
	box.add_theme_constant_override("separation", 22)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	root.add_child(box)
	root.set_meta("box", box)
	return root

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	ui_layer.layer = 10
	add_child(ui_layer)

	title_panel = _overlay()
	var tb := title_panel.get_meta("box") as VBoxContainer
	var t1 := _label(52, Color("ffd27a"))
	t1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t1.text = "ハネダマ冒険団"
	tb.add_child(t1)
	var t2 := _label(26, Color.WHITE)
	t2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t2.text = "玉を引っ張って放ち、はね返して敵を倒す\n5つの部屋を抜けて、さいごの敵を倒そう"
	tb.add_child(t2)
	var t3 := _label(26, Color(0.82, 0.85, 1.0))
	t3.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t3.text = "玉か顔をタップ → 次に放つ仲間を選ぶ\n画面を逆になぞってはなす → 発射\n出番の顔を再タップ → ためわざ"
	tb.add_child(t3)
	title_best = _label(26, Color("fff0b3"))
	title_best.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tb.add_child(title_best)
	var start_btn := _button("はじめる")
	start_btn.pressed.connect(_start_game)
	var start_wrap := CenterContainer.new()
	start_wrap.add_child(start_btn)
	tb.add_child(start_wrap)
	title_panel.visible = false
	ui_layer.add_child(title_panel)

	result_panel = _overlay()
	var rb := result_panel.get_meta("box") as VBoxContainer
	result_text = _label(30, Color("ffd27a"))
	result_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rb.add_child(result_text)
	result_best = _label(26, Color(0.85, 0.9, 1.0))
	result_best.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rb.add_child(result_best)
	var retry_btn := _button("もういちど")
	retry_btn.pressed.connect(_start_game)
	var retry_wrap := CenterContainer.new()
	retry_wrap.add_child(retry_btn)
	rb.add_child(retry_wrap)
	result_panel.visible = false
	ui_layer.add_child(result_panel)

func _layout() -> void:
	if world == null:
		return
	var vp := get_viewport().get_visible_rect().size
	world.position = ((vp - BASE) / 2.0).floor()
	world.queue_redraw()

# ---------------------------------------------------------------- 状態遷移

func _current_room() -> Dictionary:
	return rooms[room_idx]

func _clone_enemies(idx: int) -> Array:
	var out: Array = []
	for e in rooms[idx].enemies:
		out.append(e.duplicate(true))
	return out

func _reset_hero_balls() -> void:
	hero_balls = []
	var starts: Array = Rooms.hero_start_positions()
	for i in range(4):
		hero_balls.append({"hero_idx": i, "pos": starts[i], "radius": Rooms.BALL_RADIUS})

func _show_title() -> void:
	state = State.TITLE
	title_best.text = _best_text()
	demo_wait = 0.0
	title_panel.visible = true
	result_panel.visible = false
	_refresh_web_state()

func _show_result() -> void:
	demo_wait = 0.0
	title_panel.visible = false
	result_panel.visible = true
	if stat_cleared:
		result_text.text = "クリア！おめでとう\n%d部屋 / %dターン" % [rooms.size() / Rooms.WAVES_PER_ROOM, turn_count]
	else:
		result_text.text = "全滅…また挑戦しよう\n到達: %d部屋 / %dターン" % [stat_room_reached, turn_count]
	var extra := "最大ダメージ %d　なかま技 %d回" % [stat_max_damage, stat_combos]
	if best.get("room", 0) > 0:
		extra += "\n" + _best_text()
		if new_record:
			extra += "\n新記録！"
	else:
		extra += "\n" + _best_text()
	result_best.text = extra
	_refresh_web_state()

func _best_text() -> String:
	if int(best.get("room", 0)) > 0:
		return "自己ベスト: %d部屋クリア（%dターン）" % [int(best.room), int(best.turns)]
	if int(best.get("old_rule_turns", 0)) > 0:
		return "自己ベスト: 新ルールはまだなし（旧%dターン）" % int(best.old_rule_turns)
	return "自己ベスト: まだなし"

func _start_game() -> void:
	state = State.PLAY
	title_panel.visible = false
	result_panel.visible = false
	room_idx = 0
	enemies = _clone_enemies(0)
	_reset_hero_balls()
	hero_hp = HERO_HP_MAX
	turn_hero = 0
	shot_this_round = [false, false, false, false]
	turn_count = 0
	tame_cd = [TAME_INTERVAL, TAME_INTERVAL, TAME_INTERVAL, TAME_INTERVAL]
	tame_ready = [false, false, false, false]
	tame_selected = false
	active_ball = null
	aiming = false
	press_pos = Vector2.ZERO
	drag_pos = Vector2.ZERO
	fx_list.clear()
	shake = 0.0
	stat_shots = 0
	stat_tame_shots = 0
	stat_hits = 0
	stat_combos = 0
	stat_max_damage = 0
	stat_escaped = 0
	stat_predict_error = 0.0
	stat_predict_path_error = 0.0
	stat_predict_path_samples = 0
	stat_predict_path_unmatched = 0
	stat_flight_seconds = 0.0
	stat_decision_seconds = 0.0
	stat_room_turns = [0, 0, 0, 0, 0]
	demo_aim_elapsed = 0.0
	planned_shot = {}
	stat_attacks = [0, 0, 0]
	attack_sequence = 0
	stat_room_reached = 0
	stat_cleared = false
	new_record = false
	_refresh_web_state()

func _clear_room() -> void:
	room_idx += 1
	if room_idx >= rooms.size():
		_finish_run(true)
		return
	if room_idx % Rooms.WAVES_PER_ROOM == 0:
		hero_hp = min(HERO_HP_MAX, hero_hp + ROOM_CLEAR_HEAL)
	enemies = _clone_enemies(room_idx)
	var starts: Array = Rooms.hero_start_positions()
	for i in range(4):
		hero_balls[i].pos = starts[i]
	tame_selected = false

func _finish_run(cleared: bool) -> void:
	state = State.RESULT
	stat_cleared = cleared
	stat_room_reached = int(ceil(float(room_idx) / Rooms.WAVES_PER_ROOM)) if cleared else int(ceil(float(room_idx + 1) / Rooms.WAVES_PER_ROOM))
	new_record = false
	if cleared:
		if int(best.get("room", 0)) == 0 or turn_count < int(best.get("turns", turn_count)):
			best = {"turns": turn_count, "room": rooms.size() / Rooms.WAVES_PER_ROOM, "turns_version": BEST_TURNS_VERSION}
			new_record = true
			_save_best()
	_refresh_web_state()
	if autoplay or physics_test:
		_output_autoplay_json()
		get_tree().quit(0 if logger.get_errors() == 0 else 1)
	else:
		_show_result()

# ---------------------------------------------------------------- 入力（ポインターのみ）

func _input(event: InputEvent) -> void:
	if autoplay or physics_test or demo_mode:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		var p: Vector2 = world.get_local_mouse_position()
		if event.pressed:
			_pointer_down(p)
		else:
			_pointer_up(p)
	elif event is InputEventMouseMotion and aiming:
		drag_pos = world.get_local_mouse_position()

func _pointer_down(p: Vector2) -> void:
	if state == State.PLAY and active_ball == null:
		aiming = true
		press_pos = p
		drag_pos = p

func _pointer_up(p: Vector2) -> void:
	if not aiming:
		return
	aiming = false
	drag_pos = p
	var drag_vec: Vector2 = drag_pos - press_pos
	if drag_vec.length() >= CANCEL_RADIUS:
		var speed: float = lerpf(BallPhysics.MIN_SPEED, BallPhysics.MAX_SPEED, clamp(drag_vec.length() / DRAG_MAX, 0.0, 1.0))
		var dir: Vector2 = (-drag_vec).normalized()
		_fire(turn_hero, dir * speed, tame_selected)
	else:
		_try_select_hero(press_pos)

func _try_select_hero(p: Vector2) -> bool:
	for i in range(4):
		var c := Vector2(FACE_X[i], FACE_Y)
		if p.distance_to(c) <= FACE_R or p.distance_to(hero_balls[i].pos) <= Rooms.BALL_RADIUS + 12.0:
			if not shot_this_round[i]:
				if i == turn_hero and tame_ready[i]:
					tame_selected = not tame_selected
				else:
					turn_hero = i
					tame_selected = false
			return true
	return false

# ---------------------------------------------------------------- 発射・飛行

func _allies_excluding(hero_idx: int) -> Array:
	var out: Array = []
	for hb in hero_balls:
		if int(hb.hero_idx) != hero_idx:
			out.append(hb)
	return out

func _fire(hero_idx: int, vel: Vector2, use_tame: bool) -> void:
	shot_hero_idx = hero_idx
	shot_tame_active = use_tame
	if use_tame:
		tame_ready[hero_idx] = false
		tame_cd[hero_idx] = TAME_INTERVAL
	tame_selected = false
	var pierce: bool = Rooms.HEROES[hero_idx].kind == "pierce"
	var ball := {"pos": hero_balls[hero_idx].pos, "vel": vel, "radius": Rooms.BALL_RADIUS, "pierce": pierce}
	var allies := _allies_excluding(hero_idx)
	var pred := BallPhysics.predict_path(ball, _current_room(), enemies, allies, 240, Callable(self, "_damage_fn"), Callable(self, "_nakama_fn"))
	predicted_first_hit = pred.first_hit_pos
	predicted_path = pred.path
	predicted_sample = 0
	first_hit_recorded = null
	active_ball = ball
	active_hit_state = {}
	flight_time = 0.0
	stat_shots += 1
	if use_tame:
		stat_tame_shots += 1

func _flight_tick(dt: float) -> void:
	flight_time += dt
	stat_flight_seconds += dt
	var allies := _allies_excluding(shot_hero_idx)
	var r: Dictionary = BallPhysics.tick(active_ball, _current_room(), enemies, allies, dt, active_hit_state)
	active_ball = r.ball
	predicted_sample += 1
	if predicted_sample < predicted_path.size():
		stat_predict_path_error = max(stat_predict_path_error, float(active_ball.pos.distance_to(predicted_path[predicted_sample])))
		stat_predict_path_samples += 1
	var stopped: bool = r.stopped
	for ev in r.events:
		if first_hit_recorded == null and (ev.type == "wall" or ev.type == "enemy" or ev.type == "pad" or ev.type == "hole"):
			first_hit_recorded = ev.pos
		match ev.type:
			"enemy":
				_resolve_enemy_event(ev)
			"wall":
				_spawn_wall_fx(ev.pos)
			"pad":
				_spawn_pad_fx(ev.pos)
			"hole":
				_spawn_hole_fx(ev.pos)
			"ally":
				_resolve_ally_event(ev)
	if BallPhysics.out_of_bounds(active_ball.pos, _current_room(), active_ball.radius):
		stat_escaped += 1
		push_warning("玉が部屋の外に出た: pos=%s" % [active_ball.pos])
		var b: Dictionary = _current_room().bounds
		active_ball.pos.x = clamp(active_ball.pos.x, b.l + 2.0, b.r - 2.0)
		active_ball.pos.y = clamp(active_ball.pos.y, b.t + 2.0, b.b - 2.0)
		active_ball.vel = Vector2.ZERO
		stopped = true
	if flight_time >= MAX_FLIGHT_SECONDS:
		stopped = true
	if stopped:
		_end_shot()

func _resolve_enemy_event(ev: Dictionary) -> void:
	for e in enemies:
		if int(e.idx) == int(ev.idx) and e.alive:
			var dmg: float = _damage_fn(e, float(ev.speed))
			e.hp = max(0.0, float(e.hp) - dmg)
			stat_hits += 1
			stat_max_damage = max(stat_max_damage, int(dmg))
			_spawn_hit_fx(ev.pos, dmg)
			if e.hp <= 0.0:
				e.alive = false
				_spawn_defeat_fx(e.pos)
			break

func _resolve_ally_event(ev: Dictionary) -> void:
	var combo: Array = _nakama_fn(int(ev.hero_idx), enemies)
	if combo.size() > 0:
		stat_combos += 1
	for c in combo:
		stat_max_damage = max(stat_max_damage, int(c.damage))
		if c.died:
			for e in enemies:
				if int(e.idx) == int(c.idx):
					_spawn_defeat_fx(e.pos)
					break
	_spawn_combo_fx(ev.pos, int(ev.hero_idx))

## ダメージ計算（本番実行と自動プレイの先読みで共有する唯一の関数）。
func _damage_fn(enemy: Dictionary, speed: float) -> float:
	var ratio: float = clamp(speed / BallPhysics.MAX_SPEED, 0.35, 1.0)
	var mult := 1.0
	if Rooms.strong_against(int(Rooms.HEROES[shot_hero_idx].element), int(enemy.element)):
		mult = 1.5
	var tame := TAME_MULT if shot_tame_active else 1.0
	return roundf(BASE_DAMAGE * ratio * mult * tame)

## なかま技（触れた仲間の属性で、いまいる敵全員に一撃ずつ）。
func _nakama_fn(hero_idx: int, enemies_arr: Array) -> Array:
	var out: Array = []
	var atk_elem: int = int(Rooms.HEROES[hero_idx].element)
	for e in enemies_arr:
		if not e.alive:
			continue
		var mult := 1.5 if Rooms.strong_against(atk_elem, int(e.element)) else 1.0
		var dmg: float = roundf(NAKAMA_BASE * mult)
		e.hp = max(0.0, float(e.hp) - dmg)
		var died := false
		if e.hp <= 0.0:
			e.alive = false
			died = true
		out.append({"idx": int(e.idx), "damage": dmg, "died": died})
	return out

func _end_shot() -> void:
	hero_balls[shot_hero_idx].pos = active_ball.pos
	stat_predict_path_unmatched += max(0, predicted_path.size() - 1 - predicted_sample)
	if predicted_first_hit != null and first_hit_recorded != null:
		stat_predict_error = max(stat_predict_error, float(predicted_first_hit.distance_to(first_hit_recorded)))
	active_ball = null
	shot_this_round[shot_hero_idx] = true
	turn_count += 1
	stat_room_turns[int(_current_room().room_number) - 1] += 1
	if not shot_tame_active:
		tame_cd[shot_hero_idx] -= 1
		if tame_cd[shot_hero_idx] <= 0:
			tame_cd[shot_hero_idx] = 0
			tame_ready[shot_hero_idx] = true
	_tick_enemy_counters()
	_refresh_web_state()
	if hero_hp <= 0.0:
		_finish_run(false)
		return
	var room_clear := true
	for e in enemies:
		if e.alive:
			room_clear = false
			break
	if room_clear:
		_clear_room()
		if state != State.PLAY:
			return
	if not shot_this_round.has(false):
		shot_this_round = [false, false, false, false]
	for step in range(1, 5):
		var candidate: int = (shot_hero_idx + step) % 4
		if not shot_this_round[candidate]:
			turn_hero = candidate
			break
	if turn_count > MAX_TURNS_SAFETY:
		_finish_run(false)

func _tick_enemy_counters() -> void:
	for e in enemies:
		if not e.alive or bool(e.no_counter):
			continue
		e.counter = int(e.counter) - 1
		if int(e.counter) <= 0:
			e.counter = e.counter_max
			_enemy_attack(e)

func _enemy_attack(e: Dictionary) -> void:
	var pattern: int = attack_sequence % 3
	attack_sequence += 1
	stat_attacks[pattern] += 1
	var hits := 0
	var target := Vector2.ZERO
	match pattern:
		0: # 範囲: 敵を中心に半径480px。複数の玉に当たる。
			for hb in hero_balls:
				if hb.pos.distance_to(e.pos) <= 480.0:
					hits += 1
		1: # 一直線: 敵のx座標を中心とする幅92pxの縦帯。
			for hb in hero_balls:
				if absf(hb.pos.x - e.pos.x) <= 46.0:
					hits += 1
		2: # 近くの玉: 距離が最小の玉だけを狙う。
			var nearest := INF
			for hb in hero_balls:
				var distance: float = hb.pos.distance_to(e.pos)
				if distance < nearest:
					nearest = distance
					target = hb.pos
			hits = 1
	var dmg: float = hits * ENEMY_ATTACK_DAMAGE if pattern != 2 else ENEMY_ATTACK_DAMAGE * 1.5
	hero_hp = max(0.0, hero_hp - dmg)
	_spawn_enemy_attack_fx(e, pattern, target)

# ---------------------------------------------------------------- 自動プレイ

func _plan_shot(style: String) -> Dictionary:
	if active_ball != null or state != State.PLAY:
		return {}
	var hero_idx := turn_hero
	if style != "greedy":
		var target: Dictionary = {}
		for e in enemies:
			if e.alive and (target.is_empty() or float(e.hp) > float(target.hp)):
				target = e
		for offset in range(4):
			var candidate: int = (turn_hero + offset) % 4
			if not shot_this_round[candidate] and not target.is_empty() and Rooms.strong_against(int(Rooms.HEROES[candidate].element), int(target.element)):
				hero_idx = candidate
				break
	turn_hero = hero_idx
	var use_tame: bool = tame_ready[hero_idx]
	shot_hero_idx = hero_idx
	shot_tame_active = use_tame
	var room := _current_room()
	var allies := _allies_excluding(hero_idx)
	var start_pos: Vector2 = hero_balls[hero_idx].pos
	var pierce: bool = Rooms.HEROES[hero_idx].kind == "pierce"
	var best_dmg := -1.0
	var best_vel := Vector2.RIGHT * BallPhysics.MAX_SPEED
	var steps := 72
	for s in range(steps):
		var ang: float = TAU * float(s) / float(steps)
		var vel: Vector2 = Vector2.RIGHT.rotated(ang) * BallPhysics.MAX_SPEED
		var ball := {"pos": start_pos, "vel": vel, "radius": Rooms.BALL_RADIUS, "pierce": pierce}
		var res: Dictionary = BallPhysics.simulate_to_rest(ball, room, enemies, allies, 400, Callable(self, "_damage_fn"), Callable(self, "_nakama_fn"))
		var total := 0.0
		for ev in res.events:
			if ev.has("damage"):
				total += float(ev.damage)
			if ev.has("combo"):
				for c in ev.combo:
					total += float(c.damage)
		if total > best_dmg:
			best_dmg = total
			best_vel = vel
	if style != "greedy":
		var deviation := 0.08 if style == "careful" else 0.16
		best_vel = best_vel.rotated(rng.randf_range(-deviation, deviation))
		if style == "human" and stat_shots % 8 == 5:
			best_vel = best_vel.rotated(0.45 if (stat_shots / 8) % 2 == 0 else -0.45)
	return {"hero": hero_idx, "vel": best_vel, "tame": use_tame}

func _autoplay_maybe_fire() -> void:
	var shot: Dictionary = _plan_shot("greedy")
	if not shot.is_empty():
		_fire(int(shot.hero), shot.vel, bool(shot.tame))

func _demo_aim_tick() -> void:
	if planned_shot.is_empty():
		planned_shot = _plan_shot("human" if demo_mode else strategy)
		if planned_shot.is_empty():
			return
		demo_aim_elapsed = 0.0
		demo_aim_duration = [1.5, 1.2, 0.9, 1.4][stat_shots % 4]
		tame_selected = bool(planned_shot.tame)
		press_pos = hero_balls[int(planned_shot.hero)].pos
		drag_pos = press_pos
		aiming = true
	demo_aim_elapsed += BallPhysics.FIXED_DT
	stat_decision_seconds += BallPhysics.FIXED_DT
	var drag_length: float = DRAG_MAX * clampf((planned_shot.vel.length() - BallPhysics.MIN_SPEED) / (BallPhysics.MAX_SPEED - BallPhysics.MIN_SPEED), 0.0, 1.0)
	drag_pos = press_pos - planned_shot.vel.normalized() * drag_length * minf(1.0, demo_aim_elapsed / 0.35)
	if demo_aim_elapsed >= demo_aim_duration:
		aiming = false
		_fire(int(planned_shot.hero), planned_shot.vel, bool(planned_shot.tame))
		planned_shot = {}

# ---------------------------------------------------------------- フレーム更新

func _process(delta: float) -> void:
	if demo_mode and (state == State.TITLE or state == State.RESULT):
		demo_wait += delta
		if demo_wait >= (2.0 if state == State.TITLE else 4.0):
			_start_game()
	_age_fx(delta)
	if shake > 0.0:
		shake = max(0.0, shake - delta * 6.0)
	_refresh_hud()
	_refresh_web_state()
	if world:
		world.queue_redraw()

func _physics_process(_delta: float) -> void:
	if physics_test:
		return
	if state != State.PLAY:
		return
	var n := 1
	if autoplay:
		n = int(max(1.0, timescale))
	for _i in range(n):
		if demo_mode or (autoplay and strategy != "greedy"):
			if active_ball == null:
				_demo_aim_tick()
		elif autoplay:
			_autoplay_maybe_fire()
		if active_ball != null:
			_flight_tick(BallPhysics.FIXED_DT)
		if state != State.PLAY:
			break

func _refresh_hud() -> void:
	if room_label == null or room_idx >= rooms.size():
		return
	var room: Dictionary = _current_room()
	room_label.text = String(room.name)
	turn_label.text = "ターン %d" % turn_count
	hp_label.text = "たいりょく %d / %d" % [int(hero_hp), int(HERO_HP_MAX)]

func _refresh_web_state() -> void:
	if not OS.has_feature("web"):
		return
	var st := {
		"state": ["title", "play", "result"][state],
		"room": room_idx + 1,
		"hp": hero_hp,
		"turn": turn_count,
		"aiming": aiming,
		"selected_hero": turn_hero,
		"shot_this_round": shot_this_round,
		"cleared": stat_cleared,
		"result_visible": state == State.RESULT,
		"errors": logger.get_errors(),
	}
	JavaScriptBridge.eval("window.__hanedama = %s;" % JSON.stringify(st), true)

# ---------------------------------------------------------------- 演出

func _spawn_hit_fx(pos: Vector2, dmg: float) -> void:
	fx_list.append({"kind": "hit", "pos": pos, "age": 0.0, "life": 0.5, "dmg": int(dmg)})
	_trim_fx()

func _spawn_wall_fx(pos: Vector2) -> void:
	fx_list.append({"kind": "wall", "pos": pos, "age": 0.0, "life": 0.25})
	_trim_fx()

func _spawn_pad_fx(pos: Vector2) -> void:
	fx_list.append({"kind": "pad", "pos": pos, "age": 0.0, "life": 0.3})
	_trim_fx()

func _spawn_hole_fx(pos: Vector2) -> void:
	fx_list.append({"kind": "hole", "pos": pos, "age": 0.0, "life": 0.4})
	_trim_fx()

func _spawn_combo_fx(pos: Vector2, hero_idx: int) -> void:
	fx_list.append({"kind": "combo", "pos": pos, "age": 0.0, "life": 0.6, "hero": hero_idx})
	_trim_fx()

func _spawn_enemy_attack_fx(e: Dictionary, pattern: int, target: Vector2) -> void:
	fx_list.append({"kind": "attack", "pos": e.pos, "pattern": pattern, "target": target, "age": 0.0, "life": 0.8})
	shake = 8.0
	_trim_fx()

func _spawn_defeat_fx(pos: Vector2) -> void:
	fx_list.append({"kind": "defeat", "pos": pos, "age": 0.0, "life": 0.7})
	shake = 12.0
	_trim_fx()

func _trim_fx() -> void:
	while fx_list.size() > 60:
		fx_list.pop_front()

func _age_fx(delta: float) -> void:
	var i := fx_list.size() - 1
	while i >= 0:
		fx_list[i].age = float(fx_list[i].age) + delta
		if float(fx_list[i].age) >= float(fx_list[i].life):
			fx_list.remove_at(i)
		i -= 1

# ---------------------------------------------------------------- 描画

func _draw_art(texture: Texture2D, center: Vector2, size: Vector2, tint := Color.WHITE) -> void:
	world.draw_texture_rect(texture, Rect2(center - size * 0.5, size), false, tint)

func _draw_cover_background(texture: Texture2D) -> void:
	# stretch=expand が広げた部分も含め、viewport の四隅を world の canvas 座標へ戻す。
	var viewport_rect := get_viewport().get_visible_rect()
	var inverse := world.get_global_transform_with_canvas().affine_inverse()
	var corner_a: Vector2 = inverse * viewport_rect.position
	var corner_b: Vector2 = inverse * viewport_rect.end
	var visible := Rect2(corner_a, corner_b - corner_a).abs()
	# 生成絵の枠は原画内の x=78..643 / y=240..1045。中央の床だけで余白を覆い、
	# 原画本体を1.2倍で重ねて枠を物理境界 x=20..700 / y=150..1110 に合わせる。
	var floor_region := Rect2(Vector2(260, 530), Vector2(200, 200))
	var source := floor_region.size
	var scale_factor: float = maxf(visible.size.x / source.x, visible.size.y / source.y)
	var cover_size := source * scale_factor
	world.draw_texture_rect_region(texture, Rect2(visible.get_center() - cover_size * 0.5, cover_size), floor_region)
	world.draw_texture_rect(texture, Rect2(Vector2(-74, -138), Vector2(864, 1536)), false)

func _draw_world() -> void:
	if rooms.is_empty() or room_idx >= rooms.size():
		return
	var room: Dictionary = _current_room()
	var off := Vector2.ZERO
	if shake > 0.01:
		off = Vector2(fx_rng.randf_range(-1.0, 1.0), fx_rng.randf_range(-1.0, 1.0)) * shake

	var b: Dictionary = room.bounds
	_draw_cover_background(BOSS_ARENA_ART if int(room.room_number) == 5 else ARENA_ART)
	# 背景の拡大・中央切り抜き後も、当たり判定の境界を視認できるようにする。
	world.draw_rect(Rect2(Vector2(b.l, b.t) + off, Vector2(b.r - b.l, b.b - b.t)), Color(0.48, 0.72, 1.0, 0.75), false, 4.0)
	world.draw_texture_rect(HUD_ART, Rect2(Vector2(8, 8), Vector2(570, 138)), false)

	for h in room.holes:
		_draw_art(HOLE_ART, h.pos + off, Vector2.ONE * h.radius * 2.0)
	for p in room.pads:
		_draw_art(PAD_ART, p.pos + off, Vector2.ONE * p.radius * 2.0)

	for e in enemies:
		if not e.alive:
			continue
		var enemy_sprites: Array = ENEMY_ART[int(room.art_room)]
		var enemy_art: Texture2D = ELEMENT_ENEMY_ART[int(e.art_element)] if e.has("art_element") else enemy_sprites[mini(int(e.idx), enemy_sprites.size() - 1)]
		_draw_art(enemy_art, e.pos + off, Vector2.ONE * e.radius * 2.0)
		var w: float = e.radius * 2.0
		var hp_ratio: float = float(e.hp) / float(e.max_hp)
		world.draw_texture_rect(ENEMY_BAR_ART, Rect2(e.pos + off + Vector2(-w / 2.0 - 4.0, -e.radius - 27.0), Vector2(w + 8.0, 18.0)), false)
		world.draw_rect(Rect2(e.pos + off + Vector2(-w / 2.0, -e.radius - 22.0), Vector2(w * clamp(hp_ratio, 0.0, 1.0), 10.0)), Color(1, 0.3, 0.3))
		if not bool(e.no_counter):
			world.draw_string(GAME_FONT, e.pos + off + Vector2(-8.0, -e.radius - 35.0), str(int(e.counter)), HORIZONTAL_ALIGNMENT_CENTER, -1, 26, Color.WHITE)

	for hb in hero_balls:
		var is_active: bool = int(hb.hero_idx) == turn_hero and active_ball == null
		_draw_art(HERO_ART[int(hb.hero_idx)], hb.pos + off, Vector2.ONE * hb.radius * 2.0)
		if is_active:
			world.draw_arc(hb.pos + off, hb.radius + 4.0, 0, TAU, 28, Color.WHITE, 3.0)

	if active_ball != null:
		_draw_art(HERO_ART[shot_hero_idx], active_ball.pos + off, Vector2.ONE * active_ball.radius * 2.0)
		world.draw_arc(active_ball.pos + off, active_ball.radius + 3.0, 0, TAU, 24, Color.WHITE, 2.0)

	_draw_fx(off)

	if aiming:
		_draw_prediction(off)

	_draw_face_icons(off)

func _draw_prediction(off: Vector2) -> void:
	var drag_vec: Vector2 = drag_pos - press_pos
	if drag_vec.length() < CANCEL_RADIUS:
		return
	var speed: float = lerpf(BallPhysics.MIN_SPEED, BallPhysics.MAX_SPEED, clamp(drag_vec.length() / DRAG_MAX, 0.0, 1.0))
	var dir: Vector2 = (-drag_vec).normalized()
	var vel: Vector2 = dir * speed
	var start_pos: Vector2 = hero_balls[turn_hero].pos
	var pierce: bool = Rooms.HEROES[turn_hero].kind == "pierce"
	var ball := {"pos": start_pos, "vel": vel, "radius": Rooms.BALL_RADIUS, "pierce": pierce}
	var allies := _allies_excluding(turn_hero)
	var previous_hero := shot_hero_idx
	var previous_tame := shot_tame_active
	shot_hero_idx = turn_hero
	shot_tame_active = tame_selected
	var res: Dictionary = BallPhysics.predict_path(ball, _current_room(), enemies, allies, 240, Callable(self, "_damage_fn"), Callable(self, "_nakama_fn"))
	shot_hero_idx = previous_hero
	shot_tame_active = previous_tame
	var pts := PackedVector2Array()
	for pt in res.path:
		pts.append(pt + off)
	if pts.size() >= 2:
		world.draw_polyline(pts, Color(1, 1, 1, 0.85), 3.0, true)
	if res.first_hit_pos != null:
		_draw_art(AIM_ART, res.first_hit_pos + off, Vector2.ONE * 26.0)
	var bar_w: float = 200.0 * clamp(drag_vec.length() / DRAG_MAX, 0.0, 1.0)
	world.draw_texture_rect(GAUGE_ART, Rect2(start_pos + off + Vector2(-104.0, 40.0), Vector2(208.0, 22.0)), false)
	world.draw_rect(Rect2(start_pos + off + Vector2(-100.0, 44.0), Vector2(bar_w, 14.0)), Color(1, 0.8, 0.3))

func _draw_face_icons(off: Vector2) -> void:
	for i in range(4):
		var c: Vector2 = Vector2(FACE_X[i], FACE_Y) + off
		var tint := Color.WHITE if i == turn_hero else Color(0.74, 0.78, 0.85)
		_draw_art(HERO_ART[i], c, Vector2.ONE * FACE_R * 2.0, tint)
		if i == turn_hero and active_ball == null:
			world.draw_arc(c, FACE_R + 5.0, 0, TAU, 28, Color.WHITE, 3.0)
		if bool(tame_ready[i]):
			world.draw_arc(c, FACE_R + 12.0, 0, TAU, 24, Color(1, 0.95, 0.5, 0.9), 4.0)
			if i == turn_hero and tame_selected:
				world.draw_arc(c, FACE_R + 18.0, 0, TAU, 24, Color(1, 0.3, 0.3, 0.9), 3.0)
		else:
			world.draw_string(GAME_FONT, c + Vector2(-6.0, FACE_R + 30.0), str(int(tame_cd[i])), HORIZONTAL_ALIGNMENT_CENTER, -1, 26, Color.WHITE)
		var hp_ratio: float = clamp(hero_hp / HERO_HP_MAX, 0.0, 1.0)
		world.draw_texture_rect(GAUGE_ART, Rect2(c + Vector2(-FACE_R - 4.0, FACE_R), Vector2(FACE_R * 2.0 + 8.0, 14.0)), false)
		world.draw_rect(Rect2(c + Vector2(-FACE_R, FACE_R + 4.0), Vector2(FACE_R * 2.0 * hp_ratio, 6.0)), Color(0.4, 1.0, 0.5))

func _draw_fx(off: Vector2) -> void:
	for fx in fx_list:
		var k: float = clamp(float(fx.age) / float(fx.life), 0.0, 1.0)
		var pos: Vector2 = fx.pos + off
		match String(fx.kind):
			"hit":
				_draw_art(HIT_ART, pos, Vector2.ONE * (42.0 + 26.0 * k), Color(1, 1, 1, 1.0 - k))
				world.draw_arc(pos, 14.0 + 22.0 * k, 0, TAU, 16, Color(1, 1, 0.4, (1.0 - k) * 0.9), 3.0)
				world.draw_string(GAME_FONT, pos + Vector2(-10.0, -20.0 - 30.0 * k), str(int(fx.dmg)), HORIZONTAL_ALIGNMENT_CENTER, -1, 26, Color(1, 1, 0.6, 1.0 - k))
			"wall":
				_draw_art(WALL_ART, pos, Vector2.ONE * (24.0 + 16.0 * k), Color(1, 1, 1, 1.0 - k))
				world.draw_arc(pos, 8.0 + 10.0 * k, 0, TAU, 12, Color(0.8, 0.9, 1.0, (1.0 - k) * 0.8), 2.0)
			"pad":
				_draw_art(PAD_FX_ART, pos, Vector2.ONE * (32.0 + 22.0 * k), Color(1, 1, 1, 1.0 - k))
				world.draw_arc(pos, 10.0 + 16.0 * k, 0, TAU, 14, Color(1, 0.8, 0.3, (1.0 - k) * 0.9), 3.0)
			"hole":
				_draw_art(HOLE_FX_ART, pos, Vector2.ONE * (35.0 + 25.0 * k), Color(1, 1, 1, 1.0 - k))
				world.draw_arc(pos, 6.0 + 30.0 * k, 0, TAU, 20, Color(0.5, 0.4, 0.9, (1.0 - k) * 0.8), 3.0)
			"combo":
				_draw_art(COMBO_ART, pos, Vector2.ONE * (62.0 + 38.0 * k), Color(1, 1, 1, 1.0 - k))
				world.draw_arc(pos, 18.0 + 40.0 * k, 0, TAU, 24, Color(1.0, 0.95, 0.6, (1.0 - k)), 5.0)
				world.draw_arc(pos, 8.0 + 20.0 * k, 0, TAU, 24, Color(1, 1, 1, (1.0 - k) * 0.8), 3.0)
			"attack":
				match int(fx.pattern):
					0:
						_draw_art(AREA_ART, pos, Vector2.ONE * (50.0 + 60.0 * k), Color(1, 1, 1, 1.0 - k))
						world.draw_arc(pos, 480.0 * k, 0, TAU, 64, Color(1, 0.35, 0.2, 1.0 - k), 8.0)
					1:
						_draw_art(LINE_ART, pos, Vector2(54.0, 92.0 + 46.0 * k), Color(1, 1, 1, 1.0 - k))
						world.draw_rect(Rect2(Vector2(pos.x - 46.0, Rooms.ROOM_T), Vector2(92.0, Rooms.ROOM_B - Rooms.ROOM_T)), Color(1, 0.25, 0.5, (1.0 - k) * 0.4))
					2:
						_draw_art(TARGET_ART, fx.target + off, Vector2.ONE * (50.0 + 22.0 * k), Color(1, 1, 1, 1.0 - k))
						world.draw_line(pos, fx.target + off, Color(0.5, 0.9, 1.0, 1.0 - k), 10.0)
						world.draw_arc(fx.target + off, 24.0 + 18.0 * k, 0, TAU, 24, Color(0.5, 0.9, 1.0, 1.0 - k), 5.0)
			"defeat":
				_draw_art(DEFEAT_ART, pos, Vector2.ONE * (72.0 + 30.0 * k), Color(1, 1, 1, 1.0 - k))
				for j in range(10):
					var a := TAU * float(j) / 10.0
					var d := 10.0 + 60.0 * k
					world.draw_circle(pos + Vector2(cos(a), sin(a)) * d, 5.0 * (1.0 - k) + 1.0, Color(1, 0.9, 0.5, 1.0 - k))

# ---------------------------------------------------------------- physics-test

func _damage_fn_test(_enemy: Dictionary, _speed: float) -> float:
	return 0.0

func _nakama_fn_test(_hero_idx: int, _enemies: Array) -> Array:
	return []

func _run_physics_test() -> void:
	rng.seed = seed_val
	var max_err := 0.0
	var max_path_err := 0.0
	var path_samples := 0
	var path_unmatched := 0
	var escaped := 0
	var starts: Array = Rooms.hero_start_positions()
	for i in range(test_shots):
		var room_i: int = i % rooms.size()
		var room: Dictionary = rooms[room_i]
		var enemies_snapshot := _clone_enemies(room_i)
		var start_pos: Vector2 = starts[i % 4]
		var angle: float
		var speed: float
		if i == 0:
			angle = 0.35
			speed = BallPhysics.MAX_SPEED
		else:
			angle = rng.randf_range(0.0, TAU)
			speed = rng.randf_range(BallPhysics.MIN_SPEED, BallPhysics.MAX_SPEED)
		var vel: Vector2 = Vector2.RIGHT.rotated(angle) * speed
		var ball := {"pos": start_pos, "vel": vel, "radius": Rooms.BALL_RADIUS, "pierce": (i % 2 == 0)}
		var pred: Dictionary = BallPhysics.predict_path(ball, room, enemies_snapshot, [], 240)
		var res: Dictionary = BallPhysics.simulate_to_rest(ball, room, enemies_snapshot, [], 600, Callable(self, "_damage_fn_test"), Callable(self, "_nakama_fn_test"))
		for sample in range(1, min(pred.path.size(), res.path.size())):
			max_path_err = max(max_path_err, float(pred.path[sample].distance_to(res.path[sample])))
			path_samples += 1
		path_unmatched += max(0, pred.path.size() - res.path.size())
		if bool(res.escaped):
			escaped += 1
		if pred.first_hit_pos != null:
			var first_real = null
			for ev in res.events:
				if ev.type == "wall" or ev.type == "enemy" or ev.type == "pad" or ev.type == "hole":
					first_real = ev.pos
					break
			if first_real != null:
				max_err = max(max_err, float(pred.first_hit_pos.distance_to(first_real)))
	var out := {"escaped_balls": escaped, "predict_error_px": snappedf(max_err, 0.001), "predict_path_error_px": snappedf(max_path_err, 0.001), "predict_path_samples": path_samples, "predict_path_unmatched": path_unmatched}
	print(JSON.stringify(out))
	get_tree().quit(0 if logger.get_errors() == 0 else 1)

func _output_autoplay_json() -> void:
	var out := {
		"turns": turn_count,
		"shots": stat_shots,
		"tame_shots": stat_tame_shots,
		"hits": stat_hits,
		"combos": stat_combos,
		"max_damage": stat_max_damage,
		"room_reached": stat_room_reached,
		"cleared": stat_cleared,
		"escaped_balls": stat_escaped,
		"predict_error_px": snappedf(stat_predict_error, 0.001),
		"predict_path_error_px": snappedf(stat_predict_path_error, 0.001),
		"predict_path_samples": stat_predict_path_samples,
		"predict_path_unmatched": stat_predict_path_unmatched,
		"flight_seconds": snappedf(stat_flight_seconds, 0.001),
		"decision_seconds": snappedf(stat_decision_seconds, 0.001),
		"estimated_play_seconds": snappedf(stat_flight_seconds + stat_decision_seconds, 0.001),
		"room_turns": stat_room_turns,
		"strategy": strategy,
		"attack_counts": {"area": stat_attacks[0], "line": stat_attacks[1], "nearest": stat_attacks[2]},
		"errors": logger.get_errors(),
	}
	print(JSON.stringify(out))
