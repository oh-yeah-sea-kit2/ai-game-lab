class_name Rooms
extends RefCounted
## 部屋（闘技場）とキャラクター・敵のデータ。数値はすべてここに集める。

const ROOM_L := 20.0
const ROOM_R := 700.0
const ROOM_T := 150.0
const ROOM_B := 1110.0
const BALL_RADIUS := 24.0
const WAVES_PER_ROOM := 3

enum Element { FIRE, WATER, WIND, LIGHT }
const ELEMENT_NAMES := ["火", "水", "風", "光"]
const ELEMENT_COLORS := [Color("ff6b4a"), Color("4ab8ff"), Color("6bffb0"), Color("fff27a")]

## element が advantage_over(element) に 1.5 倍で効く（火→水→風→光→火の一方通行）。
static func strong_against(attacker: int, defender: int) -> bool:
	return (attacker + 1) % 4 == defender

const HEROES := [
	{"name": "火のころん", "element": Element.FIRE, "kind": "bounce", "technique": "ころんばくはつ"},
	{"name": "水のしずく丸", "element": Element.WATER, "kind": "pierce", "technique": "しずくついせき弾"},
	{"name": "風のくるり", "element": Element.WIND, "kind": "bounce", "technique": "くるりビーム"},
	{"name": "光のまるみ", "element": Element.LIGHT, "kind": "pierce", "technique": "まるみばくはつ"},
]

const HERO_START_X := [160.0, 320.0, 400.0, 560.0]
const HERO_START_Y := 1060.0

static func make_walls() -> Array:
	return [
		{"normal": Vector2(1, 0), "point": Vector2(ROOM_L, 0)},
		{"normal": Vector2(-1, 0), "point": Vector2(ROOM_R, 0)},
		{"normal": Vector2(0, 1), "point": Vector2(0, ROOM_T)},
		{"normal": Vector2(0, -1), "point": Vector2(0, ROOM_B)},
	]

static func bounds() -> Dictionary:
	return {"l": ROOM_L, "r": ROOM_R, "t": ROOM_T, "b": ROOM_B}

static func hero_start_positions() -> Array:
	var out: Array = []
	for x in HERO_START_X:
		out.append(Vector2(x, HERO_START_Y))
	return out

## 各部屋の定義。room.enemies の要素は {pos, radius, hp, max_hp, element, counter_max, no_counter, idx, name}
static func build() -> Array:
	var rooms: Array = []

	rooms.append({
		"name": "1: みずうみのほこら",
		"walls": make_walls(), "bounds": bounds(), "holes": [], "pads": [],
		"enemies": [
			_enemy(0, Vector2(360, 470), 52, 55, Element.WATER, 3, false, "みずたまりぬし"),
		],
	})

	rooms.append({
		"name": "2: かぜのかいだん",
		"walls": make_walls(), "bounds": bounds(),
		"holes": [],
		"pads": [_pad(0, Vector2(540, 760), 34, 1.6)],
		"enemies": [
			_enemy(0, Vector2(340, 480), 56, 78, Element.WIND, 3, false, "つむじおに"),
		],
	})

	rooms.append({
		"name": "3: ひかりのかいだん",
		"walls": make_walls(), "bounds": bounds(),
		"holes": [_hole(0, Vector2(360, 900), 44)],
		"pads": [],
		"enemies": [
			_enemy(0, Vector2(230, 470), 46, 48, Element.LIGHT, 4, false, "ひかりごま(左)"),
			_enemy(1, Vector2(470, 470), 46, 48, Element.FIRE, 4, false, "ひかりごま(右)"),
		],
	})

	rooms.append({
		"name": "4: ほのおのやかた",
		"walls": make_walls(), "bounds": bounds(),
		"holes": [],
		"pads": [_pad(0, Vector2(150, 760), 32, 1.7), _pad(1, Vector2(570, 760), 32, 1.7)],
		"enemies": [
			_enemy(0, Vector2(360, 460), 62, 118, Element.FIRE, 3, false, "ほのおもんばん"),
		],
	})

	rooms.append({
		"name": "5: さいごのひろま",
		"walls": make_walls(), "bounds": bounds(),
		"holes": [_hole(0, Vector2(360, 960), 40)],
		"pads": [],
		"enemies": [
			_enemy(0, Vector2(360, 420), 82, 260, Element.LIGHT, 4, false, "だいまおうコロス"),
			_enemy(1, Vector2(190, 640), 40, 42, Element.WATER, 99, true, "てさき(左)"),
			_enemy(2, Vector2(530, 640), 40, 42, Element.WIND, 99, true, "てさき(右)"),
		],
	})

	# 各部屋を三段階にする。後半は射線を遮る装置と複数属性の敵が増える。
	# 元の5配置は第1段階として残し、部屋ごとの絵もそのまま使う。
	var stages: Array = []
	for room_number in range(rooms.size()):
		for wave in range(WAVES_PER_ROOM):
			var stage: Dictionary = rooms[room_number].duplicate(true)
			stage["room_number"] = room_number + 1
			stage["wave"] = wave + 1
			stage["art_room"] = room_number
			stage["name"] = "%d-%d: %s" % [room_number + 1, wave + 1, String(stage.name).get_slice(": ", 1)]
			if wave > 0:
				stage = _make_later_wave(stage, room_number, wave)
			stages.append(stage)
	return stages

static func _make_later_wave(stage: Dictionary, room_number: int, wave: int) -> Dictionary:
	var primary: Dictionary = stage.enemies[0]
	primary.pos = Vector2(240 if wave == 1 else 490, 430 if wave == 1 else 390)
	primary.hp = float(primary.hp) * (1.5 if wave == 1 else 2.0)
	primary.max_hp = primary.hp
	primary.counter_max = 4
	# 斜めの射線でまとめて当てられる敵。属性は部屋ごとに異なる。
	var side_element: int = (room_number + wave + 1) % 4
	var side_pos := Vector2(500 if wave == 1 else 220, 620 if wave == 1 else 540)
	var side := _enemy(stage.enemies.size(), side_pos, 44, 84 if wave == 1 else 112, side_element, 4, true, "まもりだま")
	side["art_element"] = side_element
	stage.enemies.append(side)
	if wave == 2 and room_number < 4:
		var rear_element: int = (side_element + 2) % 4
		var rear := _enemy(stage.enemies.size(), Vector2(380, 750), 40, 90, rear_element, 4, true, "うしろのたま")
		rear["art_element"] = rear_element
		stage.enemies.append(rear)
	# 盤面中央を塞ぐ穴と左右のはね板を、段階ごとに組み合わせる。
	if wave == 1:
		stage.pads = [_pad(0, Vector2(150, 815), 34, 1.6)]
		stage.holes = [_hole(0, Vector2(365, 820), 42)] if room_number % 2 == 0 else []
	else:
		stage.pads = [_pad(0, Vector2(570, 850), 34, 1.6)]
		stage.holes = [_hole(0, Vector2(355, 760), 44)]
	return stage

static func _enemy(idx: int, pos: Vector2, radius: float, hp: float, element: int, counter_max: int, no_counter: bool, name: String) -> Dictionary:
	return {
		"idx": idx, "pos": pos, "radius": radius, "hp": hp, "max_hp": hp, "element": element,
		"alive": true, "counter": 1, "counter_max": counter_max, "no_counter": no_counter,
		"name": name, "attack_pattern": 0,
	}

static func _pad(id: int, pos: Vector2, radius: float, boost: float) -> Dictionary:
	return {"id": id, "pos": pos, "radius": radius, "boost": boost}

static func _hole(id: int, pos: Vector2, radius: float) -> Dictionary:
	return {"id": id, "pos": pos, "radius": radius}
