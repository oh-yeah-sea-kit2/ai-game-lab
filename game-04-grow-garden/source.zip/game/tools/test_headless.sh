#!/usr/bin/env bash
set -euo pipefail

GAME_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BOOK_ROOT="$(cd "$GAME_ROOT/.." && pwd)"
GODOT_BIN="/Applications/Godot.app/Contents/MacOS/Godot"
mkdir -p "$BOOK_ROOT/.godot-data" "$BOOK_ROOT/.godot-config" "$BOOK_ROOT/.godot-cache" "$BOOK_ROOT/qa/logs"
export XDG_DATA_HOME="$BOOK_ROOT/.godot-data"
export XDG_CONFIG_HOME="$BOOK_ROOT/.godot-config"
export XDG_CACHE_HOME="$BOOK_ROOT/.godot-cache"

cat > "$GAME_ROOT/override.cfg" <<'EOF'
[network]
tls/certificate_bundle_override="/etc/ssl/cert.pem"
EOF
trap 'rm -f "$GAME_ROOT/override.cfg"' EXIT

cd "$BOOK_ROOT"

# PNG preloads require Godot's import cache before a fresh headless run.
"$GODOT_BIN" --headless --editor --path "$GAME_ROOT" --import \
  > "$BOOK_ROOT/qa/logs/headless-import-output.log" 2>&1

declare -A RESULTS

run_strategy() {
  local strategy="$1"
  local run_log="$BOOK_ROOT/qa/logs/headless-${strategy}-output.log"
  "$GODOT_BIN" --headless --path "$GAME_ROOT" \
    --log-file "$BOOK_ROOT/qa/logs/godot-headless-${strategy}.log" --fixed-fps 60 -- \
    --autoplay "--strategy=${strategy}" --seconds=360 --seed=1 --timescale=20 \
    > "$run_log" 2>&1 || {
      cat "$run_log"
      exit 1
    }
  if rg -n '(^ERROR:|SCRIPT ERROR:|Parse Error:)' "$run_log"; then
    echo "Godot reported an error for strategy=${strategy}" >&2
    cat "$run_log"
    exit 1
  fi
  local result
  result="$(rg '^\{' "$run_log" | tail -n 1)"
  if [[ -z "$result" ]]; then
    echo "Autoplay JSON result was not found for strategy=${strategy}" >&2
    cat "$run_log"
    exit 1
  fi
  RESULTS[$strategy]="$result"
  echo "strategy=${strategy}: $result"
}

run_strategy "idle"
run_strategy "greedy"
run_strategy "balanced"
run_strategy "hands_off"

IDLE="${RESULTS[idle]}"
GREEDY="${RESULTS[greedy]}"
BALANCED="${RESULTS[balanced]}"
HANDS_OFF="${RESULTS[hands_off]}"

FAIL=0

if ! jq -e '.errors == 0' <<< "$IDLE" >/dev/null; then echo "idle: errors != 0" >&2; FAIL=1; fi
if ! jq -e '.errors == 0' <<< "$GREEDY" >/dev/null; then echo "greedy: errors != 0" >&2; FAIL=1; fi
if ! jq -e '.errors == 0' <<< "$BALANCED" >/dev/null; then echo "balanced: errors != 0" >&2; FAIL=1; fi
if ! jq -e '.errors == 0' <<< "$HANDS_OFF" >/dev/null; then echo "hands_off: errors != 0" >&2; FAIL=1; fi

if ! jq -e '.idle_ripe >= 1' <<< "$IDLE" >/dev/null; then
  echo "idle: idle_ripe < 1 (放置で育っていない)" >&2
  FAIL=1
fi

IDLE_EARNED="$(jq -r '.earned' <<< "$IDLE")"
BALANCED_EARNED="$(jq -r '.earned' <<< "$BALANCED")"
HANDS_OFF_EARNED="$(jq -r '.earned' <<< "$HANDS_OFF")"
if ! awk -v i="$IDLE_EARNED" 'BEGIN{exit !(i > 0)}'; then
  echo "idle.earned ($IDLE_EARNED) must be positive after season-end settlement" >&2
  FAIL=1
fi
if ! jq -e '.hands_off_at > 0 and (.tools | index("scarecrow")) != null and (.tools | index("auto_ship")) != null and (.tools | index("auto_seed")) != null' <<< "$HANDS_OFF" >/dev/null; then
  echo "hands_off: three tools were not acquired before input stopped" >&2
  FAIL=1
fi
if ! awk -v h="$HANDS_OFF_EARNED" -v i="$IDLE_EARNED" -v b="$BALANCED_EARNED" 'BEGIN{exit !(b > h && h > i)}'; then
  echo "expected balanced.earned > hands_off.earned > idle.earned" >&2
  FAIL=1
fi
if ! awk -v b="$BALANCED_EARNED" -v i="$IDLE_EARNED" 'BEGIN{exit !(b > i)}'; then
  echo "balanced.earned ($BALANCED_EARNED) is not greater than idle.earned ($IDLE_EARNED)" >&2
  FAIL=1
fi

TOP_CROP_NAME="ほうき星の実"
if ! jq -e --arg top "$TOP_CROP_NAME" '.top_crop == $top' <<< "$BALANCED" >/dev/null; then
  echo "balanced did not harvest the top-tier crop ($TOP_CROP_NAME): $(jq -r '.top_crop' <<< "$BALANCED")" >&2
  FAIL=1
fi

if [[ "$FAIL" -ne 0 ]]; then
  echo "Headless acceptance FAILED" >&2
  echo "idle:     $IDLE"
  echo "greedy:   $GREEDY"
  echo "balanced: $BALANCED"
  echo "hands_off: $HANDS_OFF"
  exit 1
fi

echo "Headless acceptance passed"
echo "idle:     $IDLE"
echo "greedy:   $GREEDY"
echo "balanced: $BALANCED"
echo "hands_off: $HANDS_OFF"
