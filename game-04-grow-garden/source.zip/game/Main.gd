extends Node2D

const GAME_FONT := preload("res://fonts/MPLUSRounded1c-Bold-subset.ttf")
const GARDEN_BG := preload("res://art/garden_bg.png")
const TITLE_BG := preload("res://art/title_bg.png")
const GROWTH_ART := [preload("res://art/growth_00.png"), preload("res://art/growth_01.png"), preload("res://art/growth_02.png"), preload("res://art/growth_03.png")]
const RIPE_ART := [
	preload("res://art/ripe_organic_00.png"), preload("res://art/ripe_organic_01.png"),
	preload("res://art/ripe_round_00.png"), preload("res://art/ripe_organic_02.png"),
	preload("res://art/ripe_organic_03.png"), preload("res://art/ripe_organic_04.png"),
	preload("res://art/ripe_organic_05.png"), preload("res://art/ripe_organic_06.png"),
	preload("res://art/ripe_organic_07.png"), preload("res://art/ripe_round_01.png"),
	preload("res://art/ripe_organic_08.png"), preload("res://art/ripe_organic_09.png")]
const PARTS := [
	preload("res://art/garden_parts_00.png"), preload("res://art/garden_parts_01.png"),
	preload("res://art/garden_parts_02.png"), preload("res://art/garden_parts_03.png"),
	preload("res://art/garden_parts_04.png"), preload("res://art/garden_parts_05.png"),
	preload("res://art/garden_parts_06.png"), preload("res://art/garden_parts_07.png"),
	preload("res://art/garden_parts_08.png"), preload("res://art/garden_parts_09.png"),
	preload("res://art/garden_parts_10.png"), preload("res://art/garden_parts_11.png"),
	preload("res://art/garden_parts_12.png"), preload("res://art/garden_parts_13.png"),
	preload("res://art/garden_parts_14.png")]

const CROPS := [
	{"name": "はつかな", "seed": 5.0, "sell": 9.0, "time": 10.0, "tree": false, "color": Color("8bd66b")},
	{"name": "ころ芋", "seed": 12.0, "sell": 22.0, "time": 16.0, "tree": false, "color": Color("caa06a")},
	{"name": "あかトマト", "seed": 25.0, "sell": 48.0, "time": 22.0, "tree": false, "color": Color("e0574c")},
	{"name": "そらまめ", "seed": 45.0, "sell": 88.0, "time": 30.0, "tree": false, "color": Color("6bbf59")},
	{"name": "つきかぶ", "seed": 75.0, "sell": 150.0, "time": 38.0, "tree": false, "color": Color("d9d9f0")},
	{"name": "ほし苺", "seed": 115.0, "sell": 235.0, "time": 46.0, "tree": false, "color": Color("f26b8a")},
	{"name": "ゆきうり", "seed": 165.0, "sell": 340.0, "time": 54.0, "tree": false, "color": Color("bfe7f2")},
	{"name": "ひかり麦", "seed": 230.0, "sell": 480.0, "time": 62.0, "tree": false, "color": Color("f0d768")},
	{"name": "ねむり花", "seed": 310.0, "sell": 650.0, "time": 70.0, "tree": false, "color": Color("b28ae0")},
	{"name": "にじ瓜", "seed": 410.0, "sell": 860.0, "time": 78.0, "tree": false, "color": Color("7fd9c4")},
	{"name": "ほうき星の実", "seed": 530.0, "sell": 1120.0, "time": 90.0, "tree": false, "color": Color("ffd27f")},
	{"name": "あめ実の木", "seed": 260.0, "sell": 140.0, "time": 45.0, "tree": true, "color": Color("e0895a")},
]
const TOOLS := [
	{"key": "scarecrow", "name": "かかし", "cost": 220.0, "desc": "実った作物を自動で収穫"},
	{"key": "auto_ship", "name": "自動出荷箱", "cost": 180.0, "desc": "かごが満杯で自動出荷"},
	{"key": "auto_seed", "name": "自動種まき機", "cost": 300.0, "desc": "空いた区画に最後の種を自動で植える"},
	{"key": "jouro", "name": "じょうろ", "cost": 90.0, "desc": "タップした区画の成長が一時的に2倍"},
]
const TOOL_ORDER := ["scarecrow", "auto_ship", "auto_seed", "jouro"]
const EXPANSIONS := [
	{"rows": 4, "cols": 4, "cost": 140.0},
	{"rows": 4, "cols": 5, "cost": 280.0},
	{"rows": 5, "cols": 5, "cost": 520.0},
	{"rows": 5, "cols": 6, "cost": 860.0},
]
const VARIANT_MULT := [1.0, 3.0, 10.0]
const VARIANT_NAME := ["", "つやつや", "きらめき"]
const START_MONEY := 40.0
const DURATION := 360.0
const AUTO_SHIP_CAPACITY := 20
const WATER_BOOST := 15.0
const TOP_CROP_ID := 10
const WEATHER_NAMES := {"sunny": "はれ", "rain": "あめ", "star": "ながれ星"}

var rng := RandomNumberGenerator.new()
var state := "title"
var autoplay := false
var demo_enabled := false
var demo_wait := 0.0
var strategy := "balanced"
var run_seconds := DURATION
var time_scale := 1.0
var debug_time_scale := 1.0
var elapsed := 0.0

var rows := 3
var cols := 3
var plots: Array = []
var expansion_tier := 0
var tools_owned: Dictionary = {}
var basket: Array = []
var money := START_MONEY
var earned := 0.0
var planted := 0
var harvested := 0
var sparkles := 0
var glossies := 0
var top_crop_id := -1
var idle_ripe := 0
var idle_seeded := false
var hands_off_at := -1.0
var selected_seed := 0
var last_seed := -1

var weather := "sunny"
var weather_timer := 0.0

var shop_open := false
var rack_scroll := 0.0
var shop_scroll := 0.0

var pointer_active := false
var pointer_target := ""
var pointer_start := Vector2.ZERO
var pointer_last := Vector2.ZERO
var pointer_moved := 0.0
var grid_pointer_mode := ""

var best_earned := 0.0
var result_clear := false
var money_display := START_MONEY

var next_progress := 60.0
var money_pop: Array = []
var harvest_fx: Array = []
var sprite_bounds: Dictionary = {}
var ship_button_style: StyleBoxTexture
var shop_button_style: StyleBoxTexture
var start_button_style: StyleBoxTexture

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	ship_button_style = _button_style(PARTS[3], 68, 68, 26, 26)
	shop_button_style = _button_style(PARTS[4], 60, 60, 26, 26)
	start_button_style = _button_style(PARTS[8], 118, 35, 26, 26)
	_parse_args()
	if OS.has_feature("web"):
		var query := str(JavaScriptBridge.eval("window.location.search"))
		for part in query.trim_prefix("?").split("&"):
			if part == "demo=1":
				demo_enabled = true
				demo_wait = 2.0
		var speed = JavaScriptBridge.eval("new URLSearchParams(window.location.search).get('debug_speed')", true)
		if not demo_enabled and typeof(speed) == TYPE_STRING and speed.is_valid_float():
			debug_time_scale = clampf(float(speed), 1.0, 40.0)
	rng.seed = int(_arg_value("--seed=", "1")) if autoplay or demo_enabled else int(Time.get_ticks_usec())
	_load_best()
	if autoplay:
		_start_game()
	queue_redraw()

func _parse_args() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg == "--autoplay":
			autoplay = true
	run_seconds = maxf(1.0, float(_arg_value("--seconds=", "360")))
	time_scale = clampf(float(_arg_value("--timescale=", "1")), 0.1, 60.0)
	strategy = _arg_value("--strategy=", "balanced")

func _arg_value(prefix: String, default_value: String) -> String:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with(prefix):
			return arg.substr(prefix.length())
	return default_value

func _new_plot() -> Dictionary:
	return {"state": "empty", "crop_id": -1, "progress": 0.0, "variant": 0, "water_timer": 0.0}

func _start_game() -> void:
	state = "play"
	elapsed = 0.0
	rows = 3
	cols = 3
	plots.clear()
	for i in rows * cols:
		plots.append(_new_plot())
	expansion_tier = 0
	tools_owned.clear()
	basket.clear()
	money = START_MONEY
	money_display = START_MONEY
	earned = 0.0
	planted = 0
	harvested = 0
	sparkles = 0
	glossies = 0
	top_crop_id = -1
	idle_ripe = 0
	idle_seeded = false
	hands_off_at = -1.0
	selected_seed = 0
	last_seed = -1
	weather = "sunny"
	weather_timer = 0.0
	shop_open = false
	rack_scroll = 0.0
	shop_scroll = 0.0
	pointer_active = false
	result_clear = false
	next_progress = 60.0
	money_pop.clear()
	harvest_fx.clear()

func _process(delta: float) -> void:
	var dt := minf(delta * time_scale, 0.7) if autoplay else minf(delta, 0.05)
	if debug_time_scale > 1.0 and not autoplay and not demo_enabled:
		dt = minf(delta * debug_time_scale, 0.7)
	if demo_enabled and state != "play":
		demo_wait -= delta
		if demo_wait <= 0.0:
			_start_game()
	if state == "play":
		while dt > 0.0 and state == "play":
			var step := minf(dt, 0.05)
			_update_game(step)
			dt -= step
	_update_visual(delta)
	_publish_web_state()
	queue_redraw()

## Web 版のタッチ操作検証用。矩形はブラウザのビューポート上の CSS ピクセル。
func _publish_web_state() -> void:
	if not OS.has_feature("web"):
		return
	var metrics_json = JavaScriptBridge.eval("(function(){const c=document.getElementById('canvas')||document.querySelector('canvas');if(!c)return '[]';const r=c.getBoundingClientRect();return JSON.stringify([r.left,r.top,r.width,r.height,c.width,c.height]);})()", true)
	var metrics = JSON.parse_string(str(metrics_json))
	var rects := {"shop_button": [], "shop_close": [], "shop_items": [], "retry_button": [], "start_button": []}
	if metrics is Array and metrics.size() == 6 and float(metrics[4]) > 0.0 and float(metrics[5]) > 0.0:
		var transform := get_viewport().get_screen_transform() * get_global_transform_with_canvas()
		var size := _size()
		if state == "title":
			rects.start_button = _css_rect(Rect2(size * 0.5 + Vector2(0, 185) - Vector2(255, 65), Vector2(510, 130)), transform, metrics)
		elif state == "result":
			rects.retry_button = _css_rect(Rect2(size * 0.5 + Vector2(0, 200) - Vector2(255, 42), Vector2(510, 84)), transform, metrics)
		elif state == "play":
			rects.shop_button = _css_rect(_shop_button_rect(size), transform, metrics)
			if shop_open:
				rects.shop_close = _css_rect(_shop_close_rect(size), transform, metrics)
				for i in _shop_items().size():
					rects.shop_items.append(_css_rect(_shop_item_rect(size, i), transform, metrics))
	var owned: Array = []
	for key in TOOL_ORDER:
		if _owns(key):
			owned.append(key)
	var web_state := {"state": state, "money": money, "shop_open": shop_open,
		"owned_tools": owned, "time_left": maxf(0.0, run_seconds - elapsed), "rects": rects}
	JavaScriptBridge.eval("window.__garden = %s;" % JSON.stringify(web_state), true)

func _css_rect(rect: Rect2, transform: Transform2D, metrics: Array) -> Array:
	var a := transform * rect.position
	var b := transform * rect.end
	var sx := float(metrics[2]) / float(metrics[4])
	var sy := float(metrics[3]) / float(metrics[5])
	return [float(metrics[0]) + minf(a.x, b.x) * sx, float(metrics[1]) + minf(a.y, b.y) * sy,
		absf(b.x - a.x) * sx, absf(b.y - a.y) * sy]

func _update_visual(delta: float) -> void:
	money_display = move_toward(money_display, money, maxf(4.0, absf(money - money_display) * 6.0) * delta)
	for i in range(money_pop.size() - 1, -1, -1):
		money_pop[i].life -= delta
		if money_pop[i].life <= 0.0:
			money_pop.remove_at(i)
	for i in range(harvest_fx.size() - 1, -1, -1):
		harvest_fx[i].life -= delta
		if harvest_fx[i].life <= 0.0:
			harvest_fx.remove_at(i)

func _update_game(dt: float) -> void:
	elapsed += dt
	_update_weather(dt)
	_update_plots(dt)
	if autoplay or demo_enabled:
		match strategy:
			"idle":
				_auto_idle_tick()
			"greedy":
				_auto_greedy_tick()
			"balanced":
				_auto_balanced_tick()
			"hands_off":
				_auto_hands_off_tick()
	_update_tools(dt)
	if autoplay:
		if elapsed >= next_progress:
			print("PROGRESS sec=%.0f money=%.0f planted=%d harvested=%d earned=%.0f plots=%d" % [elapsed, money, planted, harvested, earned, plots.size()])
			next_progress += 60.0
	if elapsed >= run_seconds:
		_finish()

func _update_weather(dt: float) -> void:
	weather_timer -= dt
	if weather_timer <= 0.0:
		weather_timer += 60.0
		var roll := rng.randf()
		if roll < 0.5:
			weather = "sunny"
		elif roll < 0.8:
			weather = "rain"
		else:
			weather = "star"

func _growth_multiplier(plot: Dictionary) -> float:
	var multiplier := 1.0
	if weather == "rain":
		multiplier *= 1.5
	if plot.water_timer > 0.0:
		multiplier *= 2.0
	return multiplier

func _update_plots(dt: float) -> void:
	for i in plots.size():
		var plot: Dictionary = plots[i]
		if plot.state != "growing":
			continue
		if plot.water_timer > 0.0:
			plot.water_timer = maxf(0.0, plot.water_timer - dt)
		var crop: Dictionary = CROPS[plot.crop_id]
		var multiplier := _growth_multiplier(plot)
		plot.progress += dt * multiplier / crop.time
		if plot.progress >= 1.0:
			plot.progress = 1.0
			plot.state = "ripe"
			plot.variant = _roll_variant()
			if autoplay and strategy == "idle":
				idle_ripe += 1

func _roll_variant() -> int:
	var tsuya_chance := 0.06
	var kirameki_chance := 0.01
	if weather == "star":
		tsuya_chance = 0.20
		kirameki_chance = 0.08
	var roll := rng.randf()
	if roll < kirameki_chance:
		return 2
	elif roll < kirameki_chance + tsuya_chance:
		return 1
	return 0

func _owns(key: String) -> bool:
	return tools_owned.has(key)

func _tool_cost(key: String) -> float:
	for tool in TOOLS:
		if tool.key == key:
			return tool.cost
	return 0.0

func _update_tools(dt: float) -> void:
	if _owns("scarecrow"):
		for i in plots.size():
			if plots[i].state == "ripe":
				_harvest(i)
	if _owns("auto_seed") and last_seed >= 0:
		for i in plots.size():
			if plots[i].state == "empty" and money >= CROPS[last_seed].seed:
				_plant(i, last_seed)
	if _owns("auto_ship") and basket.size() >= AUTO_SHIP_CAPACITY:
		_ship()

func _plant(index: int, crop_id: int) -> bool:
	if index < 0 or index >= plots.size():
		return false
	if crop_id < 0 or crop_id >= CROPS.size():
		return false
	var plot: Dictionary = plots[index]
	if plot.state != "empty":
		return false
	var crop: Dictionary = CROPS[crop_id]
	if money < crop.seed:
		return false
	money -= crop.seed
	plot.state = "growing"
	plot.crop_id = crop_id
	plot.progress = 0.0
	plot.variant = 0
	plot.water_timer = 0.0
	planted += 1
	last_seed = crop_id
	return true

func _harvest(index: int) -> bool:
	if index < 0 or index >= plots.size():
		return false
	var plot: Dictionary = plots[index]
	if plot.state != "ripe":
		return false
	var crop_id: int = plot.crop_id
	var variant: int = plot.variant
	var crop: Dictionary = CROPS[crop_id]
	var value: float = crop.sell * VARIANT_MULT[variant]
	basket.append({"crop_id": crop_id, "value": value, "variant": variant})
	harvested += 1
	if variant == 2:
		sparkles += 1
	elif variant == 1:
		glossies += 1
	if top_crop_id < 0 or crop.sell > CROPS[top_crop_id].sell:
		top_crop_id = crop_id
	if not autoplay:
		var size := _size()
		var origin := _grid_rect(index, _layout(size), size).get_center()
		harvest_fx.append({"life": 0.5, "origin": origin, "crop_id": crop_id, "variant": variant})
	if crop.tree:
		plot.state = "growing"
		plot.progress = 0.0
		plot.variant = 0
		plot.water_timer = 0.0
	else:
		plot.state = "empty"
		plot.crop_id = -1
		plot.progress = 0.0
		plot.variant = 0
	return true

func _ship() -> void:
	if basket.is_empty():
		return
	var total := 0.0
	for item in basket:
		total += item.value
	earned += total
	money += total
	if not autoplay:
		# Keep one cumulative receipt while shipments arrive together.
		if money_pop.is_empty():
			money_pop.append({"life": 0.9, "value": total})
		else:
			money_pop[0].value += total
			money_pop[0].life = 0.9
	basket.clear()

func _buy_expansion() -> bool:
	if expansion_tier >= EXPANSIONS.size():
		return false
	var exp: Dictionary = EXPANSIONS[expansion_tier]
	if money < exp.cost:
		return false
	money -= exp.cost
	_resize_grid(exp.rows, exp.cols)
	expansion_tier += 1
	return true

func _buy_tool(key: String) -> bool:
	if _owns(key):
		return false
	var cost := _tool_cost(key)
	if money < cost:
		return false
	money -= cost
	tools_owned[key] = true
	return true

func _resize_grid(new_rows: int, new_cols: int) -> void:
	var new_plots: Array = []
	for r in new_rows:
		for c in new_cols:
			if r < rows and c < cols:
				new_plots.append(plots[r * cols + c])
			else:
				new_plots.append(_new_plot())
	plots = new_plots
	rows = new_rows
	cols = new_cols

func _find_empty_plot() -> int:
	for i in plots.size():
		if plots[i].state == "empty":
			return i
	return -1

func _best_affordable_crop() -> int:
	var best_id := -1
	var best_cost := -1.0
	for i in CROPS.size():
		if CROPS[i].seed <= money and CROPS[i].seed > best_cost:
			best_cost = CROPS[i].seed
			best_id = i
	return best_id

func _auto_plant_best_affordable() -> void:
	var changed := true
	while changed:
		changed = false
		var idx := _find_empty_plot()
		if idx < 0:
			break
		var crop_id := _best_affordable_crop()
		if crop_id < 0:
			break
		if _plant(idx, crop_id):
			changed = true

func _auto_harvest_and_ship() -> void:
	for i in plots.size():
		if plots[i].state == "ripe":
			_harvest(i)
	_ship()

func _auto_idle_tick() -> void:
	if idle_seeded:
		return
	idle_seeded = true
	for i in plots.size():
		_plant(i, 0)

func _auto_greedy_tick() -> void:
	_auto_harvest_and_ship()
	_auto_plant_best_affordable()

func _auto_balanced_tick() -> void:
	_auto_harvest_and_ship()
	if _buy_expansion():
		return
	for key in TOOL_ORDER:
		if not _owns(key):
			if _buy_tool(key):
				return
			break
	_auto_plant_top_or_best()

func _auto_hands_off_tick() -> void:
	if hands_off_at >= 0.0:
		return
	_auto_harvest_and_ship()
	for key in ["scarecrow", "auto_ship", "auto_seed"]:
		if not _owns(key) and not _buy_tool(key):
			break
	# Keep enough seed money for one full auto-ship batch before stopping input.
	if _owns("scarecrow") and _owns("auto_ship") and _owns("auto_seed") and money >= CROPS[0].seed * AUTO_SHIP_CAPACITY:
		hands_off_at = elapsed
		return
	for i in plots.size():
		if plots[i].state == "empty":
			_plant(i, 0)

func _auto_plant_top_or_best() -> void:
	var idx := _find_empty_plot()
	if idx >= 0 and money >= CROPS[TOP_CROP_ID].seed:
		_plant(idx, TOP_CROP_ID)
	_auto_plant_best_affordable()

func _finish() -> void:
	state = "result"
	for i in plots.size():
		if plots[i].state == "ripe":
			_harvest(i)
	_ship()
	result_clear = true
	if autoplay:
		var tools_list: Array = []
		for key in TOOL_ORDER:
			if _owns(key):
				tools_list.append(key)
		var output := {
			"strategy": strategy,
			"planted": planted,
			"harvested": harvested,
			"earned": snappedf(earned, 0.01),
			"top_crop": CROPS[top_crop_id].name if top_crop_id >= 0 else "",
			"sparkles": sparkles,
			"plots": plots.size(),
			"tools": tools_list,
			"idle_ripe": idle_ripe,
			"hands_off_at": snappedf(hands_off_at, 0.01),
			"errors": 0,
		}
		print(JSON.stringify(output))
		get_tree().quit()
	else:
		if not demo_enabled and earned > best_earned:
			best_earned = earned
			_save_best()
		if demo_enabled:
			demo_wait = 5.0

func _load_best() -> void:
	if FileAccess.file_exists("user://best.json"):
		var file := FileAccess.open("user://best.json", FileAccess.READ)
		if file:
			var value = JSON.parse_string(file.get_as_text())
			if value is Dictionary:
				best_earned = float(value.get("earned", 0.0))

func _save_best() -> void:
	var file := FileAccess.open("user://best.json", FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify({"earned": best_earned}))

# ---------------------------------------------------------------------------
# Input
# ---------------------------------------------------------------------------

func _input(event: InputEvent) -> void:
	if autoplay or demo_enabled:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_pointer_event(event.position, event.pressed, false)
	elif event is InputEventMouseMotion and pointer_active:
		_pointer_event(event.position, true, true)

func _pointer_event(point: Vector2, pressed: bool, drag: bool) -> void:
	if not drag and pressed:
		pointer_active = true
		pointer_start = point
		pointer_last = point
		pointer_moved = 0.0
		_pointer_press(point)
	elif drag and pointer_active:
		pointer_moved += point.distance_to(pointer_last)
		_pointer_drag(point)
		pointer_last = point
	elif not pressed:
		_pointer_release(point)
		pointer_active = false
		pointer_target = ""

func _pointer_press(point: Vector2) -> void:
	if state == "title" or state == "result":
		pointer_target = "start_or_restart"
		return
	if state != "play":
		pointer_target = ""
		return
	var size := _size()
	if shop_open:
		pointer_target = "shop"
		return
	if _ship_button_rect(size).has_point(point):
		pointer_target = "ship_button"
		return
	if _shop_button_rect(size).has_point(point):
		pointer_target = "shop_button"
		return
	if _rack_rect(size).has_point(point):
		pointer_target = "rack"
		return
	var idx := _grid_index_at(point)
	if idx >= 0:
		pointer_target = "grid"
		_grid_press(idx)
		return
	pointer_target = "none"

func _grid_press(idx: int) -> void:
	var plot: Dictionary = plots[idx]
	if plot.state == "empty":
		if _plant(idx, selected_seed):
			grid_pointer_mode = "plant"
		else:
			grid_pointer_mode = ""
	elif plot.state == "ripe":
		_harvest(idx)
		grid_pointer_mode = "harvest"
	elif plot.state == "growing" and _owns("jouro"):
		plot.water_timer = WATER_BOOST
		grid_pointer_mode = "water"
	else:
		grid_pointer_mode = ""

func _grid_drag(idx: int) -> void:
	var plot: Dictionary = plots[idx]
	match grid_pointer_mode:
		"plant":
			if plot.state == "empty":
				_plant(idx, selected_seed)
		"harvest":
			if plot.state == "ripe":
				_harvest(idx)
		"water":
			if plot.state == "growing" and _owns("jouro"):
				plot.water_timer = WATER_BOOST

func _pointer_drag(point: Vector2) -> void:
	match pointer_target:
		"rack":
			rack_scroll = clampf(rack_scroll - (point.x - pointer_last.x), 0.0, _rack_scroll_max())
		"shop":
			shop_scroll = clampf(shop_scroll - (point.y - pointer_last.y), 0.0, _shop_scroll_max())
		"grid":
			var idx := _grid_index_at(point)
			if idx >= 0:
				_grid_drag(idx)

func _pointer_release(point: Vector2) -> void:
	match pointer_target:
		"start_or_restart":
			if pointer_moved < 12.0 and (state == "title" or state == "result"):
				_start_game()
		"ship_button":
			if pointer_moved < 12.0:
				_ship()
		"shop_button":
			if pointer_moved < 12.0:
				shop_open = not shop_open
				shop_scroll = 0.0
		"rack":
			if pointer_moved < 12.0:
				var arrow := _rack_arrow_at(point)
				if arrow != 0:
					rack_scroll = clampf(rack_scroll + arrow * _rack_spacing(_layout(_size())), 0.0, _rack_scroll_max())
				else:
					var seed_idx := _rack_index_at(pointer_start)
					if seed_idx >= 0:
						selected_seed = seed_idx
			else:
				rack_scroll = roundf(rack_scroll / _rack_spacing(_layout(_size()))) * _rack_spacing(_layout(_size()))
		"shop":
			if pointer_moved < 12.0:
				_shop_click(point)

func _shop_click(point: Vector2) -> void:
	var size := _size()
	if _shop_close_rect(size).has_point(point) or _shop_button_rect(size).has_point(point) or not _shop_panel_rect(size).has_point(point):
		shop_open = false
		return
	var idx := _shop_item_index_at(point)
	if idx < 0:
		return
	var items := _shop_items()
	var item: Dictionary = items[idx]
	if item.done:
		return
	if item.type == "expand":
		_buy_expansion()
	elif item.type == "tool":
		_buy_tool(item.key)

# ---------------------------------------------------------------------------
# Layout helpers
# ---------------------------------------------------------------------------

func _size() -> Vector2:
	return get_viewport_rect().size

func _layout(size: Vector2) -> Dictionary:
	var top_h := size.y * 0.13
	var rack_h := size.y * 0.15
	var buttons_h := size.y * 0.09
	return {
		"top_h": top_h,
		"grid_top": top_h,
		"grid_bottom": size.y - rack_h - buttons_h,
		"grid_margin": size.x * 0.05,
		"rack_top": size.y - rack_h - buttons_h,
		"rack_h": rack_h,
		"buttons_top": size.y - buttons_h,
		"buttons_h": buttons_h,
	}

func _grid_cell_size(layout: Dictionary, size: Vector2) -> float:
	var avail_w: float = size.x - 2.0 * layout.grid_margin
	var avail_h: float = layout.grid_bottom - layout.grid_top - 12.0
	return minf(avail_w / float(cols), avail_h / float(rows))

func _grid_origin(layout: Dictionary, size: Vector2, cell: float) -> Vector2:
	var total_w := cell * cols
	var total_h := cell * rows
	var x := (size.x - total_w) * 0.5
	var y: float = layout.grid_top + (layout.grid_bottom - layout.grid_top - total_h) * 0.5
	return Vector2(x, y)

func _grid_index_at(point: Vector2) -> int:
	var size := _size()
	var layout := _layout(size)
	var cell := _grid_cell_size(layout, size)
	var origin := _grid_origin(layout, size, cell)
	var rel := point - origin
	if rel.x < 0.0 or rel.y < 0.0:
		return -1
	if rel.x >= cell * cols or rel.y >= cell * rows:
		return -1
	var c := int(rel.x / cell)
	var r := int(rel.y / cell)
	if c < 0 or c >= cols or r < 0 or r >= rows:
		return -1
	return r * cols + c

func _grid_rect(idx: int, layout: Dictionary, size: Vector2) -> Rect2:
	var cell := _grid_cell_size(layout, size)
	var origin := _grid_origin(layout, size, cell)
	var r := idx / cols
	var c := idx % cols
	return Rect2(origin + Vector2(c * cell, r * cell), Vector2(cell, cell)).grow(-4.0)

func _rack_rect(size: Vector2) -> Rect2:
	var layout := _layout(size)
	return Rect2(Vector2(0.0, layout.rack_top), Vector2(size.x, layout.rack_h))

func _rack_item_size(layout: Dictionary) -> Vector2:
	return Vector2(190.0, minf(layout.rack_h - 4.0, 190.0))

func _rack_spacing(layout: Dictionary) -> float:
	return _rack_item_size(layout).x + 18.0

func _rack_visible_count(size: Vector2) -> int:
	var spacing := _rack_spacing(_layout(size))
	return maxi(1, int(floor((size.x - 16.0 - 82.0 + 18.0) / spacing)))

func _rack_first_index() -> int:
	var spacing := _rack_spacing(_layout(_size()))
	return clampi(int(roundf(rack_scroll / spacing)), 0, maxi(0, CROPS.size() - _rack_visible_count(_size())))

func _rack_arrow_at(point: Vector2) -> int:
	var rect := _rack_rect(_size())
	if point.x < rect.end.x - 82.0 or not rect.has_point(point):
		return 0
	if point.y < rect.position.y + rect.size.y * 0.5:
		return -1 if _rack_first_index() > 0 else 0
	return 1 if _rack_first_index() + _rack_visible_count(_size()) < CROPS.size() else 0

func _rack_index_at(point: Vector2) -> int:
	var size := _size()
	var layout := _layout(size)
	var item := _rack_item_size(layout)
	var spacing := _rack_spacing(layout)
	if point.x >= size.x - 82.0:
		return -1
	var x := point.x - 16.0
	var idx := _rack_first_index() + int(floor(x / spacing))
	if idx < 0 or idx >= CROPS.size():
		return -1
	var local_x := x - (idx - _rack_first_index()) * spacing
	if local_x < 0.0 or local_x > item.x or idx >= _rack_first_index() + _rack_visible_count(size):
		return -1
	return idx

func _rack_scroll_max() -> float:
	var size := _size()
	var layout := _layout(size)
	var spacing := _rack_spacing(layout)
	return maxf(0.0, float(CROPS.size() - _rack_visible_count(size)) * spacing)

func _ship_button_rect(size: Vector2) -> Rect2:
	var layout := _layout(size)
	var w := size.x * 0.44
	var h: float = layout.buttons_h * 0.82
	return Rect2(Vector2(size.x * 0.03, layout.buttons_top + (layout.buttons_h - h) * 0.5), Vector2(w, h))

func _shop_button_rect(size: Vector2) -> Rect2:
	var layout := _layout(size)
	var w := size.x * 0.44
	var h: float = layout.buttons_h * 0.82
	return Rect2(Vector2(size.x * 0.53, layout.buttons_top + (layout.buttons_h - h) * 0.5), Vector2(w, h))

func _shop_panel_rect(size: Vector2) -> Rect2:
	var w := minf(size.x * 0.9, 760.0)
	var h := minf(size.y * 0.74, 800.0)
	return Rect2((size.x - w) * 0.5, (size.y - h) * 0.5, w, h)

func _shop_close_rect(size: Vector2) -> Rect2:
	var panel := _shop_panel_rect(size)
	return Rect2(Vector2(panel.end.x - 96.0, panel.position.y + 8.0), Vector2(88.0, 88.0))

func _shop_items() -> Array:
	var items: Array = []
	if expansion_tier < EXPANSIONS.size():
		var exp: Dictionary = EXPANSIONS[expansion_tier]
		items.append({"type": "expand", "label": "畑を広げる (%d×%d)" % [exp.rows, exp.cols], "cost": exp.cost, "done": false, "desc": "区画が %d マスに増える" % (exp.rows * exp.cols)})
	else:
		items.append({"type": "expand", "label": "畑は最大まで拡張済み", "cost": 0.0, "done": true, "desc": "5×6 マス"})
	for tool in TOOLS:
		items.append({"type": "tool", "label": tool.name, "cost": tool.cost, "done": _owns(tool.key), "key": tool.key, "desc": tool.desc})
	return items

func _shop_item_rect(size: Vector2, i: int) -> Rect2:
	var panel := _shop_panel_rect(size)
	var row_h := 132.0
	var top := panel.position.y + 98.0 - shop_scroll
	return Rect2(panel.position.x + 16.0, top + i * row_h, panel.size.x - 32.0, row_h - 12.0)

func _shop_item_index_at(point: Vector2) -> int:
	var size := _size()
	var items := _shop_items()
	for i in items.size():
		if _shop_item_rect(size, i).has_point(point):
			return i
	return -1

func _shop_scroll_max() -> float:
	var size := _size()
	var panel := _shop_panel_rect(size)
	var items := _shop_items()
	var total := 98.0 + items.size() * 132.0
	return maxf(0.0, total - panel.size.y + 20.0)

# ---------------------------------------------------------------------------
# Drawing
# ---------------------------------------------------------------------------

func _draw() -> void:
	var size := _size()
	var visible := _visible_local_rect()
	draw_rect(visible, Color(0.078, 0.11, 0.07, 1.0))
	if state == "title":
		_draw_background(TITLE_BG, visible)
		_draw_title(size)
		return
	_draw_background(GARDEN_BG, visible)
	_draw_field_bg(size)
	_draw_grid(size)
	_draw_hud(size)
	_draw_harvest_fx(size)
	_draw_rack(size)
	_draw_buttons(size)
	if shop_open:
		_draw_shop(size)
	if state == "result":
		_draw_result(size)

func _visible_local_rect() -> Rect2:
	var viewport_rect := get_viewport().get_visible_rect()
	var inverse := get_global_transform_with_canvas().affine_inverse()
	var a := inverse * viewport_rect.position
	var b := inverse * viewport_rect.end
	return Rect2(a, b - a).abs()

func _draw_background(texture: Texture2D, visible: Rect2) -> void:
	var source_size := texture.get_size()
	var scale := maxf(visible.size.x / source_size.x, visible.size.y / source_size.y)
	var crop_size := visible.size / scale
	var source := Rect2((source_size - crop_size) * 0.5, crop_size)
	draw_texture_rect_region(texture, visible, source)

func _art_bounds(texture: Texture2D) -> Rect2:
	if not sprite_bounds.has(texture):
		sprite_bounds[texture] = Rect2(texture.get_image().get_used_rect())
	return sprite_bounds[texture]

func _draw_sprite(texture: Texture2D, destination: Rect2) -> void:
	var source := _art_bounds(texture)
	var scale := minf(destination.size.x / source.size.x, destination.size.y / source.size.y)
	var drawn_size := source.size * scale
	var drawn := Rect2(destination.position + (destination.size - drawn_size) * 0.5, drawn_size)
	draw_texture_rect_region(texture, drawn, source)

func _draw_nine(texture: Texture2D, destination: Rect2, margin: float = 22.0) -> void:
	var source := _art_bounds(texture)
	var sx := minf(margin, source.size.x * 0.25)
	var sy := minf(margin, source.size.y * 0.25)
	var dx := minf(sx, destination.size.x * 0.25)
	var dy := minf(sy, destination.size.y * 0.25)
	var source_x := [source.position.x, source.position.x + sx, source.end.x - sx, source.end.x]
	var source_y := [source.position.y, source.position.y + sy, source.end.y - sy, source.end.y]
	var dest_x := [destination.position.x, destination.position.x + dx, destination.end.x - dx, destination.end.x]
	var dest_y := [destination.position.y, destination.position.y + dy, destination.end.y - dy, destination.end.y]
	for row in 3:
		for col in 3:
			var src := Rect2(source_x[col], source_y[row], source_x[col + 1] - source_x[col], source_y[row + 1] - source_y[row])
			var dst := Rect2(dest_x[col], dest_y[row], dest_x[col + 1] - dest_x[col], dest_y[row + 1] - dest_y[row])
			draw_texture_rect_region(texture, dst, src)

func _button_style(texture: Texture2D, left: float, right: float, top: float, bottom: float) -> StyleBoxTexture:
	var style := StyleBoxTexture.new()
	style.texture = texture
	style.texture_margin_left = left
	style.texture_margin_right = right
	style.texture_margin_top = top
	style.texture_margin_bottom = bottom
	return style

func _draw_field_bg(size: Vector2) -> void:
	var weather_color := Color(0.5, 0.72, 0.95, 0.10)
	if weather == "rain":
		weather_color = Color(0.35, 0.45, 0.7, 0.22)
	elif weather == "star":
		weather_color = Color(0.9, 0.8, 0.4, 0.14)
	draw_rect(_visible_local_rect(), weather_color)

func _draw_grid(size: Vector2) -> void:
	var layout := _layout(size)
	var cell := _grid_cell_size(layout, size)
	for i in plots.size():
		var rect := _grid_rect(i, layout, size)
		_draw_plot(rect, plots[i], cell)

func _draw_plot(rect: Rect2, plot: Dictionary, cell: float) -> void:
	_draw_sprite(PARTS[0], rect)
	var center := rect.position + rect.size * 0.5
	if plot.state == "empty":
		return
	var soil_anchor := rect.position + Vector2(rect.size.x * 0.5, rect.size.y * 0.66)
	_draw_plot_shadow(soil_anchor, rect.size.x)
	if plot.state == "growing":
		var stage: int = clampi(int(plot.progress * 4.0), 0, 3)
		var plant_rect := _grounded_rect(_art_bounds(GROWTH_ART[stage]), soil_anchor, Vector2(rect.size.x * 0.68, rect.size.y * [0.37, 0.45, 0.53, 0.61][stage]))
		draw_texture_rect_region(GROWTH_ART[stage], plant_rect, _art_bounds(GROWTH_ART[stage]))
		_draw_soil_lip(plant_rect)
		if plot.water_timer > 0.0:
			draw_arc(center, cell * 0.42, 0.0, TAU, 24, Color(0.5, 0.8, 1.0, 0.55), 2.0)
	elif plot.state == "ripe":
		var radius := cell * 0.32
		var plant_rect: Rect2
		if plot.crop_id == 2:
			plant_rect = _draw_tomato_plant(soil_anchor, rect.size * Vector2(0.72, 0.66))
		else:
			var texture: Texture2D = RIPE_ART[plot.crop_id]
			plant_rect = _grounded_rect(_art_bounds(texture), soil_anchor, rect.size * Vector2(0.72, 0.66))
			draw_texture_rect_region(texture, plant_rect, _art_bounds(texture))
		_draw_soil_lip(plant_rect)
		if plot.variant == 1:
			draw_arc(center, radius + 3.0, 0.0, TAU, 20, Color(1.0, 1.0, 1.0, 0.55), 2.0)
		elif plot.variant == 2:
			draw_arc(center, radius + 4.0, 0.0, TAU, 24, Color(1.0, 0.9, 0.4, 0.85), 3.0)
			for a in 4:
				var ang: float = TAU * a / 4.0 + elapsed
				draw_circle(center + Vector2.RIGHT.rotated(ang) * (radius + 10.0), 2.5, Color(1.0, 0.95, 0.6, 0.9))

func _draw_plot_shadow(anchor: Vector2, width: float) -> void:
	var points := PackedVector2Array()
	for i in 24:
		var angle := TAU * float(i) / 24.0
		points.append(anchor + Vector2(cos(angle) * width * 0.19, sin(angle) * width * 0.04))
	draw_colored_polygon(points, Color(0.09, 0.045, 0.02, 0.17))

func _soil_lip_points(plant: Rect2) -> PackedVector2Array:
	# Opaque foreground soil buries the central base by 18% of its actual height.
	# The old feathered ellipse left the white stalk visible through its edge.
	var anchor := Vector2(plant.get_center().x, plant.end.y)
	var points := PackedVector2Array()
	for point in [Vector2(-0.55, 0.03), Vector2(-0.46, -0.08), Vector2(-0.30, -0.15), Vector2(-0.13, -0.18), Vector2(0.12, -0.18), Vector2(0.29, -0.15), Vector2(0.46, -0.07), Vector2(0.55, 0.03), Vector2(0.38, 0.09), Vector2(-0.38, 0.09)]:
		points.append(anchor + point * plant.size)
	return points

func _draw_soil_lip(plant: Rect2) -> void:
	var points := _soil_lip_points(plant)
	var uv := PackedVector2Array()
	var anchor := Vector2(plant.get_center().x, plant.end.y)
	for point in points:
		var unit := (point - anchor) / plant.size
		# Sample only the opaque earth inside the existing plot, without its frame.
		uv.append((Vector2(146, 135) + unit * Vector2(150, 150)) / PARTS[0].get_size())
	draw_polygon(points, PackedColorArray([Color.WHITE]), uv, PARTS[0])

func _grounded_rect(source: Rect2, anchor: Vector2, max_size: Vector2) -> Rect2:
	var scale := minf(max_size.x / source.size.x, max_size.y / source.size.y)
	var drawn_size := source.size * scale
	return Rect2(anchor - Vector2(drawn_size.x * 0.5, drawn_size.y), drawn_size)

func _tomato_stem_source() -> Rect2:
	var source := _art_bounds(GROWTH_ART[2])
	# Reuse the existing leafy stem, excluding its unrelated flower bud.
	source.position.y += source.size.y * 0.24
	source.size.y *= 0.76
	return source

func _draw_tomato_plant(anchor: Vector2, max_size: Vector2) -> Rect2:
	var source := _tomato_stem_source()
	var plant := _grounded_rect(source, anchor, max_size)
	draw_texture_rect_region(GROWTH_ART[2], plant, source)
	# Fruits hang beside the branch junctions, leaving the main stem visible.
	for fruit in [Vector3(0.33, 0.45, 0.30), Vector3(0.69, 0.32, 0.27), Vector3(0.62, 0.67, 0.25)]:
		var diameter: float = plant.size.x * fruit.z
		var center := plant.position + plant.size * Vector2(fruit.x, fruit.y)
		_draw_sprite(RIPE_ART[2], Rect2(center - Vector2.ONE * diameter * 0.5, Vector2.ONE * diameter))
	return plant

func _draw_hud(size: Vector2) -> void:
	var layout := _layout(size)
	var pad := size.x * 0.04
	var top: float = layout.top_h * 0.2
	draw_rect(Rect2(0, 0, size.x, layout.top_h), Color(0.02, 0.07, 0.03, 0.72))
	_text("¥ %d" % int(money_display), Vector2(pad, top + 30), 30, Color.WHITE)
	var remain := maxi(0, int(run_seconds - elapsed))
	_text_center("%02d:%02d" % [remain / 60, remain % 60], Vector2(size.x * 0.5, top + 30), 30, Color.WHITE)
	_draw_sprite(PARTS[9], Rect2(size.x - pad - 156, top - 14, 50, 50))
	_text("%d" % basket.size(), Vector2(size.x - pad - 96, top + 30), 30, Color("bfe7c8"))
	_text(WEATHER_NAMES.get(weather, weather), Vector2(pad, top + 68), 26, Color("cfe3ff"))
	for pop in money_pop:
		_text_center("+¥%d" % int(pop.value), Vector2(size.x * 0.5, top + 76), 28, Color("ffe08a"))

func _draw_harvest_fx(size: Vector2) -> void:
	var layout := _layout(size)
	var pad := size.x * 0.04
	var target := Vector2(size.x - pad - 131.0, layout.top_h * 0.2 + 11.0)
	for fx in harvest_fx:
		var progress: float = 1.0 - fx.life / 0.5
		var position: Vector2 = fx.origin.lerp(target, progress)
		position.y -= sin(progress * PI) * 85.0
		var diameter := lerpf(54.0, 20.0, progress)
		var texture: Texture2D = RIPE_ART[fx.crop_id]
		var source := _art_bounds(texture)
		var scale := diameter / maxf(source.size.x, source.size.y)
		var sprite_size := source.size * scale
		var color := Color("ffe08a") if fx.variant == 2 else Color.WHITE
		draw_texture_rect_region(texture, Rect2(position - sprite_size * 0.5, sprite_size), source, color)

func _draw_rack(size: Vector2) -> void:
	var layout := _layout(size)
	var rect := _rack_rect(size)
	draw_rect(rect, Color(0.02, 0.05, 0.03, 0.78))
	_draw_nine(PARTS[2], rect)
	var item := _rack_item_size(layout)
	var spacing := _rack_spacing(layout)
	var y := rect.position.y + (rect.size.y - item.y) * 0.5
	var first := _rack_first_index()
	for i in range(first, mini(CROPS.size(), first + _rack_visible_count(size))):
		var x := 16.0 + (i - first) * spacing
		var crop: Dictionary = CROPS[i]
		var box := Rect2(Vector2(x, y), item)
		var affordable: bool = money >= crop.seed
		_draw_sprite(PARTS[1], box)
		if i == selected_seed:
			draw_rect(box.grow(-3.0), Color("ffe08a"), false, 4.0)
		var band_top := y + item.y * 0.66
		var icon := Rect2(x + 48.0, y + 12.0, 94.0, band_top - y - 27.0)
		_draw_sprite(RIPE_ART[i], icon)
		if not affordable:
			draw_rect(icon, Color(0.03, 0.04, 0.03, 0.45))
		var band := Rect2(x + 25.0, band_top, item.x - 50.0, item.y - (band_top - y) - 7.0)
		draw_rect(band, Color("f9e9c2"))
		var name_size := 24
		while GAME_FONT.get_string_size(crop.name, HORIZONTAL_ALIGNMENT_LEFT, -1, name_size).x > band.size.x - 4.0 and name_size > 20:
			name_size -= 1
		_text_center(crop.name, Vector2(x + item.x * 0.5, band_top + 22.0), name_size, Color("342314"))
		_text_center("¥%d" % int(crop.seed), Vector2(x + item.x * 0.5, band_top + 51.0), 24, Color("46321d"))
	var arrow_x := size.x - 41.0
	var arrow_top := rect.position.y + rect.size.y * 0.34
	var arrow_bottom := rect.position.y + rect.size.y * 0.8
	_text_center("←", Vector2(arrow_x, arrow_top), 30, Color("ffe08a") if first > 0 else Color("918366"))
	_text_center("→", Vector2(arrow_x, arrow_bottom), 30, Color("ffe08a") if first + _rack_visible_count(size) < CROPS.size() else Color("918366"))

func _draw_buttons(size: Vector2) -> void:
	var ship_rect := _ship_button_rect(size)
	var shop_rect := _shop_button_rect(size)
	draw_style_box(ship_button_style, ship_rect)
	_text_center("出荷", ship_rect.position + ship_rect.size * 0.5 + Vector2(0, 10), 30, Color.WHITE)
	draw_style_box(shop_button_style, shop_rect)
	_text_center("お店", shop_rect.position + shop_rect.size * 0.5 + Vector2(0, 10), 30, Color("35220e"))

func _draw_shop(size: Vector2) -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.0, 0.0, 0.0, 0.72))
	var panel := _shop_panel_rect(size)
	_draw_nine(PARTS[5], panel, 30.0)
	_text("お店", panel.position + Vector2(28, 52), 32, Color.WHITE)
	var close := _shop_close_rect(size)
	_draw_nine(PARTS[7], close)
	_text_center("×", close.get_center() + Vector2(0, 16), 48, Color.WHITE)
	var items := _shop_items()
	for i in items.size():
		var rect := _shop_item_rect(size, i)
		if rect.position.y < panel.position.y + 98.0 or rect.end.y > panel.end.y - 8.0:
			continue
		var item: Dictionary = items[i]
		_draw_nine(PARTS[6], rect)
		if item.type == "tool":
			_draw_sprite(PARTS[11 + i - 1], Rect2(rect.position + Vector2(12, 20), Vector2(70, 78)))
		_text(item.label, rect.position + Vector2(94, 39), 26, Color("2d2115"))
		_draw_shop_description(item.desc, rect.position + Vector2(94, 77), 26, rect.size.x - 112.0)
		if item.done:
			_text(("済" if item.type == "tool" else "最大"), rect.position + Vector2(rect.size.x - 75, 39), 26, Color("26573a"))
		else:
			var affordable: bool = money >= item.cost
			_text("¥%d" % int(item.cost), rect.position + Vector2(rect.size.x - 110, 39), 26, Color("2d2115") if affordable else Color("9b3f32"))

func _draw_shop_description(value: String, position: Vector2, font_size: int, max_width: float) -> void:
	var line := ""
	var y := position.y
	for character in value:
		if GAME_FONT.get_string_size(line + character, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x > max_width and not line.is_empty():
			_text(line, Vector2(position.x, y), font_size, Color("493622"))
			line = ""
			y += 30.0
		line += character
	if not line.is_empty():
		_text(line, Vector2(position.x, y), font_size, Color("493622"))

func _draw_title(size: Vector2) -> void:
	var center := size * 0.5
	draw_rect(Rect2(center - Vector2(minf(size.x * 0.46, 420), 330), Vector2(minf(size.x * 0.92, 840), 690)), Color(0.015, 0.07, 0.04, 0.72))
	_draw_sprite(PARTS[10], Rect2(center + Vector2(-100, -300), Vector2(200, 130)))
	_text_center("ほったら菜園", center + Vector2(0, -130), 50, Color.WHITE)
	_text_center("種をまいたら、あとは待つだけ", center + Vector2(0, -74), 28, Color("f4f3d9"))
	_text_center("1シーズン = 6分", center + Vector2(0, 25), 30, Color("ffe08a"))
	_text_center("自己ベスト  ¥%d" % int(best_earned), center + Vector2(0, 82), 28, Color("bfe7c8"))
	_draw_button(center + Vector2(0, 185), "タップしてはじめる", true)
	_text_center("種を選んで畑をタップ", center + Vector2(0, 270), 26, Color.WHITE)
	_text_center("なぞって連続操作", center + Vector2(0, 306), 26, Color.WHITE)

func _draw_result(size: Vector2) -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.0, 0.0, 0.0, 0.78))
	var center := size * 0.5
	_text_center("この6分の収穫", center + Vector2(0, -230), 34, Color("ffe08a"))
	_text_center("稼いだ合計   ¥%d" % int(earned), center + Vector2(0, -150), 28, Color.WHITE)
	_text_center("収穫数        %d" % harvested, center + Vector2(0, -100), 28, Color.WHITE)
	var top_name: String = (CROPS[top_crop_id].name if top_crop_id >= 0 else "-")
	_text_center("一番高い作物  %s" % top_name, center + Vector2(0, -50), 28, Color.WHITE)
	_text_center("きらめきの数  %d" % sparkles, center + Vector2(0, 0), 28, Color("ffe08a"))
	_text_center("自己ベスト    ¥%d" % int(best_earned), center + Vector2(0, 60), 28, Color("bfe7c8"))
	_draw_button(center + Vector2(0, 200), "もう一度")

func _draw_button(center: Vector2, label: String, preserve_ratio: bool = false) -> void:
	if not preserve_ratio:
		draw_style_box(start_button_style, Rect2(center - Vector2(255, 42), Vector2(510, 84)))
		_text_center(label, center + Vector2(52, 10), 28, Color("173149"))
		return
	var texture := PARTS[8]
	var source_size := texture.get_size()
	var rect := Rect2(center - Vector2(255, 65), Vector2(510, 130))
	var scale := rect.size.y / source_size.y
	var left_source := 118.0
	var right_source := 35.0
	var left_width := left_source * scale
	var right_width := right_source * scale
	draw_texture_rect_region(texture, Rect2(rect.position, Vector2(left_width, rect.size.y)), Rect2(Vector2.ZERO, Vector2(left_source, source_size.y)))
	draw_texture_rect_region(texture, Rect2(rect.position + Vector2(left_width, 0), Vector2(rect.size.x - left_width - right_width, rect.size.y)), Rect2(Vector2(left_source, 0), Vector2(source_size.x - left_source - right_source, source_size.y)))
	draw_texture_rect_region(texture, Rect2(rect.end - Vector2(right_width, rect.size.y), Vector2(right_width, rect.size.y)), Rect2(Vector2(source_size.x - right_source, 0), Vector2(right_source, source_size.y)))
	_text_center(label, center + Vector2(52, 10), 28, Color("173149"))

func _text(value: String, position: Vector2, font_size: int, color: Color) -> void:
	draw_string(GAME_FONT, position, value, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, color)

func _text_center(value: String, position: Vector2, font_size: int, color: Color) -> void:
	var width := GAME_FONT.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	_text(value, position - Vector2(width * 0.5, 0.0), font_size, color)
