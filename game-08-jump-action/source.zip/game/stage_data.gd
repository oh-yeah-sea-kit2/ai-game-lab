class_name StageData
## 面のデータと地形の当たり判定クエリ。
##
## 実装メモ（BUILD-LOG参照）: 仕様は「面ごとの文字列（1文字＝1マス）」からTileMapLayerを組み立てることを
## 求めている。1面が60〜90秒（速度240〜300px/s、タイル64px）だと260〜350マスの横長文字列になるため、
## 生のASCIIアートを直接手打ちすると「面の追加・改造が文字列の編集で済む」という目的にかえって反する。
## そこで `_Builder`（区間の長さ・高さ・地物を順番に積む小さなDSL）で `ground` / `overlay` という
## 1面1本の文字列（1文字＝1マス、0-9=高さ・"."=穴）を組み立てる。最終的にTileMapLayer構築に渡るのは
## この文字列そのもの。動く足場・上がる足場・かみ鳥だけは高さ・振れ幅・周期という数値パラメータが
## 要るため `bands`（構造化リスト）で持つ（文字1つでは表現できないための判断）。

const TILE := Tuning.TILE

var stage_name: String
var theme: String
var speed_base: float
var ground: String
var overlay: String
var bands: Array = []
var cols: int
var length_px: float
var start_x: float
var checkpoint_x: float
var goal_x: float

func _init(b: _Builder) -> void:
	stage_name = b.stage_name
	theme = b.theme
	speed_base = b.speed_base
	ground = b.ground
	overlay = b.overlay
	bands = b.bands
	cols = ground.length()
	length_px = cols * TILE
	start_x = b.start_x
	checkpoint_x = b.checkpoint_x
	goal_x = b.goal_x

# ---------------------------------------------------------------- 地形クエリ

func col_at(x: float) -> int:
	return clampi(int(floor(x / TILE)), 0, cols - 1)

## 高さ（タイル数）。穴なら -1。
func height_at_col(c: int) -> int:
	if c < 0 or c >= cols:
		return 0
	var ch := ground[c]
	if ch == ".":
		return -1
	return ch.to_int()

func height_at_x(x: float) -> int:
	return height_at_col(col_at(x))

## 地面の表面 y（足元の位置）。穴なら NAN。
## 段差（高さの違う列がとなり合う所）は、境目をまたぐ 1 マス幅で滑らかな坂として
## つなぐ（ジャンプなしで登れる小さな段差にするための実装上の判断。BUILD-LOG参照）。
## 穴に接する側は坂にせず、そのマスの高さのまま急に切れる（穴は跳んで越える対象のため）。
func surface_y_at_x(x: float) -> float:
	var c := col_at(x)
	var h := height_at_col(c)
	if h < 0:
		return NAN
	var center := (float(c) + 0.5) * TILE
	var t := (x - center) / TILE
	var neighbor := c + 1 if t > 0.0 else c - 1
	var hn := height_at_col(neighbor)
	if hn < 0 or neighbor < 0 or neighbor >= cols:
		return -float(h) * TILE
	var tt := clampf(absf(t), 0.0, 0.5) * 2.0
	var h_interp := lerpf(float(h), float(hn), tt)
	return -h_interp * TILE

func overlay_at_x(x: float) -> String:
	var c := col_at(x)
	if c < 0 or c >= overlay.length():
		return "."
	return overlay[c]

func speed_mult_at_x(x: float) -> float:
	var ch := overlay_at_x(x)
	if ch == "a":
		return Tuning.WIND_MULT
	if ch == "d":
		return Tuning.MUD_MULT
	return 1.0

func is_spring_at_x(x: float) -> bool:
	return overlay_at_x(x) == "^"

func is_crumble_col(c: int) -> bool:
	if c < 0 or c >= overlay.length():
		return false
	return overlay[c] == "c"

# ---------------------------------------------------------------- 建設用DSL

class _Builder:
	var stage_name: String
	var theme: String
	var speed_base: float
	var ground := ""
	var overlay := ""
	var bands: Array = []
	var col := 0
	var start_x := 0.0
	var checkpoint_x := 0.0
	var goal_x := 0.0

	func _init(n: String, th: String, speed: float) -> void:
		stage_name = n
		theme = th
		speed_base = speed

	## 平らな区間。marks は {区間内の相対列: 文字}（n/s/t/w/^/c/K/G/S など）。
	func seg(h: int, n: int, marks: Dictionary = {}) -> _Builder:
		var ov := PackedStringArray()
		ov.resize(n)
		for i in n:
			ov[i] = "."
		for k in marks:
			ov[int(k)] = marks[k]
		ground += str(h).repeat(n)
		overlay += "".join(ov)
		col += n
		return self

	## 速度ゾーン（風の坂 "a" / ぬかるみ "d"）。区間全体が高さ h の地面。
	func zone(h: int, n: int, ch: String) -> _Builder:
		ground += str(h).repeat(n)
		overlay += ch.repeat(n)
		col += n
		return self

	## 穴（地面なし）。
	func gap(n: int) -> _Builder:
		ground += ".".repeat(n)
		overlay += ".".repeat(n)
		col += n
		return self

	## 崩れる足場（高さ h、n マス。踏むと少し後に消え、しばらくして復活する）。
	func crumble(h: int, n: int) -> _Builder:
		ground += str(h).repeat(n)
		overlay += "c".repeat(n)
		col += n
		return self

	## いま位置から offset マス先に、幅 w・高さ height（タイル）の要素を積む。
	func band_here(offset: int, type: String, w: int, height: float, extra: Dictionary = {}) -> _Builder:
		var d := {"type": type, "x": float(col + offset) * TILE, "w": float(w) * TILE, "height": height}
		for k in extra:
			d[k] = extra[k]
		bands.append(d)
		return self

	func mark_start() -> _Builder:
		start_x = float(col) * TILE
		return self

	func mark_checkpoint() -> _Builder:
		checkpoint_x = float(col) * TILE
		return self

	func mark_goal() -> _Builder:
		goal_x = float(col) * TILE
		return self

	func build() -> StageData:
		return StageData.new(self)

# ---------------------------------------------------------------- 4面のデータ

static func build_all() -> Array:
	var out: Array = []
	out.append(_stage1_hill())
	out.append(_stage2_cave())
	out.append(_stage3_clouds())
	out.append(_stage4_port())
	return out

## 障害物（穴・とげ貝・ぬめ虫）を跳んで越えた「あと」、次の障害物までに必ず空ける
## 最小のマス数。着地地点の直後にすぐ次の敵の当たり判定が始まると、2段ジャンプ要らずの
## はずの跳躍が「その先も安全か」の確認に引っかかって無駄な2段ジャンプへ化け、
## かえって届かなくなる不具合が実際に起きた（BUILD-LOG参照）。着地後に十分走れる
## 距離を必ず空けることで、跳躍1回・着地1回が単純に完結するようにする。
const SAFE_GAP := 22

## 1面目「丘」— 段差・穴・ばね草・ぬめ虫・とげ貝・風の坂。速度 240px/s。
static func _stage1_hill() -> StageData:
	var b := _Builder.new("かざぐるま丘", "hill", 240.0)
	# 初回だけ、敵に会う前に約10秒走れる平地と安全に拾えるたねを置く。
	b.seg(1, 26, {2: "S", 6: "U", 8: "t", 16: "t"}) # 開始数秒、ジャンプで拾える種のまとまり
	b.seg(1, SAFE_GAP, {11: "n", 15: "t"})
	b.seg(2, SAFE_GAP, {2: "t"})                 # 段差（上り。坂として自動でつながる）
	b.seg(2, 10, {})
	b.gap(2)                                     # 穴（2マス）
	b.seg(2, SAFE_GAP, {2: "t", 3: "t"})
	b.seg(1, SAFE_GAP, {11: "s", 15: "t"})          # とげ貝は跳び越える（段差は坂で下る）
	b.zone(1, 10, "a")                           # 風の坂（加速）
	b.seg(1, 10, {})
	b.gap(2)
	b.seg(1, SAFE_GAP, {11: "n", 15: "t"})
	b.mark_checkpoint()
	b.seg(1, 4, {1: "K"})
	b.seg(1, SAFE_GAP, {})                       # ばね草は着地して踏まないと発動しないので、
	                                              # 直前のジャンプの着地点が坂の上に来ないよう広く空ける
	b.seg(1, 4, {0: "^"})                        # ばね草
	b.gap(3)                                     # ばね草で越える広めの穴
	b.seg(1, SAFE_GAP, {2: "t", 3: "t"})          # 着地は広く安全に
	b.seg(1, SAFE_GAP, {11: "s", 15: "t"})
	b.seg(1, 10, {})
	b.gap(2)
	b.seg(1, SAFE_GAP, {})
	b.band_here(8, "platform", 4, 3.0)            # 上がる足場（安全な区間の頭上。任意の寄り道）
	b.seg(1, 8, {3: "G"})
	b.mark_goal()
	b.seg(1, 6, {})
	return b.build()

## 2面目「洞くつ」— 上がる足場・穴・とげ貝・ぬかるみ。速度 260px/s。
static func _stage2_cave() -> StageData:
	var b := _Builder.new("風なりの洞くつ", "cave", 260.0)
	b.seg(1, 8, {2: "S"})
	b.seg(1, SAFE_GAP, {11: "n", 15: "t"})
	b.seg(1, 10, {})
	b.gap(2)
	b.seg(1, SAFE_GAP, {2: "t", 3: "t"})
	b.band_here(10, "platform", 4, 2.0)           # 上がる足場（安全な区間の頭上。任意の寄り道）
	b.seg(1, SAFE_GAP, {11: "s", 15: "t"})
	b.zone(1, 12, "d")                            # ぬかるみ（減速）
	b.seg(1, 10, {})
	b.gap(2)
	b.seg(1, SAFE_GAP, {11: "n", 15: "t"})
	b.mark_checkpoint()
	b.seg(1, 4, {1: "K"})
	b.seg(1, SAFE_GAP, {11: "s", 15: "t"})
	b.seg(1, 10, {})
	b.gap(2)
	b.seg(1, SAFE_GAP, {})
	b.crumble(1, 6)                               # 崩れる足場（自動走行で通り過ぎるだけの飾り）
	b.seg(1, SAFE_GAP, {11: "n", 15: "t", 16: "t"})
	b.seg(1, SAFE_GAP, {6: "t", 12: "t"})
	b.seg(1, 8, {3: "G"})
	b.mark_goal()
	b.seg(1, 6, {})
	return b.build()

## 3面目「雲の上」— 動く足場・かみ鳥・穴の多い足場飛び。速度 280px/s。
static func _stage3_clouds() -> StageData:
	var b := _Builder.new("雲の上のみち", "clouds", 280.0)
	b.seg(2, 12, {2: "S"})
	b.seg(2, SAFE_GAP, {3: "t", 7: "t"})
	b.band_here(4, "bird", 0, 7.0)                # かみ鳥は高い所を飛ぶ（見せ場・当たらない高さ）
	b.seg(2, 10, {})
	b.gap(2)
	b.seg(2, SAFE_GAP, {3: "t"})
	b.band_here(6, "moving", 3, 5.5, {"amp": 100.0, "period": 2.4, "axis": "x"})  # 動く足場（頭上の寄り道）
	b.seg(2, SAFE_GAP, {2: "t", 3: "t"})
	b.seg(2, SAFE_GAP, {11: "n", 15: "t"})
	b.mark_checkpoint()
	b.seg(2, 4, {1: "K"})
	b.seg(2, SAFE_GAP, {})
	b.band_here(4, "bird", 0, 7.0)
	b.seg(2, SAFE_GAP, {6: "t"})
	b.gap(2)
	b.seg(2, SAFE_GAP, {2: "t"})
	b.band_here(6, "moving", 3, 5.5, {"amp": 90.0, "period": 2.6, "axis": "y"})
	b.seg(2, SAFE_GAP, {11: "n", 15: "t"})
	b.seg(2, SAFE_GAP, {6: "t", 14: "t"})
	b.seg(2, SAFE_GAP, {11: "n", 15: "t"})
	b.seg(2, 8, {3: "G"})
	b.mark_goal()
	b.seg(2, 6, {})
	return b.build()

## 4面目「夕暮れの港」— 崩れる足場・風の坂・とげ貝＋かみ鳥・風のお守り。速度 300px/s。
static func _stage4_port() -> StageData:
	var b := _Builder.new("夕暮れの港", "port", 300.0)
	b.seg(1, 8, {2: "S"})
	b.seg(1, SAFE_GAP, {2: "w", 6: "t"})          # 風のお守り
	b.seg(1, 10, {})
	b.gap(2)
	b.seg(1, SAFE_GAP, {11: "s", 15: "t"})
	b.band_here(10, "bird", 0, 7.0)
	b.crumble(1, 6)                                # 崩れる足場
	b.seg(1, SAFE_GAP, {11: "n", 15: "t"})
	b.mark_checkpoint()
	b.seg(1, 4, {1: "K"})
	b.zone(1, 12, "a")                             # 風の坂（加速）
	b.seg(1, 10, {})
	b.gap(2)
	b.seg(1, SAFE_GAP, {11: "s", 15: "t"})
	b.band_here(10, "platform", 4, 3.0)
	b.seg(1, SAFE_GAP, {6: "t"})
	b.gap(2)
	b.seg(1, SAFE_GAP, {11: "n", 15: "t"})
	b.zone(1, 10, "a")
	b.seg(1, SAFE_GAP, {2: "t", 6: "t"})
	b.seg(1, SAFE_GAP, {11: "s", 15: "t"})
	b.seg(1, SAFE_GAP, {6: "t", 14: "t"})
	b.seg(1, 10, {})
	b.seg(1, 8, {3: "G"})
	b.mark_goal()
	b.seg(1, 6, {})
	return b.build()
