class_name Fx
## 使い捨てのパーティクル効果。呼ぶたびに1つ生成して自動で消える。

const DUST := preload("res://art/scenery_ui_fx_12.png")
const STOMP := preload("res://art/scenery_ui_fx_13.png")
const SPARKLE := preload("res://art/scenery_ui_fx_14.png")
const BELL := preload("res://art/scenery_ui_fx_15.png")

static func burst(parent: Node, pos: Vector2, color: Color, amount: int, speed: float, life: float, size: float, texture: Texture2D = null) -> void:
	var p := CPUParticles2D.new()
	p.position = pos
	p.one_shot = true
	p.amount = amount
	p.lifetime = life
	p.explosiveness = 1.0
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = 6.0
	p.direction = Vector2.UP
	p.spread = 180.0
	p.gravity = Vector2(0, 420)
	p.initial_velocity_min = speed * 0.5
	p.initial_velocity_max = speed
	p.texture = texture
	var unit := float(texture.get_width()) if texture != null else 1.0
	p.scale_amount_min = size * 0.6 / unit
	p.scale_amount_max = size / unit
	p.color = color
	p.emitting = true
	parent.add_child(p)
	parent.get_tree().create_timer(life + 0.2).timeout.connect(p.queue_free)

static func dust(parent: Node, pos: Vector2) -> void:
	burst(parent, pos, Color(1, 1, 1, 0.7), 4, 90.0, 0.4, 12.0, DUST)

static func stomp(parent: Node, pos: Vector2, color: Color) -> void:
	burst(parent, pos, Color.WHITE, 10, 220.0, 0.5, 16.0, STOMP)

static func sparkle(parent: Node, pos: Vector2) -> void:
	burst(parent, pos, Color.WHITE, 12, 180.0, 0.55, 13.0, SPARKLE)

static func bell(parent: Node, pos: Vector2) -> void:
	burst(parent, pos, Color.WHITE, 26, 320.0, 0.9, 20.0, BELL)

static func popup(parent: Node, pos: Vector2, text: String, color: Color) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 28)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0.05, 0.05, 0.1))
	l.add_theme_constant_override("outline_size", 5)
	l.position = pos + Vector2(-40, -20)
	parent.add_child(l)
	var tw := l.create_tween()
	tw.tween_property(l, "position:y", l.position.y - 50, 0.7)
	tw.parallel().tween_property(l, "modulate:a", 0.0, 0.7)
	tw.tween_callback(l.queue_free)
