extends Node2D
## かざぐるま丘ラン — 本体。横スクロールのジャンプアクション。
## 主人公クルリは自動で右へ走り続け、プレイヤーはジャンプの時機と高さだけを決める。

const ErrorCounter := preload("res://error_counter.gd")
const EnemyNode := preload("res://enemy_node.gd")
const PickupNode := preload("res://pickup_node.gd")
const PlatformNode := preload("res://platform_node.gd")
const TerrainNode := preload("res://terrain_node.gd")
const BackgroundNode := preload("res://background_node.gd")
const TERRAIN := [
	preload("res://art/terrain_00.png"), preload("res://art/terrain_01.png"),
	preload("res://art/terrain_02.png"), preload("res://art/terrain_03.png"),
	preload("res://art/terrain_04.png"), preload("res://art/terrain_05.png"),
	preload("res://art/terrain_06.png"), preload("res://art/terrain_07.png"),
	preload("res://art/terrain_08.png"), preload("res://art/terrain_09.png"),
	preload("res://art/terrain_10.png"),
]
const CHECKPOINT := preload("res://art/props_02.png")
const GOAL := preload("res://art/props_03.png")
const SPRING := preload("res://art/props_04.png")
const PANEL_ART := preload("res://art/scenery_ui_fx_08.png")
const BUTTON_ART := preload("res://art/scenery_ui_fx_09.png")
const LIFE_ART := preload("res://art/scenery_ui_fx_10.png")
const CHARM_STATUS_ART := preload("res://art/scenery_ui_fx_11.png")

const TILE := Tuning.TILE
const TILE_I := int(Tuning.TILE)
const FILL_BOTTOM := 10
const BEST_PATH := "user://best.json"
const STAGE_TIMEOUT := 240.0  # この秒数で面をクリアできなければ不具合として打ち切る

enum State { TITLE, PLAY, RESULT }

var state := State.TITLE
var logger: ErrorCounter
var rng := RandomNumberGenerator.new()

# CLI
var autoplay := false
var demo := false
var demo_wait := 0.0
var goal_pause := 0.0
var start_stage := 0        # 0始まり
var timescale := 1

var stages: Array = []
var stage_index := 0
var cur_stage: StageData
var sim: KuruliSim.State
var stage_time := 0.0
var respawn_x := 0.0
var checkpoint_passed := false
var autoplay_ctrl: Autoplay
var anomalies := 0

var lives := Tuning.LIVES_MAX
var shield := false
var invuln_timer := 0.0
var seeds_collected := 0
var stomps := 0
var misses := 0
var jumps := 0
var total_time := 0.0
var stages_cleared := 0
var run_cleared := false
var finished := false

var enemies: Array = []
var pickups: Array = []
var moving_nodes: Array = []

var best := {"time_sec": 0.0, "seeds": 0}

# 入力
var held := false
var press_pending := false
var swipe_pending := false
var swipe_origin := Vector2.ZERO
var swipe_time_ms := 0

# ノード
var world: Node2D
var background: Node2D
var tile_layer: TileMapLayer
var terrain_visual: Node2D
var entities_root: Node2D
var fx_root: Node2D
var player: CharacterBody2D
var ui_layer: CanvasLayer
var title_panel: Control
var result_panel: Control
var hud: Control
var hud_lives: Label
var hud_seeds: Label
var hud_stage: Label
var hud_timer: Label
var hud_life_icons: Array[TextureRect] = []
var hud_charm_icon: PanelContainer
var result_label: Label
var title_best_label: Label
var shake_timer := 0.0
var flash_rect: ColorRect

func _ready() -> void:
	logger = ErrorCounter.new()
	OS.add_logger(logger)
	stages = StageData.build_all()
	_parse_args()
	if OS.has_feature("web"):
		var query := str(JavaScriptBridge.eval("window.location.search"))
		for param in query.trim_prefix("?").split("&"):
			if param == "demo=1":
				demo = true
				break
	_load_best()
	_build_scene()
	get_viewport().size_changed.connect(_layout)
	_layout()
	if autoplay:
		_start_run()
	else:
		_show_title()

func _process(delta: float) -> void:
	if not demo or demo_wait <= 0.0:
		return
	demo_wait -= delta
	if demo_wait <= 0.0 and (state == State.TITLE or state == State.RESULT):
		_start_run()

func _parse_args() -> void:
	var args := OS.get_cmdline_user_args()
	args.append_array(OS.get_cmdline_args())
	var seed_val := int(Time.get_unix_time_from_system())
	for a in args:
		if a == "--autoplay":
			autoplay = true
		elif a.begins_with("--seed="):
			seed_val = int(a.get_slice("=", 1))
		elif a.begins_with("--stage="):
			start_stage = clampi(int(a.get_slice("=", 1)) - 1, 0, stages.size() - 1)
		elif a.begins_with("--timescale="):
			timescale = maxi(1, int(a.get_slice("=", 1)))
	rng.seed = seed_val

# ---------------------------------------------------------------- 組み立て

func _build_scene() -> void:
	background = BackgroundNode.new()
	add_child(background)
	world = Node2D.new()
	world.name = "World"
	add_child(world)

	tile_layer = TileMapLayer.new()
	world.add_child(tile_layer)
	# 面の文字列から組む TileMapLayer は残す。見た目だけ連続した帯へ差し替える。
	tile_layer.visible = false
	terrain_visual = TerrainNode.new()
	world.add_child(terrain_visual)

	entities_root = Node2D.new()
	world.add_child(entities_root)

	fx_root = Node2D.new()
	world.add_child(fx_root)

	player = CharacterBody2D.new()
	player.set_script(load("res://kuruli_node.gd"))
	world.add_child(player)

	flash_rect = ColorRect.new()
	flash_rect.color = Color(1, 1, 1, 0.0)
	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	flash_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(flash_rect)

	_build_ui()

func _layout() -> void:
	background.update_bounds()
	var bounds: Rect2 = background.visible_area
	# 縦長では画面下の地面を減らし、クルリを大きく見せる。横長の値は従来どおり。
	var portrait := bounds.size.y > bounds.size.x
	world.scale = Vector2.ONE * (1.6 if portrait else 1.2)
	if sim != null:
		_update_visuals()
	else:
		world.position = Vector2(bounds.position.x + bounds.size.x / 3.0, bounds.end.y - bounds.size.y * (0.24 if portrait else 0.32))

# ---------------------------------------------------------------- UI

func _label(size: int, col: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0.05, 0.05, 0.1))
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(320, 96)
	b.add_theme_font_size_override("font_size", 38)
	var sb := StyleBoxTexture.new()
	sb.texture = BUTTON_ART
	sb.texture_margin_left = 44
	sb.texture_margin_right = 44
	sb.texture_margin_top = 40
	sb.texture_margin_bottom = 40
	b.add_theme_stylebox_override("normal", sb)
	var sbh := sb.duplicate() as StyleBoxTexture
	sbh.modulate_color = Color(1.1, 1.1, 1.1)
	b.add_theme_stylebox_override("hover", sbh)
	var sbp := sb.duplicate() as StyleBoxTexture
	sbp.modulate_color = Color(0.84, 0.84, 0.84)
	b.add_theme_stylebox_override("pressed", sbp)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", Color("2a1740"))
	b.add_theme_color_override("font_hover_color", Color("2a1740"))
	b.add_theme_color_override("font_pressed_color", Color("2a1740"))
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	return b

func _overlay() -> Control:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	var dim := ColorRect.new()
	dim.color = Color(0.03, 0.03, 0.1, 0.55)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)
	var card := PanelContainer.new()
	var sb := StyleBoxTexture.new()
	sb.texture = PANEL_ART
	sb.texture_margin_left = 40
	sb.texture_margin_right = 40
	sb.texture_margin_top = 40
	sb.texture_margin_bottom = 40
	sb.set_content_margin_all(34)
	card.add_theme_stylebox_override("panel", sb)
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.custom_minimum_size = Vector2(650, 0)
	center.add_child(card)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 18)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(box)
	root.set_meta("box", box)
	ui_layer.add_child(root)
	return root

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	ui_layer.layer = 10
	add_child(ui_layer)

	title_panel = _overlay()
	var tv := title_panel.get_meta("box") as VBoxContainer
	var t1 := _label(52, Color("ffe38a"))
	t1.text = "かざぐるま丘ラン"
	t1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tv.add_child(t1)
	var t2 := _label(26, Color.WHITE)
	t2.text = "自動で走るクルリを\n押している長さでジャンプさせよう。\n敵は上から踏み、とげ貝は跳び越え、\n鐘を鳴らそう。"
	t2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t2.autowrap_mode = TextServer.AUTOWRAP_WORD
	tv.add_child(t2)
	var t3 := _label(26, Color(0.85, 0.87, 1.0))
	t3.text = "画面を押す → ジャンプ\n空中でもう一度 → 2段ジャンプ\n下へすばやく払う → 急降下\nPC: スペース/↑、↓"
	t3.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t3.autowrap_mode = TextServer.AUTOWRAP_WORD
	tv.add_child(t3)
	title_best_label = _label(23, Color("ffe8a3"))
	title_best_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tv.add_child(title_best_label)
	_refresh_best_display()
	var b1 := _button("あそぶ")
	b1.pressed.connect(_start_run)
	tv.add_child(b1)

	result_panel = _overlay()
	var rv := result_panel.get_meta("box") as VBoxContainer
	var r1 := _label(46, Color("ffe38a"))
	r1.text = "けっか"
	r1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rv.add_child(r1)
	result_label = _label(26, Color.WHITE)
	result_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rv.add_child(result_label)
	var b2 := _button("もう一度")
	b2.pressed.connect(_start_run)
	rv.add_child(b2)
	result_panel.visible = false

	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_layer.add_child(hud)
	var hud_back := ColorRect.new()
	hud_back.color = Color(0.04, 0.05, 0.12, 0.72)
	hud_back.position = Vector2(16, 16)
	hud_back.size = Vector2(420, 184)
	hud_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(hud_back)
	hud_lives = _label(30, Color.WHITE)
	hud_lives.position = Vector2(30, 30)
	hud.add_child(hud_lives)
	for i in Tuning.LIVES_MAX:
		var icon := TextureRect.new()
		icon.texture = LIFE_ART
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.position = Vector2(134 + i * 38, 32)
		icon.size = Vector2(32, 32)
		icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hud.add_child(icon)
		hud_life_icons.append(icon)
	hud_charm_icon = PanelContainer.new()
	var ring := StyleBoxFlat.new()
	ring.bg_color = Color(0.03, 0.15, 0.22, 0.95)
	ring.border_color = Color("d4f8ff")
	ring.set_border_width_all(3)
	ring.set_corner_radius_all(24)
	ring.set_content_margin_all(4)
	hud_charm_icon.add_theme_stylebox_override("panel", ring)
	hud_charm_icon.position = Vector2(260, 24)
	hud_charm_icon.custom_minimum_size = Vector2(46, 46)
	hud_charm_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var charm_image := TextureRect.new()
	charm_image.texture = CHARM_STATUS_ART
	charm_image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	charm_image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	charm_image.custom_minimum_size = Vector2(38, 38)
	hud_charm_icon.add_child(charm_image)
	hud.add_child(hud_charm_icon)
	hud_seeds = _label(26, Color("ffe17a"))
	hud_seeds.position = Vector2(30, 70)
	hud.add_child(hud_seeds)
	hud_stage = _label(26, Color.WHITE)
	hud_stage.position = Vector2(30, 106)
	hud.add_child(hud_stage)
	hud_timer = _label(26, Color(0.85, 0.87, 1.0))
	hud_timer.position = Vector2(30, 140)
	hud.add_child(hud_timer)
	hud.visible = false

# ---------------------------------------------------------------- 進行

func _show_title() -> void:
	state = State.TITLE
	background.set_scene("hill", false)
	title_panel.visible = true
	result_panel.visible = false
	hud.visible = false
	if demo:
		demo_wait = 2.5
	_publish_web_state()

func _start_run() -> void:
	demo_wait = 0.0
	goal_pause = 0.0
	lives = Tuning.LIVES_MAX
	shield = false
	seeds_collected = 0
	stomps = 0
	misses = 0
	jumps = 0
	total_time = 0.0
	stages_cleared = 0
	run_cleared = false
	finished = false
	stage_index = start_stage
	title_panel.visible = false
	result_panel.visible = false
	hud.visible = true
	state = State.PLAY
	RenderingServer.set_default_clear_color(Color(0.53, 0.75, 0.88))
	_load_stage(stage_index)

func _load_stage(idx: int) -> void:
	cur_stage = stages[idx]
	background.set_scene(cur_stage.theme, true)
	stage_time = 0.0
	checkpoint_passed = false
	respawn_x = cur_stage.start_x
	invuln_timer = 1.0
	sim = KuruliSim.make_state(cur_stage.start_x, cur_stage)
	_build_terrain(cur_stage)
	_spawn_entities(cur_stage)
	if autoplay or demo:
		autoplay_ctrl = Autoplay.new(cur_stage, enemies + [])
	_refresh_hud()
	_publish_web_state()

# ---------------------------------------------------------------- 地形

func _theme_colors(theme: String) -> Dictionary:
	match theme:
		"hill":
			return {"surface": Color("8bc34a"), "fill": Color("6b4a2e"), "sky": Color(0.66, 0.86, 0.90)}
		"cave":
			return {"surface": Color("8a7aa0"), "fill": Color("352a44"), "sky": Color(0.09, 0.08, 0.16)}
		"clouds":
			return {"surface": Color("ffffff"), "fill": Color("cfe8ff"), "sky": Color(0.62, 0.82, 0.98)}
		_:
			return {"surface": Color("d98a4a"), "fill": Color("4a3226"), "sky": Color(0.36, 0.24, 0.34)}

func _tile_source(ts: TileSet, texture: Texture2D) -> int:
	# Atlas の1セルを64pxに合わせる。原画は preload で Web 書き出しにも入る。
	var img := texture.get_image()
	img.resize(TILE_I, TILE_I, Image.INTERPOLATE_LANCZOS)
	var src := TileSetAtlasSource.new()
	src.texture = ImageTexture.create_from_image(img)
	src.texture_region_size = Vector2i(TILE_I, TILE_I)
	src.create_tile(Vector2i.ZERO)
	return ts.add_source(src)

func _ground_decoration(texture: Texture2D, pos: Vector2, size: Vector2) -> void:
	var sprite := Sprite2D.new()
	sprite.texture = texture
	sprite.position = pos
	sprite.scale = size / texture.get_size()
	entities_root.add_child(sprite)

func _build_terrain(stage: StageData) -> void:
	tile_layer.clear()
	for n in moving_nodes:
		if is_instance_valid(n):
			n.queue_free()
	moving_nodes.clear()
	for c in entities_root.get_children():
		c.queue_free()

	var colors := _theme_colors(stage.theme)
	RenderingServer.set_default_clear_color(colors["sky"])

	var ts := TileSet.new()
	ts.tile_size = Vector2i(TILE_I, TILE_I)
	var theme_index := ["hill", "cave", "clouds", "port"].find(stage.theme)
	var surface_id := _tile_source(ts, TERRAIN[theme_index * 2])
	var fill_id := _tile_source(ts, TERRAIN[theme_index * 2 + 1])
	tile_layer.tile_set = ts
	terrain_visual.set_stage(stage, float(FILL_BOTTOM + 1) * TILE)

	for c in stage.cols:
		var h := stage.height_at_col(c)
		if h < 0:
			continue
		var ov := stage.overlay[c]
		tile_layer.set_cell(Vector2i(c, -h), surface_id, Vector2i.ZERO)
		for r in range(-h + 1, FILL_BOTTOM + 1):
			tile_layer.set_cell(Vector2i(c, r), fill_id, Vector2i.ZERO)
		if (ov == "a" or ov == "d" or ov == "c") and c % 2 == 0:
			var overlay_index := 8 if ov == "a" else (9 if ov == "d" else 10)
			_ground_decoration(TERRAIN[overlay_index], Vector2((c + 0.5) * TILE + float(c % 3 - 1) * 9.0, -h * TILE + 10), Vector2(54, 25))
		elif ov == "^":
			_ground_decoration(SPRING, Vector2((c + 0.5) * TILE, -h * TILE - 24), Vector2(64, 54))

	for band in stage.bands:
		if band["type"] == "platform":
			var n := PlatformNode.new()
			n.w = band["w"]
			n.theme_index = theme_index
			n.position = Vector2(band["x"] + band["w"] / 2.0, -band["height"] * TILE)
			entities_root.add_child(n)
		elif band["type"] == "moving":
			var n2 := PlatformNode.new()
			n2.w = band["w"]
			n2.moving = true
			entities_root.add_child(n2)
			moving_nodes.append(n2)
			n2.set_meta("band", band)

func _update_moving_platforms() -> void:
	for n in moving_nodes:
		var band: Dictionary = n.get_meta("band")
		var r := KuruliSim.band_rect_and_surface(band, stage_time)
		n.position = Vector2((r["x0"] + r["x1"]) / 2.0, r["y"])

# ---------------------------------------------------------------- 敵・収集物

func _spawn_entities(stage: StageData) -> void:
	enemies.clear()
	pickups.clear()
	for c in stage.overlay.length():
		var ch := stage.overlay[c]
		var x := (float(c) + 0.5) * TILE
		var gy := stage.surface_y_at_x(x)
		if is_nan(gy):
			continue
		match ch:
			"n":
				enemies.append({"type": "nume", "x": x, "y": gy, "alive": true})
			"s":
				enemies.append({"type": "toge", "x": x, "y": gy, "alive": true})
			"t":
				pickups.append({"type": "seed", "x": x, "y": gy - 40.0, "got": false})
			"U":
				# 開始直後にジャンプで拾えるよう、通常の短いタップ軌道上へ種を寄せて置く。
				for offset in [-32.0, 0.0, 32.0]:
					pickups.append({"type": "seed", "x": x + offset, "y": gy - 170.0, "got": false})
			"w":
				pickups.append({"type": "charm", "x": x, "y": gy - 46.0, "got": false})
	for band in stage.bands:
		match band["type"]:
			"bird":
				enemies.append({"type": "bird", "x": band["x"], "y": -band["height"] * TILE, "alive": true})

	for e in enemies:
		var n := EnemyNode.new()
		n.kind = e["type"]
		n.position = Vector2(e["x"], e["y"])
		entities_root.add_child(n)
		e["node"] = n
	for p in pickups:
		var n2 := PickupNode.new()
		n2.kind = p["type"]
		n2.position = Vector2(p["x"], p["y"])
		entities_root.add_child(n2)
		p["node"] = n2

	_make_marker(Vector2(cur_stage.checkpoint_x, cur_stage.surface_y_at_x(cur_stage.checkpoint_x)), "checkpoint")
	_make_marker(Vector2(cur_stage.goal_x, cur_stage.surface_y_at_x(cur_stage.goal_x)), "goal")

func _make_marker(pos: Vector2, kind: String) -> void:
	var n := Node2D.new()
	n.position = pos
	entities_root.add_child(n)
	var sprite := Sprite2D.new()
	sprite.texture = CHECKPOINT if kind == "checkpoint" else GOAL
	var size := Vector2(76, 100) if kind == "checkpoint" else Vector2(100, 112)
	sprite.scale = size / sprite.texture.get_size()
	sprite.position = Vector2(0, -size.y * 0.5)
	n.add_child(sprite)

# ---------------------------------------------------------------- 入力

func _unhandled_input(event: InputEvent) -> void:
	if state != State.PLAY or autoplay or demo:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			held = true
			press_pending = true
			swipe_origin = event.position
			swipe_time_ms = Time.get_ticks_msec()
		else:
			held = false
	elif event is InputEventScreenTouch:
		if event.pressed:
			held = true
			press_pending = true
			swipe_origin = event.position
			swipe_time_ms = Time.get_ticks_msec()
		else:
			held = false
	elif event is InputEventMouseMotion:
		if held:
			_check_swipe(event.position)
	elif event is InputEventScreenDrag:
		if held:
			_check_swipe(event.position)
	elif event is InputEventKey and not event.echo:
		if event.keycode == KEY_SPACE or event.keycode == KEY_UP:
			if event.pressed:
				held = true
				press_pending = true
			else:
				held = false
		elif event.keycode == KEY_DOWN and event.pressed:
			swipe_pending = true

func _check_swipe(pos: Vector2) -> void:
	var dy := pos.y - swipe_origin.y
	var dt_ms := Time.get_ticks_msec() - swipe_time_ms
	if dy >= Tuning.SWIPE_MIN_PX and dt_ms <= Tuning.SWIPE_MAX_MS:
		swipe_pending = true

# ---------------------------------------------------------------- 毎ティック

func _physics_process(delta: float) -> void:
	if state != State.PLAY or finished:
		return
	if goal_pause > 0.0:
		goal_pause -= delta
		_update_visuals()
		if goal_pause <= 0.0:
			_advance_after_goal()
		return
	var dt := 1.0 / Tuning.PHYSICS_FPS
	for i in timescale:
		_play_tick(dt)
		if finished:
			break

func _play_tick(dt: float) -> void:
	var action: Dictionary
	if autoplay or demo:
		action = autoplay_ctrl.decide(sim, stage_time, dt)
	else:
		action = {"press": press_pending, "hold": held, "swipe": swipe_pending}
	press_pending = false
	swipe_pending = false

	KuruliSim.step(sim, dt, cur_stage, stage_time, action)
	stage_time += dt
	total_time += dt
	invuln_timer = maxf(0.0, invuln_timer - dt)

	if sim.just_jumped or sim.just_double:
		jumps += 1
		player.pop_jump()
	if sim.just_landed:
		player.pop_land()
	if sim.just_sprang:
		player.pop_jump()
		Fx.burst(fx_root, Vector2(sim.x, sim.y), Color("bff7d0"), 10, 260.0, 0.5, 5.0)

	if is_nan(sim.x) or is_nan(sim.y) or is_inf(sim.x) or is_inf(sim.y):
		anomalies += 1
		push_warning("クルリの位置が異常: x=%s y=%s" % [sim.x, sim.y])
		sim.x = respawn_x
		sim.y = cur_stage.surface_y_at_x(respawn_x)
		sim.vy = 0.0
		sim.on_ground = true

	_update_moving_platforms()
	_check_hazards()
	_check_pickups()
	_check_checkpoint_goal()

	if sim.on_ground and fmod(stage_time, 0.12) < dt:
		Fx.dust(fx_root, Vector2(sim.x, sim.y))

	if stage_time > STAGE_TIMEOUT:
		anomalies += 1
		push_warning("面のタイムアウト: 自動プレイでも越えられない場所がある可能性")
		_finish_run(false)
		return

	_update_visuals()
	_publish_web_state()

func _check_hazards() -> void:
	for e in enemies:
		if not e.get("alive", true):
			continue
		var pos := Entities.current_pos(e, stage_time)
		var sz := Entities.size(e)
		var res := Entities.resolve(e, pos, sz, sim.x, sim.y, sim.vy, sim.diving)
		if res == "stomp":
			e["alive"] = false
			stomps += 1
			var node = e.get("node")
			if node:
				node.dead = true
			sim.vy = -Tuning.STOMP_BOUNCE_V
			sim.on_ground = false
			sim.coyote_timer = 0.0
			Fx.stomp(fx_root, pos, Color("7ed08a") if e["type"] != "bird" else Color("ffb15e"))
			Fx.popup(fx_root, pos, "＋踏んだ！", Color("bff7d0"))
		elif res == "hit" and invuln_timer <= 0.0:
			_on_miss()
			return

	if not sim.on_ground and sim.y > Tuning.PIT_DEATH_Y and invuln_timer <= 0.0:
		_on_miss()

func _check_pickups() -> void:
	for p in pickups:
		if p.get("got", false):
			continue
		var d := Vector2(sim.x, sim.y - Tuning.PLAYER_H / 2.0).distance_to(Vector2(p["x"], p["y"]))
		if d < 46.0:
			p["got"] = true
			var node = p.get("node")
			if node:
				node.got = true
			if p["type"] == "seed":
				seeds_collected += 1
				Fx.sparkle(fx_root, Vector2(p["x"], p["y"]))
			else:
				shield = true
				Fx.sparkle(fx_root, Vector2(p["x"], p["y"]))
				Fx.popup(fx_root, Vector2(p["x"], p["y"]), "風のお守り！", Color("8fd3ff"))

func _check_checkpoint_goal() -> void:
	if not checkpoint_passed and sim.x >= cur_stage.checkpoint_x:
		checkpoint_passed = true
		respawn_x = cur_stage.checkpoint_x
	if sim.x >= cur_stage.goal_x:
		_on_goal()

func _on_miss() -> void:
	if shield:
		shield = false
		invuln_timer = Tuning.HIT_INVULN
		player.pop_hit()
		Fx.popup(fx_root, Vector2(sim.x, sim.y), "お守りが守った！", Color("8fd3ff"))
		return
	misses += 1
	lives -= 1
	player.pop_hit()
	Fx.burst(fx_root, Vector2(sim.x, sim.y), Color("ff8f8f"), 12, 200.0, 0.5, 5.0)
	if lives <= 0:
		_finish_run(false)
		return
	sim = KuruliSim.make_state(respawn_x, cur_stage)
	invuln_timer = Tuning.HIT_INVULN
	_refresh_hud()

func _on_goal() -> void:
	stages_cleared += 1
	shake_timer = 0.5
	Fx.bell(fx_root, Vector2(sim.x, sim.y))
	Fx.popup(fx_root, Vector2(sim.x, sim.y), "面クリア！", Color("ffe38a"))
	if demo:
		goal_pause = 1.0
		return
	_advance_after_goal()

func _advance_after_goal() -> void:
	if stage_index + 1 >= stages.size():
		_finish_run(true)
	else:
		stage_index += 1
		_load_stage(stage_index)

func _finish_run(cleared: bool) -> void:
	if finished:
		return
	finished = true
	run_cleared = cleared
	var errs := logger.get_errors() + anomalies
	if autoplay:
		var out := {
			"stages_cleared": stages_cleared, "deaths": misses, "stomps": stomps,
			"seeds": seeds_collected, "jumps": jumps, "time_sec": snappedf(total_time, 0.01),
			"cleared": cleared, "errors": errs,
		}
		print(JSON.stringify(out))
		if errs > 0:
			printerr("errors: ", logger.first_errors)
		OS.remove_logger(logger)
		get_tree().quit(0 if (cleared and stages_cleared == stages.size() and errs == 0) else 1)
		return
	if cleared:
		if best["time_sec"] <= 0.0 or total_time < best["time_sec"]:
			best["time_sec"] = total_time
	if seeds_collected > int(best["seeds"]):
		best["seeds"] = seeds_collected
	_save_best()
	state = State.RESULT
	result_label.text = "クリアした面 %d / %d\nたね %d 個\n踏んだ敵 %d 匹\nミス %d 回\nタイム %s\n自己ベスト %s / たね %d 個" % [
		stages_cleared, stages.size(), seeds_collected, stomps, misses, _fmt_time(total_time),
		_fmt_time(best["time_sec"]) if best["time_sec"] > 0.0 else "―", int(best["seeds"]),
	]
	result_panel.visible = true
	hud.visible = false
	if demo:
		demo_wait = 4.0
	_publish_web_state()

func _fmt_time(t: float) -> String:
	var m := int(t) / 60
	var s := int(t) % 60
	return "%d:%02d" % [m, s]

# ---------------------------------------------------------------- 見た目

func _update_visuals() -> void:
	player.position = Vector2(sim.x, sim.y)
	player.airborne = not sim.on_ground
	for e in enemies:
		if e.get("alive", true):
			var node = e.get("node")
			if node:
				node.position = Entities.current_pos(e, stage_time)

	var bounds: Rect2 = background.visible_area
	world.position.x = bounds.position.x + bounds.size.x / 3.0 - sim.x * world.scale.x
	if bounds.size.y > bounds.size.x:
		# 足元を画面高の76%に固定し、縦長画面でも地面が下部約1/4に収まる構図にする。
		world.position.y = bounds.position.y + bounds.size.y * 0.76 - sim.y * world.scale.y
	else:
		world.position.y = bounds.end.y - bounds.size.y * 0.32
	if shake_timer > 0.0:
		shake_timer -= 1.0 / Tuning.PHYSICS_FPS
		world.position += Vector2(rng.randf_range(-6, 6), rng.randf_range(-6, 6)) * clampf(shake_timer / 0.5, 0.0, 1.0)
		flash_rect.color = Color(1, 1, 1, clampf(shake_timer / 0.5, 0.0, 1.0) * 0.5)
	else:
		flash_rect.color = Color(1, 1, 1, 0.0)

	_refresh_hud()

func _refresh_hud() -> void:
	if not hud.visible:
		return
	hud_lives.text = "いのち"
	for i in hud_life_icons.size():
		hud_life_icons[i].visible = i < lives
	hud_charm_icon.visible = shield
	hud_seeds.text = "たね %d" % seeds_collected
	hud_stage.text = "%d/%d %s" % [stage_index + 1, stages.size(), cur_stage.stage_name]
	hud_timer.text = _fmt_time(total_time)

# ---------------------------------------------------------------- 自己ベスト

func _load_best() -> void:
	if not FileAccess.file_exists(BEST_PATH):
		_refresh_best_display()
		return
	var f := FileAccess.open(BEST_PATH, FileAccess.READ)
	if f == null:
		_refresh_best_display()
		return
	var d = JSON.parse_string(f.get_as_text())
	if d is Dictionary:
		best["time_sec"] = float(d.get("time_sec", 0.0))
		best["seeds"] = int(d.get("seeds", 0))
	_refresh_best_display()

func _refresh_best_display() -> void:
	if title_best_label == null:
		return
	var time_text := _fmt_time(best["time_sec"]) if best["time_sec"] > 0.0 else "―"
	title_best_label.text = "自己ベスト %s / たね %d 個" % [time_text, int(best["seeds"])]

func _save_best() -> void:
	var f := FileAccess.open(BEST_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("best.json を書けなかった: %s" % FileAccess.get_open_error())
		return
	f.store_string(JSON.stringify(best))
	_refresh_best_display()

# ---------------------------------------------------------------- Web 連携（検証用）

func _publish_web_state() -> void:
	if not OS.has_feature("web"):
		return
	var st := {
		"state": ["title", "play", "result"][state],
		"stage": stage_index + 1,
		"stages": stages.size(),
		"seeds": seeds_collected,
		"stomps": stomps,
		"misses": misses,
		"lives": lives,
		"cleared": run_cleared,
		"result_visible": result_panel != null and result_panel.visible,
		"errors": logger.get_errors() + anomalies,
	}
	JavaScriptBridge.eval("window.__kuruli = %s;" % JSON.stringify(st), true)
