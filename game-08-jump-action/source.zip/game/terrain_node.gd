extends Node2D
## TileMapLayer と同じ面データを、継ぎ目のない地面の帯として描く。物理には関与しない。

var stage: StageData
var bottom_y := 704.0

func set_stage(next_stage: StageData, next_bottom_y: float) -> void:
	stage = next_stage
	bottom_y = next_bottom_y
	queue_redraw()

func _palette() -> Dictionary:
	match stage.theme:
		"cave":
			return {"deep": Color("211b30"), "soil": Color("4a3b58"), "layer": Color("675779"),
				"rim": Color("527d69"), "light": Color("97b68c"), "stone": Color("8a80a0")}
		"clouds":
			return {"deep": Color("92b9d7"), "soil": Color("c9e3f2"), "layer": Color("e0f0f9"),
				"rim": Color("e8f8ef"), "light": Color("ffffff"), "stone": Color("a9cfe4")}
		"port":
			return {"deep": Color("38283a"), "soil": Color("78513d"), "layer": Color("a66e46"),
				"rim": Color("6e9b56"), "light": Color("b8c87a"), "stone": Color("c49565")}
		_:
			return {"deep": Color("3c291e"), "soil": Color("805133"), "layer": Color("a56c3d"),
				"rim": Color("4f9b37"), "light": Color("b0db65"), "stone": Color("c08a57")}

func _wave(x: float, seed: float) -> float:
	return sin(x * 0.013 + seed) * 3.0 + sin(x * 0.037 + seed * 2.1) * 1.4

func _top(x: float) -> float:
	return stage.surface_y_at_x(x) + _wave(x, 0.7) * 0.35

func _strip(xs: PackedFloat32Array, upper: PackedFloat32Array, lower: PackedFloat32Array, color: Color) -> void:
	var points := PackedVector2Array()
	for i in xs.size():
		points.append(Vector2(xs[i], upper[i]))
	for i in range(xs.size() - 1, -1, -1):
		points.append(Vector2(xs[i], lower[i]))
	draw_colored_polygon(points, color)

func _draw_span(first: int, last: int, colors: Dictionary) -> void:
	var left := float(first) * Tuning.TILE
	var right := float(last + 1) * Tuning.TILE
	var xs := PackedFloat32Array()
	var top := PackedFloat32Array()
	var deep := PackedFloat32Array()
	var mid := PackedFloat32Array()
	var upper := PackedFloat32Array()
	var rim := PackedFloat32Array()
	var grass := PackedFloat32Array()
	var bottom := PackedFloat32Array()
	var count := int(ceil((right - left) / 12.0))
	for i in count + 1:
		var x := minf(left + float(i) * 12.0, right - 0.01)
		var y := _top(x)
		xs.append(x)
		top.append(y)
		deep.append(y + 160.0 + _wave(x, 1.3) * 3.0)
		mid.append(y + 87.0 + _wave(x, 2.7) * 2.0)
		upper.append(y + 36.0 + _wave(x, 4.1))
		rim.append(y + 12.0 + _wave(x, 5.2) * 0.3)
		grass.append(y - 9.0 - maxf(0.0, _wave(x, 3.5) * 0.6))
		bottom.append(bottom_y)
	_strip(xs, top, bottom, colors["deep"])
	_strip(xs, top, deep, colors["soil"])
	_strip(xs, top, mid, colors["layer"])
	_strip(xs, top, upper, colors["soil"])
	_strip(xs, grass, rim, colors["rim"])
	# 上面の明るい細い帯を連続させる。列境界に線を置かない。
	for i in xs.size() - 1:
		draw_line(Vector2(xs[i], grass[i] + 3.0), Vector2(xs[i + 1], grass[i + 1] + 3.0), colors["light"], 3.0, true)
	# 石と草はワールド座標に分散させ、64px グリッドに揃えない。
	var spot := int(ceil(left / 79.0))
	while float(spot) * 79.0 < right - 20.0:
		var x := float(spot) * 79.0 + sin(float(spot) * 7.7) * 18.0
		if x > left + 15.0 and x < right - 15.0:
			var y := _top(x)
			var depth := 46.0 + float(posmod(spot * 37, 84))
			draw_circle(Vector2(x, y + depth), 4.0 + float(posmod(spot * 11, 5)), colors["stone"])
			if spot % 3 == 0:
				draw_line(Vector2(x - 9.0, y - 8.0), Vector2(x - 4.0, y - 17.0), colors["light"], 2.0, true)
				draw_line(Vector2(x - 4.0, y - 17.0), Vector2(x + 2.0, y - 8.0), colors["light"], 2.0, true)
		spot += 1

func _draw() -> void:
	if stage == null:
		return
	var colors := _palette()
	var first := -1
	for c in stage.cols + 1:
		var solid := c < stage.cols and stage.height_at_col(c) >= 0
		if solid and first < 0:
			first = c
		elif not solid and first >= 0:
			_draw_span(first, c - 1, colors)
			first = -1
