extends Node2D
## 収集物の見た目。取得判定と位置は main.gd のまま。

const SEED := preload("res://art/props_00.png")
const CHARM := preload("res://art/props_01.png")

var kind := "seed"
var got := false
var phase := 0.0

func _process(delta: float) -> void:
	phase += delta * 3.0
	queue_redraw()

func _draw() -> void:
	if got:
		return
	var bob := sin(phase) * 4.0
	var tex: Texture2D = SEED if kind == "seed" else CHARM
	var size := Vector2(34, 40) if kind == "seed" else Vector2(42, 46)
	draw_texture_rect(tex, Rect2(Vector2(-size.x * 0.5, -size.y * 0.5 - bob), size), false)
