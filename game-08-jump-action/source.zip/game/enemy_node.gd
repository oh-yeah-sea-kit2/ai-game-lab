extends Node2D
## 敵の見た目。位置と接触判定は Entities が管理する。

const NUME := preload("res://art/actors_05.png")
const TOGE := preload("res://art/actors_06.png")
const BIRD_UP := preload("res://art/actors_07.png")
const BIRD_DOWN := preload("res://art/actors_08.png")

var kind := "nume"
var squish := 1.0
var dead := false
var flap_phase := 0.0

func _process(delta: float) -> void:
	squish = move_toward(squish, 1.0, delta * 5.0)
	flap_phase += delta * 8.0
	queue_redraw()

func pop_stomp() -> void:
	squish = 0.35

func _draw() -> void:
	if dead:
		return
	var tex: Texture2D
	var size: Vector2
	match kind:
		"nume":
			tex = NUME
			size = Vector2(58, 50)
		"toge":
			tex = TOGE
			size = Vector2(60, 56)
		_:
			tex = BIRD_UP if sin(flap_phase) >= 0.0 else BIRD_DOWN
			size = Vector2(62, 54)
	if kind != "bird":
		size.y *= squish
		draw_texture_rect(tex, Rect2(-size.x * 0.5, -size.y, size.x, size.y), false)
	else:
		draw_texture_rect(tex, Rect2(-size * 0.5, size), false)
