extends CharacterBody2D
## 見た目だけを描く。位置と当たり判定は KuruliSim が管理する。

const POSES := [
	preload("res://art/actors_00.png"), preload("res://art/actors_01.png"),
	preload("res://art/actors_02.png"), preload("res://art/actors_03.png"),
]
const PINWHEEL := preload("res://art/actors_04.png")

var facing := 1.0
var squash := 1.0
var stretch := 1.0
var wind_phase := 0.0
var hit_flash := 0.0
var pose_timer := 0.0
var airborne := false

func _ready() -> void:
	z_index = 10

func _process(delta: float) -> void:
	wind_phase += delta * 6.0
	squash = move_toward(squash, 1.0, delta * 4.0)
	stretch = move_toward(stretch, 1.0, delta * 4.0)
	hit_flash = maxf(0.0, hit_flash - delta * 2.5)
	pose_timer = maxf(0.0, pose_timer - delta)
	queue_redraw()

func pop_land() -> void:
	squash = 0.78
	stretch = 1.35
	pose_timer = 0.18

func pop_jump() -> void:
	squash = 1.3
	stretch = 0.72

func pop_hit() -> void:
	hit_flash = 1.0

func _draw() -> void:
	var pose := 3 if hit_flash > 0.0 else (2 if pose_timer > 0.0 else (1 if airborne else 0))
	var body: Texture2D = POSES[pose]
	var body_size := Vector2(92, 102) * Vector2(stretch, squash)
	draw_texture_rect(body, Rect2(Vector2(-body_size.x * 0.5, -body_size.y), body_size), false)
	# かざぐるまは顔素材と独立して回転させる。
	var hub := Vector2(0, -body_size.y + 9)
	draw_set_transform(hub, wind_phase, Vector2.ONE)
	draw_texture_rect(PINWHEEL, Rect2(-20, -27, 40, 40), false)
	draw_set_transform(Vector2.ZERO)
