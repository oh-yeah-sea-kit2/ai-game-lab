extends Node2D
## 画面全体を覆う固定遠景。可視矩形を canvas 変換でローカル座標に戻す。

const HILL := preload("res://art/bg_hill.png")
const PORT := preload("res://art/bg_port.png")
const CAVE_ARCH := preload("res://art/scenery_ui_fx_00.png")
const CAVE_CRYSTALS := preload("res://art/scenery_ui_fx_01.png")
const CAVE_ROCKS := preload("res://art/scenery_ui_fx_02.png")
const CLOUD_BANK := preload("res://art/scenery_ui_fx_03.png")
const CLOUD_TOWER := preload("res://art/scenery_ui_fx_04.png")
const CLOUD_WISP := preload("res://art/scenery_ui_fx_05.png")
const HILL_FLOWER := preload("res://art/scenery_ui_fx_06.png")
const PORT_LANTERN := preload("res://art/scenery_ui_fx_07.png")

var theme := "hill"
var gameplay := false
var visible_area := Rect2(0, 0, 720, 1280)

func update_bounds() -> void:
	var view := get_viewport().get_visible_rect()
	var inverse := get_canvas_transform().affine_inverse()
	var a := inverse * view.position
	var b := inverse * view.end
	visible_area = Rect2(a, b - a).abs()
	queue_redraw()

func set_scene(next_theme: String, in_game: bool) -> void:
	theme = next_theme
	gameplay = in_game
	queue_redraw()

func _cover(tex: Texture2D) -> void:
	var sz := tex.get_size()
	var scale_factor := maxf(visible_area.size.x / sz.x, visible_area.size.y / sz.y)
	var dest_size := sz * scale_factor
	var dest := Rect2(visible_area.get_center() - dest_size * 0.5, dest_size)
	draw_texture_rect(tex, dest, false)

func _sprite(tex: Texture2D, center: Vector2, size: Vector2, alpha: float = 1.0) -> void:
	draw_texture_rect(tex, Rect2(center - size * 0.5, size), false, Color(1, 1, 1, alpha))

func _draw() -> void:
	var r := visible_area
	match theme:
		"hill":
			_cover(HILL)
			if gameplay:
				_sprite(HILL_FLOWER, r.position + r.size * Vector2(0.78, 0.59), Vector2(92, 100), 0.7)
		"port":
			_cover(PORT)
			if gameplay:
				_sprite(PORT_LANTERN, r.position + r.size * Vector2(0.83, 0.55), Vector2(92, 130), 0.55)
		"cave":
			draw_rect(r, Color("171229"))
			_sprite(CAVE_ARCH, r.position + r.size * Vector2(0.5, 0.12), Vector2(r.size.x * 1.1, r.size.y * 0.35), 0.8)
			_sprite(CAVE_CRYSTALS, r.position + r.size * Vector2(0.83, 0.54), Vector2(150, 160), 0.55)
			_sprite(CAVE_ROCKS, r.position + r.size * Vector2(0.13, 0.61), Vector2(165, 105), 0.5)
		"clouds":
			draw_rect(r, Color("a5d6ff"))
			_sprite(CLOUD_TOWER, r.position + r.size * Vector2(0.77, 0.44), Vector2(190, 260), 0.5)
			_sprite(CLOUD_BANK, r.position + r.size * Vector2(0.2, 0.57), Vector2(230, 110), 0.45)
			_sprite(CLOUD_WISP, r.position + r.size * Vector2(0.65, 0.18), Vector2(190, 90), 0.55)
	if gameplay:
		# 画像の茂み・岩が手前の地形と混ざらないよう、下側をなめらかに暗くする。
		var band_top := r.position.y + r.size.y * 0.55
		var shade := Color(0.04, 0.06, 0.11, 0.32)
		draw_polygon(
			PackedVector2Array([
				Vector2(r.position.x, band_top), Vector2(r.end.x, band_top),
				Vector2(r.end.x, r.end.y), Vector2(r.position.x, r.end.y),
			]),
			PackedColorArray([Color(shade, 0.0), Color(shade, 0.0), shade, shade])
		)
