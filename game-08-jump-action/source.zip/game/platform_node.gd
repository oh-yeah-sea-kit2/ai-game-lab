extends Node2D
## 上がる足場・動く足場の見た目。position は上面の幅中央を指す。

var w := 128.0
var col := Color(0.75, 0.62, 0.42)
var theme_index := 0
var moving := false

func _draw() -> void:
	var top_color: Color = [Color("75b34d"), Color("8db69a"), Color("f7ffff"), Color("92a65d")][theme_index]
	var body_color: Color = [Color("805335"), Color("615574"), Color("b7d6e9"), Color("9b683e")][theme_index]
	var shade: Color = body_color.darkened(0.35)
	var left := -w * 0.5
	var right := w * 0.5
	if moving:
		# 舟形の木板。四角い端面と釘の格子を作らない。
		draw_colored_polygon(PackedVector2Array([
			Vector2(left + 18, -5), Vector2(right - 18, -5), Vector2(right, 3),
			Vector2(right - 15, 17), Vector2(left + 15, 17), Vector2(left, 3),
		]), shade)
		draw_colored_polygon(PackedVector2Array([
			Vector2(left + 19, -5), Vector2(right - 19, -5), Vector2(right - 6, 2),
			Vector2(right - 20, 9), Vector2(left + 20, 9), Vector2(left + 6, 2),
		]), Color("bb844b"))
		draw_line(Vector2(left + 24, 3), Vector2(right - 24, 3), Color("e6b878"), 2.0, true)
		return
	# 浮島は中央を厚く、左右を薄くした丸い断面にする。
	var outline := PackedVector2Array()
	var cap := PackedVector2Array()
	for i in 17:
		var t := float(i) / 16.0
		var x := lerpf(left, right, t)
		var bulge := sin(PI * t)
		outline.append(Vector2(x, 2.0 - bulge * 6.0))
		cap.append(Vector2(x, -3.0 - bulge * 6.0))
	for i in range(16, -1, -1):
		var t := float(i) / 16.0
		var x := lerpf(left, right, t)
		outline.append(Vector2(x, 5.0 + sin(PI * t) * 27.0))
		cap.append(Vector2(x, 4.0 + sin(PI * t) * 5.0))
	draw_colored_polygon(outline, shade)
	draw_colored_polygon(cap, body_color)
	for i in 16:
		var x := lerpf(left + 7.0, right - 7.0, float(i) / 15.0)
		var y := -3.0 - sin(PI * (x - left) / w) * 6.0
		draw_circle(Vector2(x, y), 5.0 + float(i % 3), top_color)
	draw_line(Vector2(left + 24, 18), Vector2(left + 35, 21), body_color.lightened(0.24), 2.0, true)
