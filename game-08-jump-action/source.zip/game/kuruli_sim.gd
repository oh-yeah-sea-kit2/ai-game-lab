class_name KuruliSim
## クルリ（主人公）の縦方向の動きを1か所にまとめた「物理の複製」。
## 実プレイ（main.gd が毎物理ティック呼ぶ）と、自動プレイの先読み（autoplay.gd が
## 状態を複製して数秒先まで試す）の**両方が同じこの関数を呼ぶ**ことで、
## 「今跳ぶ／待つ／長く跳ぶ／2段目を使う」の判断が実機の動きと必ず一致するようにしている。
## CharacterBody2D 自体（main.gd 側）は move_and_slide を使わず、ここで計算した
## position だけをそのまま反映する入れ物にする（決定的な固定刻みのため）。
##
## 動く足場は縦方向にはプレイヤーを乗せて一緒に動かす（乗った実感のため）が、
## 横方向には運ばない（自動走行の速さだけで x(t) が決まる前提を保つため。詳細は
## stage_data.gd と autoplay.gd の実装メモを参照）。

const TILE := Tuning.TILE

class State:
	var x := 0.0
	var y := 0.0          # 足元の位置。上が負、下が正（Godot の座標系に合わせる）
	var vy := 0.0
	var on_ground := true
	var coyote_timer := 0.0
	var buffer_timer := 0.0
	var jumps_used := 0
	var holding := false
	var hold_timer := 0.0
	var diving := false
	var just_jumped := false     # このティックで1段目のジャンプが発生したか（効果音・演出用）
	var just_double := false
	var just_landed := false
	var just_sprang := false

	func clone() -> State:
		var s := State.new()
		s.x = x; s.y = y; s.vy = vy; s.on_ground = on_ground
		s.coyote_timer = coyote_timer; s.buffer_timer = buffer_timer
		s.jumps_used = jumps_used; s.holding = holding; s.hold_timer = hold_timer
		s.diving = diving
		return s

static func make_state(x: float, stage: StageData) -> State:
	var s := State.new()
	s.x = x
	var gy := stage.surface_y_at_x(x)
	s.y = 0.0 if is_nan(gy) else gy
	s.on_ground = not is_nan(gy)
	return s

static func _begin_jump(s: State, v: float) -> void:
	s.vy = -v
	s.on_ground = false
	s.coyote_timer = 0.0
	s.holding = true
	s.hold_timer = 0.0

## 動く足場の現在の矩形と上面 y を返す（time=面の開始からの経過秒）。
static func band_rect_and_surface(band: Dictionary, time: float) -> Dictionary:
	var x0: float = band["x"]
	var surface_y: float = -float(band["height"]) * TILE
	if band["type"] == "moving":
		var amp: float = band.get("amp", Tuning.MOVING_AMPLITUDE)
		var period: float = band.get("period", Tuning.MOVING_PERIOD)
		var phase := sin(TAU * time / period)
		if band.get("axis", "x") == "x":
			x0 += amp * phase
		else:
			surface_y -= amp * phase
	return {"x0": x0, "x1": x0 + float(band["w"]), "y": surface_y}

## 現在の x・時刻で乗れる面（地面＋足場）の上面 y の一覧。
static func surfaces_at(stage: StageData, x: float, time: float) -> Array:
	var out: Array = []
	var gy := stage.surface_y_at_x(x)
	if not is_nan(gy):
		out.append(gy)
	for band in stage.bands:
		if band["type"] != "platform" and band["type"] != "moving":
			continue
		var r := band_rect_and_surface(band, time)
		if x >= r["x0"] and x < r["x1"]:
			out.append(r["y"])
	return out

## action: {"press": bool, "hold": bool, "swipe": bool}
## dt 経過させ、s を書き換える。time は面開始からの経過秒（このティックの開始時刻）。
static func step(s: State, dt: float, stage: StageData, time: float, action: Dictionary) -> void:
	s.just_jumped = false
	s.just_double = false
	s.just_landed = false
	s.just_sprang = false

	# 横方向は速度ゾーンの影響だけを受け、縦の入力とは無関係（自動プレイの先読みが
	# 「時刻→x位置」を一意に計算できる前提。ジャンプしても前に進む速さは変わらない）。
	var speed := stage.speed_base * stage.speed_mult_at_x(s.x)
	s.x += speed * dt
	var time_after := time + dt

	s.coyote_timer = maxf(0.0, s.coyote_timer - dt)
	s.buffer_timer = maxf(0.0, s.buffer_timer - dt)

	var pressed: bool = action.get("press", false)
	var held: bool = action.get("hold", false)
	var swiped: bool = action.get("swipe", false)

	if pressed:
		if s.on_ground or s.coyote_timer > 0.0:
			_begin_jump(s, Tuning.JUMP_TAKEOFF_V)
			s.jumps_used = 1
			s.just_jumped = true
		elif s.jumps_used < 2:
			_begin_jump(s, Tuning.DOUBLE_JUMP_V)
			s.jumps_used = 2
			s.holding = false
			s.just_double = true
		else:
			s.buffer_timer = Tuning.JUMP_BUFFER

	# 1) すでに地面／足場に乗っている場合: 動く足場について来られるかだけ確かめる。
	if s.on_ground:
		var surfaces := surfaces_at(stage, s.x, time_after)
		var best := NAN
		for surf in surfaces:
			var f: float = surf
			if absf(f - s.y) <= Tuning.REST_SNAP_PX and (is_nan(best) or absf(f - s.y) < absf(best - s.y)):
				best = f
		if not is_nan(best):
			s.y = best
			s.vy = 0.0
			if stage.is_spring_at_x(s.x):
				s.vy = -Tuning.SPRING_V
				s.on_ground = false
				s.jumps_used = 0
				s.holding = true
				s.hold_timer = 0.0
				s.just_sprang = true
		else:
			s.on_ground = false
			s.coyote_timer = Tuning.COYOTE_TIME

	# 2) 空中（1で足場を失った場合も含む）: 重力で落ちる。下向きに交差した面に着地する。
	if not s.on_ground:
		s.holding = s.holding and held
		if swiped and not s.diving:
			s.diving = true
			s.vy = maxf(s.vy, Tuning.FASTFALL_VY)
		var g := Tuning.GRAVITY_HIGH
		if s.holding and s.vy < 0.0 and s.hold_timer < Tuning.JUMP_MAX_HOLD:
			g = Tuning.GRAVITY_HOLD
		if s.holding:
			s.hold_timer += dt
		s.vy += g * dt
		var y_prev := s.y
		var y_new := s.y + s.vy * dt
		var surfaces := surfaces_at(stage, s.x, time_after)
		var landed_on := NAN
		for surf in surfaces:
			var f: float = surf
			if s.vy >= 0.0 and y_prev <= f + 0.5 and y_new >= f - 0.5:
				if is_nan(landed_on) or f < landed_on:
					landed_on = f
		if not is_nan(landed_on):
			s.y = landed_on
			s.vy = 0.0
			s.on_ground = true
			s.jumps_used = 0
			s.holding = false
			s.diving = false
			s.coyote_timer = 0.0
			s.just_landed = true
			if s.buffer_timer > 0.0:
				s.buffer_timer = 0.0
				_begin_jump(s, Tuning.JUMP_TAKEOFF_V)
				s.jumps_used = 1
				s.just_jumped = true
			elif stage.is_spring_at_x(s.x):
				s.vy = -Tuning.SPRING_V
				s.on_ground = false
				s.jumps_used = 0
				s.holding = true
				s.hold_timer = 0.0
				s.just_sprang = true
		else:
			s.y = y_new
