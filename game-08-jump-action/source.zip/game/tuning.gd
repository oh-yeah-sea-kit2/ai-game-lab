class_name Tuning
## 跳び心地とゲーム全体の数値定数を1か所にまとめる（仕様必須事項）。
## ここを変えるだけで手触りが変わるようにし、実プレイと自動プレイ（先読み）の両方が
## 同じ値を参照する（`kuruli_sim.gd` から使われる）。

const TILE := 64.0

# 重力・ジャンプ（押す長さで高さが変わる。最大 0.25 秒）
const GRAVITY_HIGH := 2600.0       # 通常の重力（短いタップ・落下時）
const GRAVITY_HOLD := 900.0        # ボタンを押し続けている間の上昇（ゆっくり落ち始める＝高く跳べる）
const JUMP_TAKEOFF_V := 820.0      # ジャンプ開始時の上向き速度
const JUMP_MAX_HOLD := 0.25        # 長押しが効く上限（秒）
const DOUBLE_JUMP_V := 560.0       # 空中でもう一度押した時の2段目（固定・小さめ）

# 跳び心地の決まり（仕様必須）
const COYOTE_TIME := 0.08          # 足場を離れた直後、まだ跳べる猶予
const JUMP_BUFFER := 0.1           # 着地前に押した入力を着地後に活かす猶予

# 急降下（下へすばやく払う）
const SWIPE_MIN_PX := 100.0
const SWIPE_MAX_MS := 200.0
const FASTFALL_VY := 1500.0        # 急降下で即座に与える下向き速度
const FASTFALL_MIN_VY := 900.0     # この速さ以上で落下中なら「急降下中」とみなし、とげ貝以外を確実に倒す

const STOMP_BOUNCE_V := 420.0      # 敵を踏んだ後の小さな跳ね返り

# ばね草
const SPRING_V := 1300.0

# 速度ゾーン
const WIND_MULT := 1.4             # 風の坂（加速）
const MUD_MULT := 0.55             # ぬかるみ（減速）

# キャラクターの当たり判定（足元原点。y は下向きが正）
const PLAYER_W := 40.0
const PLAYER_H := 76.0
const PLAYER_HALF_W := PLAYER_W / 2.0

# 敵
const NUME_W := 50.0
const NUME_H := 44.0
const NUME_PATROL := 46.0
const NUME_SPEED := 40.0

const TOGE_W := 54.0
const TOGE_H := 50.0

const BIRD_W := 48.0
const BIRD_H := 40.0
const BIRD_AMPLITUDE := 46.0
const BIRD_PERIOD := 1.7

const NUME_PERIOD := 2.2

# 穴に落ちて「ミス」と判定するまでの深さ（地面の高さ 0 より下）
const PIT_DEATH_Y := TILE * 2.5

# ライフ・ミス
const LIVES_MAX := 3
const HIT_INVULN := 1.0            # ミス直後の無敵時間（連続ミス防止）

# 収集物・ギミック
const SEED_R := 14.0
const CHARM_R := 18.0
const BELL_TRIGGER_X := 34.0

# 崩れる足場
const CRUMBLE_DELAY := 0.5         # 乗ってから崩れるまで
const CRUMBLE_RESPAWN := 3.0       # 崩れてから復活するまで

# 動く足場
const MOVING_PERIOD := 2.4
const MOVING_AMPLITUDE := 128.0    # 中心から片側への振れ幅（px）

# 物理刻み
const PHYSICS_FPS := 60

# 実装上の許容誤差（手触りの定数ではなく、動く足場に乗り続けるための当たり判定の遊び）
const REST_SNAP_PX := 48.0
