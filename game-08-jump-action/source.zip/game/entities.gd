class_name Entities
## 敵の位置（時刻の関数）と、プレイヤーとの当たり判定。実プレイと自動プレイの先読みが
## どちらもこの関数を使う（同じ「物理の複製」の一部）。
## 敵は数式で位置が決まる（乱数を使わない）ので、面の開始からの経過秒だけで未来の位置が計算でき、
## 自動プレイヤーが数秒先まで安全かどうかを見積もれる。

const TILE := Tuning.TILE

## 敵1体を表す Dictionary: {"type":"nume"|"toge"|"bird", "x":スポーン列のx, "y":地面 y（bird は基準の高さ）}

static func current_pos(e: Dictionary, time: float) -> Vector2:
	var x: float = e["x"]
	var y: float = e["y"]
	match e["type"]:
		"nume":
			var phase := fmod(x * 0.013, TAU)
			return Vector2(x + Tuning.NUME_PATROL * sin(TAU * time / Tuning.NUME_PERIOD + phase), y)
		"bird":
			var phase2 := fmod(x * 0.021, TAU)
			return Vector2(x, y + Tuning.BIRD_AMPLITUDE * sin(TAU * time / Tuning.BIRD_PERIOD + phase2))
		_:
			return Vector2(x, y)

static func size(e: Dictionary) -> Vector2:
	match e["type"]:
		"nume":
			return Vector2(Tuning.NUME_W, Tuning.NUME_H)
		"toge":
			return Vector2(Tuning.TOGE_W, Tuning.TOGE_H)
		"bird":
			return Vector2(Tuning.BIRD_W, Tuning.BIRD_H)
		_:
			return Vector2(48.0, 48.0)

## プレイヤー（足元 player_x/player_y、下向き速度 vy、急降下中か diving）と敵1体の当たりを判定する。
## 戻り値: "none" | "stomp" | "hit"
## 「踏んだかどうか」＝「主人公が下向きに動いていて、足が敵の上半分に当たった」（仕様必須のルール）。
static func resolve(e: Dictionary, pos: Vector2, sz: Vector2, player_x: float, player_y: float, vy: float, diving: bool) -> String:
	var half_w := sz.x / 2.0
	var top := pos.y - sz.y
	var bottom := pos.y
	var mid := pos.y - sz.y / 2.0
	var overlap_x := absf(player_x - pos.x) < (half_w + Tuning.PLAYER_HALF_W)
	var overlap_y := player_y > top and (player_y - Tuning.PLAYER_H) < bottom
	if not overlap_x or not overlap_y:
		return "none"
	if e["type"] == "toge":
		return "hit"
	var stomp := vy > 0.0 and player_y >= top and player_y <= mid
	if diving and vy >= Tuning.FASTFALL_MIN_VY:
		stomp = true
	return "stomp" if stomp else "hit"
