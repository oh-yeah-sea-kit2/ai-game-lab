class_name Autoplay
## 先読みの自動プレイヤー。
##
## 横方向は自動走行で、ジャンプしても前に進む速さは変わらない（`kuruli_sim.gd` 参照）。
## つまり面の x(t) は入力と無関係に決まる。そこで「今このティックで何もしないと決めた場合、
## もう1ティックだけ待ってから跳んでも間に合うか」を `KuruliSim.step`（実プレイと全く同じ
## 物理の複製）で数秒先まで試しに進めて確かめる。まだ間に合うなら待つ、間に合わなくなった
## その瞬間（＝待てる最後のタイミング）でジャンプを押す。空中では、2段目のジャンプについて
## 「今の跳躍をそのまま（2段目なしで）続けても安全か」を毎ティック試し、危ないと分かった
## その場で2段目を使う。急降下は面のクリアに必須ではない（踏める敵は落下中の接触だけで
## 踏める）ため、自動プレイヤーは使わない。

const HORIZON := 150         # 2.5秒（60fps）先まで見る
const GROUND_LEAD_TICKS := 6 # 「あと何ティック待てるか」の判定に持たせる安全のりしろ
const LANDING_BUFFER_TICKS := 30  # 着地後、そのまま何もせず走り続けても平気だと確かめる猶予（0.5秒）

var stage: StageData
var hazards: Array

func _init(p_stage: StageData, p_hazards: Array) -> void:
	stage = p_stage
	hazards = p_hazards

func decide(state: KuruliSim.State, time: float, dt: float) -> Dictionary:
	if state.on_ground:
		var plan := _actions_wait_then(GROUND_LEAD_TICKS, [{"press": true, "hold": true, "swipe": false}])
		if not _simulate_safe(state, time, dt, plan, HORIZON):
			return {"press": true, "hold": true, "swipe": false}
		return {"press": false, "hold": false, "swipe": false}
	if state.jumps_used < 2 and not state.diving:
		# 今の跳躍をそのまま（2段目を使わずに）続けても安全か、まず確かめる。
		# ここで無条件に2段目を試すと、まだ必要ない2段目（弱い固定速度）が今の跳躍の
		# 勢いを弱めてしまい、逆に届かなくなる（実際に起きた不具合。BUILD-LOG参照）。
		if not _simulate_safe(state, time, dt, [], HORIZON):
			return {"press": true, "hold": false, "swipe": false}
	return {"press": false, "hold": true, "swipe": false}

func _actions_wait_then(n: int, tail: Array) -> Array:
	var out: Array = []
	for i in n:
		out.append({"press": false, "hold": true, "swipe": false})
	out.append_array(tail)
	return out

## actions を最初に適用し、その後は着地するまで様子を見るだけの「コースト」を続ける。
## 遠くの別の障害物（次の敵や穴）まで見てしまうと「今回の跳躍とは無関係な将来」を理由に
## 誤って危険と判定してしまう（実際に起きた不具合。BUILD-LOG参照）ため、
## actions で始めた跳躍が着地したら、そこで打ち切らず**着地後も少し走らせてから**安全と判定する
## （着地地点そのものが次の障害物にめり込むほど近いと、着地の瞬間だけを見ても分からないため。
## これも実際に起きた不具合: 2段ジャンプで敵の手前1マスに着地し、次のティックで反応できず接触した）。
func _simulate_safe(start: KuruliSim.State, start_time: float, dt: float, actions: Array, horizon_ticks: int) -> bool:
	var sim := start.clone()
	var t := start_time
	var stomped := {}
	var landed_at := -1
	for i in horizon_ticks:
		var act: Dictionary = actions[i] if i < actions.size() else {"press": false, "hold": true, "swipe": false}
		KuruliSim.step(sim, dt, stage, t, act)
		t += dt
		if _hits_death(sim, t, stomped):
			return false
		if i >= actions.size() and sim.just_landed and landed_at < 0:
			landed_at = i
		if landed_at >= 0 and i - landed_at >= LANDING_BUFFER_TICKS:
			return true
	return true

func _hits_death(sim: KuruliSim.State, t: float, stomped: Dictionary) -> bool:
	if not sim.on_ground and sim.y > Tuning.PIT_DEATH_Y:
		return true
	for i in hazards.size():
		var h: Dictionary = hazards[i]
		if stomped.has(i) or not h.get("alive", true):
			continue
		var pos := Entities.current_pos(h, t)
		var sz := Entities.size(h)
		var res := Entities.resolve(h, pos, sz, sim.x, sim.y, sim.vy, sim.diving)
		if res == "hit":
			return true
		elif res == "stomp":
			stomped[i] = true
	return false
