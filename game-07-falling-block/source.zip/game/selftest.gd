class_name SelfTest
## `--selftest` 用。決め打ちの盤・決め打ちの駒配置で、回転(壁ぎわ・床ぎわのずらし)・
## 列消し(1〜5列)・ひかえ・点数表を確かめる。

const BL := preload("res://board_logic.gd")
const PL := preload("res://piece_logic.gd")

## --- 壁ぎわの回転ずらし ---
## l5(縦棒4+足1)を右壁ぎわに横向き(rot0)で置き、時計回りに回すと縦向き(rot1)は
## 右にはみ出す。ずらし表を (-2,0) まで試してようやく収まることを確かめる。
static func _case_wall_kick() -> Dictionary:
	var board := BL.new_board()
	var piece := {"shape": "l5", "rot": 0, "origin": Vector2i(8, 0)}
	var before_ok := PL.can_place(board, piece["shape"], piece["origin"], piece["rot"])
	var rotated = PL.try_rotate(board, piece, 1)
	var ok: bool = before_ok and rotated != null \
		and rotated["rot"] == 1 \
		and rotated["origin"] == Vector2i(6, 0)
	return {
		"name": "wall_kick_l5",
		"ok": ok,
		"detail": "before_ok=%s rotated=%s (expect origin=(6,0) rot=1)" % [before_ok, rotated],
	}

## --- 床ぎわの回転ずらし ---
## l5 を横向き(rot0のとき縦4段になる形をrot1=横2段で)床ぎわに置き、反時計回りで
## rot0(縦4段)に戻すと下にはみ出す。(0,-1) のずらしで収まることを確かめる。
static func _case_floor_kick() -> Dictionary:
	var board := BL.new_board()
	var piece := {"shape": "l5", "rot": 1, "origin": Vector2i(3, BL.ROWS - 3)}
	var before_ok := PL.can_place(board, piece["shape"], piece["origin"], piece["rot"])
	var rotated = PL.try_rotate(board, piece, -1)
	var ok: bool = before_ok and rotated != null \
		and rotated["rot"] == 0 \
		and rotated["origin"] == Vector2i(3, BL.ROWS - 4)
	return {
		"name": "floor_kick_l5",
		"ok": ok,
		"detail": "before_ok=%s rotated=%s (expect origin=(3,%d) rot=0)" % [before_ok, rotated, BL.ROWS - 4],
	}

## 一番下のk段を完全に埋め、その1段上は「1マスだけ空き」にした盤を作る。
static func _build_lines_board(k: int) -> PackedByteArray:
	var b := BL.new_board()
	for r in range(BL.ROWS - k, BL.ROWS):
		for c in range(BL.COLS):
			b[BL.idx(c, r)] = 1
	var near_row := BL.ROWS - k - 1
	if near_row >= 0:
		for c in range(1, BL.COLS):
			b[BL.idx(c, near_row)] = 2
	return b

static func _case_line_clear(k: int) -> Dictionary:
	var board := _build_lines_board(k)
	var full := BL.find_full_rows(board)
	var expect_rows: Array[int] = []
	for r in range(BL.ROWS - k, BL.ROWS):
		expect_rows.append(r)
	var rows_ok: bool = full == expect_rows
	var cleared := BL.clear_rows(board, full)
	var remaining := 0
	for v in cleared:
		if v != 0:
			remaining += 1
	var expect_remaining := BL.COLS - 1
	var remaining_ok := remaining == expect_remaining
	var score1 := BL.score_for_clear(full.size(), 1)
	var score2 := BL.score_for_clear(full.size(), 2)
	var expect_score1: int = BL.LINE_SCORE[k]
	var expect_score2 := int(round(float(BL.LINE_SCORE[k]) * 1.5))
	var ok: bool = rows_ok and remaining_ok and score1 == expect_score1 and score2 == expect_score2
	return {
		"name": "line_clear_%d" % k,
		"ok": ok,
		"detail": "rows=%s(expect %s) remaining=%d(expect %d) score1=%d(expect %d) score2=%d(expect %d)" % [
			full, expect_rows, remaining, expect_remaining, score1, expect_score1, score2, expect_score2],
	}

static func _case_hold_first_use() -> Dictionary:
	var r := PL.apply_hold("t5", null, false)
	var ok: bool = r["ok"] and r["held"] == "t5" and r["current"] == null
	return {"name": "hold_first_use", "ok": ok, "detail": str(r)}

static func _case_hold_swap() -> Dictionary:
	var r := PL.apply_hold("t5", "v5", false)
	var ok: bool = r["ok"] and r["current"] == "v5" and r["held"] == "t5"
	return {"name": "hold_swap", "ok": ok, "detail": str(r)}

static func _case_hold_blocked_second_use() -> Dictionary:
	var r := PL.apply_hold("t5", "v5", true)
	var ok: bool = r["ok"] == false
	return {"name": "hold_blocked_second_use", "ok": ok, "detail": str(r)}

static func run() -> Dictionary:
	var cases := []
	cases.append(_case_wall_kick())
	cases.append(_case_floor_kick())
	for k in range(1, 6):
		cases.append(_case_line_clear(k))
	cases.append(_case_hold_first_use())
	cases.append(_case_hold_swap())
	cases.append(_case_hold_blocked_second_use())

	var passed := 0
	var failed := 0
	var errors: Array[String] = []
	for c in cases:
		if c["ok"]:
			passed += 1
		else:
			failed += 1
			errors.append("%s: %s" % [c["name"], c["detail"]])

	return {
		"selftest_passed": passed,
		"selftest_failed": failed,
		"errors": errors,
		"cases": cases,
	}
