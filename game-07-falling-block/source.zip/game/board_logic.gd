class_name BoardLogic
## 盤の純粋関数だけを集めたクラス。描画・入力を一切知らない。
## 盤は PackedByteArray（COLS*ROWS）。row0〜1 = 見えない上2段、row2..ROWS-1 = 表示20段。
## セル値: EMPTY=0、1..8 = サンゴのかけらの色id（PieceLogic.color_id と対応）。

const COLS := 11
const HIDDEN_ROWS := 2
const VISIBLE_ROWS := 20
const ROWS := HIDDEN_ROWS + VISIBLE_ROWS
const EMPTY := 0

## 同時に消した列数(1..5)ごとの独自の点数表
const LINE_SCORE := [0, 100, 300, 600, 1000, 1500]
const LINES_PER_LEVEL := 10
const BASE_FALL_INTERVAL := 1.0
const FALL_INTERVAL_STEP := 0.075
const MIN_FALL_INTERVAL := 0.12

static func idx(col: int, row: int) -> int:
	return row * COLS + col

static func in_bounds(col: int, row: int) -> bool:
	return col >= 0 and col < COLS and row >= 0 and row < ROWS

static func new_board() -> PackedByteArray:
	var b := PackedByteArray()
	b.resize(COLS * ROWS)
	b.fill(EMPTY)
	return b

static func cell_free(board: PackedByteArray, col: int, row: int) -> bool:
	if not in_bounds(col, row):
		return false
	return board[idx(col, row)] == EMPTY

## 与えたセル(絶対盤座標)を color_id で埋めた新しい盤を返す(元の盤は変更しない)。
static func lock_cells(board: PackedByteArray, cells: Array, color_id: int) -> PackedByteArray:
	var work := board.duplicate()
	for c in cells:
		var p: Vector2i = c
		work[idx(p.x, p.y)] = color_id
	return work

## すき間なく埋まっている行の番号をすべて返す(小さい順)。
static func find_full_rows(board: PackedByteArray) -> Array[int]:
	var rows: Array[int] = []
	for r in range(ROWS):
		var full := true
		for c in range(COLS):
			if board[idx(c, r)] == EMPTY:
				full = false
				break
		if full:
			rows.append(r)
	return rows

## 指定した行を取り除き、上を1段ずつ詰めた新しい盤を返す。
static func clear_rows(board: PackedByteArray, rows: Array[int]) -> PackedByteArray:
	if rows.is_empty():
		return board.duplicate()
	var rows_set := {}
	for r in rows:
		rows_set[r] = true
	var work := new_board()
	var write_row := ROWS - 1
	for r in range(ROWS - 1, -1, -1):
		if rows_set.has(r):
			continue
		for c in range(COLS):
			work[idx(c, write_row)] = board[idx(c, r)]
		write_row -= 1
	return work

## 列ごとの高さ(一番上の詰みマスから床までの段数)。AI評価・でこぼこ計算に使う。
static func column_heights(board: PackedByteArray) -> Array[int]:
	var heights: Array[int] = []
	for c in range(COLS):
		var h := 0
		for r in range(ROWS):
			if board[idx(c, r)] != EMPTY:
				h = ROWS - r
				break
		heights.append(h)
	return heights

## 上にブロックがあるのに下が空いている「穴」の数。
static func count_holes(board: PackedByteArray) -> int:
	var holes := 0
	for c in range(COLS):
		var seen_block := false
		for r in range(ROWS):
			var filled := board[idx(c, r)] != EMPTY
			if filled:
				seen_block = true
			elif seen_block:
				holes += 1
	return holes

static func bumpiness(heights: Array[int]) -> int:
	var b := 0
	for i in range(heights.size() - 1):
		b += absi(heights[i] - heights[i + 1])
	return b

static func aggregate_height(heights: Array[int]) -> int:
	var s := 0
	for h in heights:
		s += h
	return s

## 消した列数と連続消し(combo, 1始まり)から点数を計算する。combo=1 は倍率なし。
static func score_for_clear(lines_count: int, combo: int) -> int:
	var i := clampi(lines_count, 0, LINE_SCORE.size() - 1)
	var base_score: int = LINE_SCORE[i]
	var mult := 1.0 + 0.5 * float(maxi(combo, 1) - 1)
	return int(round(float(base_score) * mult))

static func level_for_lines(total_lines: int) -> int:
	return int(total_lines / LINES_PER_LEVEL) + 1

static func fall_interval_for_level(level: int) -> float:
	return maxf(MIN_FALL_INTERVAL, BASE_FALL_INTERVAL - FALL_INTERVAL_STEP * float(level - 1))

## 出現位置(見えない上2段)にブロックがあるか＝天井に届いた。
static func is_spawn_area_blocked(board: PackedByteArray) -> bool:
	for r in range(HIDDEN_ROWS):
		for c in range(COLS):
			if board[idx(c, r)] != EMPTY:
				return true
	return false
