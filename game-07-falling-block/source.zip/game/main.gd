extends Node2D
## サンゴ積み — 本体。3マスと5マスの形だけで遊ぶ落ちものパズル。
## 画面の基準は 720x1280。横長でも縦長でも、World ノードを画面中央に置き直す。

const BL := preload("res://board_logic.gd")
const PL := preload("res://piece_logic.gd")
const AutoAI := preload("res://auto_ai.gd")
const SelfTest := preload("res://selftest.gd")
const ErrorCounter := preload("res://error_counter.gd")
const REEF_BG := preload("res://art/reef_bg.png")
const GLASS_WELL := preload("res://art/glass_well.png")
const CLEAR_BAND := preload("res://art/clear_band.png")
const NEXT_FRAME := preload("res://art/ui_furniture_00.png")
const HOLD_FRAME := preload("res://art/ui_furniture_01.png")
const CARD_ART := preload("res://art/ui_furniture_02.png")
const BUTTON_ART := preload("res://art/ui_furniture_03.png")
const CELLS := [
	preload("res://art/coral_cells_00.png"), preload("res://art/coral_cells_01.png"),
	preload("res://art/coral_cells_02.png"), preload("res://art/coral_cells_03.png"),
	preload("res://art/coral_cells_04.png"), preload("res://art/coral_cells_05.png"),
	preload("res://art/coral_cells_06.png"), preload("res://art/coral_cells_07.png"),
]
const BUBBLES := [
	preload("res://art/bubbles_00.png"), preload("res://art/bubbles_01.png"),
	preload("res://art/bubbles_02.png"), preload("res://art/bubbles_03.png"),
]

const BASE := Vector2(720, 1280)
const CELL := 52.0
const BOARD_ORIGIN := Vector2(74, 230)
const BOARD_PIXEL_W := 572.0  ## 11列 * 52px
const BOARD_PIXEL_H := 1040.0  ## 20段(表示分) * 52px

const NEXT_RECTS := [
	Rect2(74, 50, 74, 74),
	Rect2(158, 50, 74, 74),
	Rect2(242, 50, 74, 74),
]
const HOLD_RECT := Rect2(400, 50, 90, 90)
const HUD_POS := Vector2(500, 20)

const MOVE_STEP_PX := 52.0
const TAP_MAX_DIST := 16.0
const TAP_MAX_TIME := 0.25
const SWIPE_MIN_DY := 120.0
const SWIPE_MAX_TIME := 0.2
const SOFT_DRAG_MIN_DY := 24.0
const SOFT_DROP_INTERVAL := 0.045
const LOCK_DELAY := 0.5
const LOCK_MAX_RESETS := 15

const BEST_PATH := "user://best.json"

enum State { TITLE, PLAY, RESULT }

var state := State.TITLE
var rng := RandomNumberGenerator.new()
var logger: ErrorCounter

var world: Node2D
var ui_layer: CanvasLayer
var title_panel: Control
var result_panel: Control
var hud_label: Label
var result_label: Label
var title_best_label: Label
var start_button: Button
var retry_button: Button
var hold_button: Button
var base_layout_pos := Vector2.ZERO
var web_state_update_timer := 0.0

# --- 検証用の引数 ---
var autoplay := false
var demo := false
var selftest_mode := false
var run_seconds := 300.0
var time_scale := 1.0
var demo_transition_time := 0.0
var demo_piece_time := 0.0
var demo_drop_time := 0.0
var demo_target: Dictionary = {}

# --- 盤とゲーム状態 ---
var board: PackedByteArray = BL.new_board()
var piece_queue: Array[String] = []
var current_piece: Dictionary = {}
var held_shape = null
var hold_used := false
var hold_count := 0  ## ひかえが成功した回数(検証用。hold_usedは新しい駒が出ると毎回falseに戻るため)
var score := 0
var total_lines := 0
var level := 1
var combo := 0
var max_clear := 0
var pieces_spawned := 0
var piece_sizes_seen := {}
var time_left := 300.0
var fall_timer := 1.0
var grounded := false
var lock_time_left := 0.0
var lock_resets := 0
var topped_out := false
var best := {"score": 0}
var new_record := false

# --- 演出 ---
var clearing_flash: Array = []  # [{row:int, alpha:float}]
var shake_time := 0.0
var particles_root: Node2D

# --- 入力(ポインター) ---
var pointer_active := false
var pointer_start_pos := Vector2.ZERO
var pointer_start_time := 0.0
var pointer_move_ref_x := 0.0
var pointer_hard_drop_done := false
var pointer_history: Array = []
var soft_drop_drag := false

func _ready() -> void:
	logger = ErrorCounter.new()
	OS.add_logger(logger)
	_parse_args()
	if OS.has_feature("web"):
		var query := str(JavaScriptBridge.eval("window.location.search", true))
		for part in query.trim_prefix("?").split("&"):
			if part == "demo=1":
				demo = true
	if selftest_mode:
		var result := SelfTest.run()
		print(JSON.stringify(result))
		if result["selftest_failed"] > 0:
			printerr("selftest failed: ", result["errors"])
		OS.remove_logger(logger)
		get_tree().quit(0 if result["selftest_failed"] == 0 else 1)
		return
	_load_best()
	_build_world()
	_build_ui()
	get_viewport().size_changed.connect(_layout)
	_layout()
	if autoplay:
		_start_game()
	else:
		_show_title()

func _parse_args() -> void:
	var args := OS.get_cmdline_user_args()
	var seed_val := int(Time.get_unix_time_from_system())
	for a in args:
		if a == "--autoplay":
			autoplay = true
		elif a == "--selftest":
			selftest_mode = true
		elif a.begins_with("--seconds="):
			run_seconds = maxf(1.0, float(a.get_slice("=", 1)))
		elif a.begins_with("--seed="):
			seed_val = int(a.get_slice("=", 1))
		elif a.begins_with("--timescale="):
			time_scale = clampf(float(a.get_slice("=", 1)), 0.1, 60.0)
	rng.seed = seed_val
	time_left = run_seconds

# ---------------------------------------------------------------- 組み立て

func _build_world() -> void:
	world = Node2D.new()
	world.name = "World"
	add_child(world)
	world.draw.connect(_draw_world)
	particles_root = Node2D.new()
	world.add_child(particles_root)

	hold_button = Button.new()
	hold_button.position = HOLD_RECT.position
	hold_button.size = HOLD_RECT.size
	var empty_sb := StyleBoxEmpty.new()
	hold_button.add_theme_stylebox_override("normal", empty_sb)
	hold_button.add_theme_stylebox_override("hover", empty_sb)
	hold_button.add_theme_stylebox_override("pressed", empty_sb)
	hold_button.add_theme_stylebox_override("focus", empty_sb)
	hold_button.pressed.connect(_hold)
	world.add_child(hold_button)

	hud_label = _label(26, Color.WHITE)
	hud_label.position = HUD_POS
	hud_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hud_label.custom_minimum_size = Vector2(180, 0)
	world.add_child(hud_label)

	var next_caption := _label(26, Color(0.85, 0.95, 1.0))
	next_caption.text = "つぎ"
	next_caption.position = NEXT_RECTS[0].position + Vector2(0, -30)
	world.add_child(next_caption)

	var hold_caption := _label(26, Color(0.85, 0.95, 1.0))
	hold_caption.text = "ひかえ"
	hold_caption.position = HOLD_RECT.position + Vector2(0, -30)
	world.add_child(hold_caption)

func _label(size: int, col: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0.02, 0.03, 0.06))
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	ui_layer.layer = 10
	add_child(ui_layer)

	title_panel = _overlay()
	var tv := title_panel.get_meta("box") as VBoxContainer
	var t1 := _label(56, Color("ffd27a"))
	t1.text = "サンゴ積み"
	t1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tv.add_child(t1)
	var t2 := _label(26, Color.WHITE)
	t2.text = "3マスと5マスのサンゴが落ちてくる。\n横一列をすき間なく埋めると消える。\n5分でどれだけ稼げるか。"
	t2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tv.add_child(t2)
	var t3 := _label(26, Color(0.85, 0.95, 1.0))
	t3.text = "左右になぞる：移動　タップ：回転\n下へ払う：一気に落とす\nゆっくり下へ：速く落とす\nひかえ：形を入れ替え\nPC：←→ 移動、↑/X/Z 回転\n↓ 速く、Space 一気に、C ひかえ"
	t3.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tv.add_child(t3)
	title_best_label = _label(28, Color("ffe49d"))
	title_best_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tv.add_child(title_best_label)
	start_button = _button("あそぶ")
	start_button.pressed.connect(_start_game)
	tv.add_child(start_button)

	result_panel = _overlay()
	var rv := result_panel.get_meta("box") as VBoxContainer
	var r1 := _label(48, Color("ffd27a"))
	r1.text = "おしまい"
	r1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rv.add_child(r1)
	result_label = _label(26, Color.WHITE)
	result_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rv.add_child(result_label)
	retry_button = _button("もう一度")
	retry_button.pressed.connect(_start_game)
	rv.add_child(retry_button)
	result_panel.visible = false

func _overlay() -> Control:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.04, 0.08, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)
	var card := PanelContainer.new()
	var sb := StyleBoxTexture.new()
	sb.texture = CARD_ART
	sb.texture_margin_left = 94
	sb.texture_margin_right = 94
	sb.texture_margin_top = 92
	sb.texture_margin_bottom = 92
	sb.set_content_margin_all(34)
	card.add_theme_stylebox_override("panel", sb)
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.custom_minimum_size = Vector2(600, 0)
	center.add_child(card)
	var box := VBoxContainer.new()
	box.name = "Box"
	box.add_theme_constant_override("separation", 22)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(box)
	root.set_meta("box", box)
	ui_layer.add_child(root)
	return root

func _button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(320, 96)
	b.add_theme_font_size_override("font_size", 38)
	var sb := StyleBoxTexture.new()
	sb.texture = BUTTON_ART
	sb.texture_margin_left = 125
	sb.texture_margin_right = 125
	sb.texture_margin_top = 108
	sb.texture_margin_bottom = 108
	sb.set_content_margin_all(0)
	b.add_theme_stylebox_override("normal", sb)
	var sbh := sb.duplicate() as StyleBoxTexture
	sbh.modulate_color = Color(1.15, 1.15, 1.15)
	b.add_theme_stylebox_override("hover", sbh)
	var sbp := sb.duplicate() as StyleBoxTexture
	sbp.modulate_color = Color(0.7, 0.8, 0.8)
	b.add_theme_stylebox_override("pressed", sbp)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", Color("072018"))
	b.add_theme_color_override("font_hover_color", Color("072018"))
	b.add_theme_color_override("font_pressed_color", Color("072018"))
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	return b

# ---------------------------------------------------------------- 画面配置

func _layout() -> void:
	var vp := get_viewport().get_visible_rect().size
	# 縦長のスマホでは盤を少し大きくし、左右と下の余白を抑える。
	var factor := minf(1.1, vp.y / BASE.y) if vp.y > BASE.y else 1.0
	world.scale = Vector2.ONE * factor
	base_layout_pos = ((vp - BASE * factor) / 2.0).floor()
	world.position = base_layout_pos
	world.queue_redraw()

# ---------------------------------------------------------------- 状態遷移

func _show_title() -> void:
	state = State.TITLE
	title_best_label.text = "自己ベスト  %d" % int(best.get("score", 0))
	title_panel.visible = true
	result_panel.visible = false
	if demo:
		demo_transition_time = 2.0
	_publish_web_state()

func _start_game() -> void:
	board = BL.new_board()
	piece_queue.clear()
	held_shape = null
	hold_used = false
	hold_count = 0
	score = 0
	total_lines = 0
	level = 1
	combo = 0
	max_clear = 0
	pieces_spawned = 0
	piece_sizes_seen.clear()
	time_left = run_seconds
	fall_timer = BL.fall_interval_for_level(1)
	grounded = false
	lock_time_left = 0.0
	lock_resets = 0
	topped_out = false
	new_record = false
	clearing_flash.clear()
	shake_time = 0.0
	pointer_active = false
	demo_target.clear()
	demo_piece_time = 0.0
	demo_drop_time = 0.0
	title_panel.visible = false
	result_panel.visible = false
	state = State.PLAY
	_spawn_next()
	_refresh_hud()

func _ensure_queue(min_len: int) -> void:
	while piece_queue.size() < min_len:
		var b: Array[String] = []
		for s in PL.SHAPE_ORDER:
			var count := 2 if PL.mass(s) == 3 else 1
			for _i in range(count):
				b.append(s)
		_shuffle_array(b)
		piece_queue.append_array(b)

func _shuffle_array(arr: Array) -> void:
	for i in range(arr.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var tmp = arr[i]
		arr[i] = arr[j]
		arr[j] = tmp

func _spawn_next() -> void:
	demo_target.clear()
	demo_piece_time = 0.0
	demo_drop_time = 0.0
	_ensure_queue(4)
	var shape: String = piece_queue.pop_front()
	piece_sizes_seen[PL.mass(shape)] = true
	current_piece = PL.spawn(shape)
	pieces_spawned += 1
	hold_used = false
	grounded = false
	lock_time_left = 0.0
	lock_resets = 0
	fall_timer = BL.fall_interval_for_level(level)
	_ensure_queue(4)
	if not PL.can_place(board, shape, current_piece["origin"], current_piece["rot"]):
		_end_game(true)

func _end_game(topped: bool) -> void:
	if state != State.PLAY:
		return
	topped_out = topped
	state = State.RESULT
	if autoplay:
		_finish_autoplay()
		return
	if score > int(best.get("score", 0)):
		best["score"] = score
		new_record = true
	_save_best()
	result_label.text = "スコア %d%s\nけした列 %d\n最大同時消し %d\nレベル %d\n自己ベスト %d" % [
		score, "  (新記録！)" if new_record else "", total_lines, max_clear, level, int(best.get("score", 0))]
	result_panel.visible = true
	if demo:
		demo_transition_time = 5.0
	_publish_web_state()

func _load_best() -> void:
	if not FileAccess.file_exists(BEST_PATH):
		return
	var f := FileAccess.open(BEST_PATH, FileAccess.READ)
	if f == null:
		return
	var d = JSON.parse_string(f.get_as_text())
	if d is Dictionary:
		best["score"] = int(d.get("score", 0))

func _save_best() -> void:
	var f := FileAccess.open(BEST_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("best.json を書けなかった: %s" % FileAccess.get_open_error())
		return
	f.store_string(JSON.stringify(best))

# ---------------------------------------------------------------- 入力

func _pointer_local(screen_pos: Vector2) -> Vector2:
	return world.get_global_transform_with_canvas().affine_inverse() * screen_pos

func _unhandled_input(event: InputEvent) -> void:
	if state != State.PLAY or autoplay or demo:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		var lp := _pointer_local(event.position)
		if event.pressed:
			pointer_active = true
			pointer_start_pos = lp
			pointer_start_time = Time.get_ticks_msec() / 1000.0
			pointer_move_ref_x = lp.x
			pointer_hard_drop_done = false
			pointer_history = [{"t": pointer_start_time, "y": lp.y}]
			soft_drop_drag = false
		else:
			if pointer_active:
				var dist := pointer_start_pos.distance_to(lp)
				var dt := Time.get_ticks_msec() / 1000.0 - pointer_start_time
				if not pointer_hard_drop_done and dist < TAP_MAX_DIST and dt < TAP_MAX_TIME:
					_rotate_from_tap(lp.x)
			pointer_active = false
			soft_drop_drag = false
	elif event is InputEventMouseMotion and pointer_active:
		_handle_drag(_pointer_local(event.position))
	elif event is InputEventKey and event.pressed and not event.echo:
		_handle_key(event.keycode)

func _handle_drag(lp: Vector2) -> void:
	while lp.x - pointer_move_ref_x >= MOVE_STEP_PX:
		_move(1)
		pointer_move_ref_x += MOVE_STEP_PX
	while pointer_move_ref_x - lp.x >= MOVE_STEP_PX:
		_move(-1)
		pointer_move_ref_x -= MOVE_STEP_PX
	var now := Time.get_ticks_msec() / 1000.0
	pointer_history.append({"t": now, "y": lp.y})
	while pointer_history.size() > 1 and now - pointer_history[0]["t"] > SWIPE_MAX_TIME:
		pointer_history.pop_front()
	if not pointer_hard_drop_done:
		var oldest = pointer_history[0]
		if lp.y - oldest["y"] >= SWIPE_MIN_DY:
			_hard_drop_current()
			pointer_hard_drop_done = true
			soft_drop_drag = false
			return
	var dy_total := lp.y - pointer_start_pos.y
	soft_drop_drag = dy_total >= SOFT_DRAG_MIN_DY

func _rotate_from_tap(x: float) -> void:
	var mid := BOARD_ORIGIN.x + BOARD_PIXEL_W / 2.0
	_rotate(1 if x >= mid else -1)

func _handle_key(keycode: int) -> void:
	match keycode:
		KEY_LEFT:
			_move(-1)
		KEY_RIGHT:
			_move(1)
		KEY_UP, KEY_X:
			_rotate(1)
		KEY_Z:
			_rotate(-1)
		KEY_SPACE:
			_hard_drop_current()
		KEY_C:
			_hold()

func _move(dcol: int) -> void:
	var moved = PL.try_move(board, current_piece, dcol)
	if moved != null:
		current_piece = moved
		_after_piece_change()

func _rotate(dir: int) -> void:
	var moved = PL.try_rotate(board, current_piece, dir)
	if moved != null:
		current_piece = moved
		_after_piece_change()

func _after_piece_change() -> void:
	var can_fall = PL.try_soft_drop(board, current_piece) != null
	if can_fall:
		grounded = false
	elif grounded:
		if lock_resets < LOCK_MAX_RESETS:
			lock_time_left = LOCK_DELAY
			lock_resets += 1
	else:
		grounded = true
		lock_time_left = LOCK_DELAY
		lock_resets = 0

func _hard_drop_current() -> void:
	if state != State.PLAY:
		return
	current_piece = PL.hard_drop(board, current_piece)
	_lock_current_piece()

func _hold() -> void:
	if state != State.PLAY:
		return
	var r := PL.apply_hold(current_piece["shape"], held_shape, hold_used)
	if not r["ok"]:
		return
	held_shape = r["held"]
	hold_used = true
	hold_count += 1
	if r["current"] == null:
		_spawn_next()
	else:
		var shape: String = r["current"]
		current_piece = PL.spawn(shape)
		piece_sizes_seen[PL.mass(shape)] = true
		pieces_spawned += 1
		grounded = false
		lock_time_left = 0.0
		lock_resets = 0
		fall_timer = BL.fall_interval_for_level(level)
		if not PL.can_place(board, shape, current_piece["origin"], current_piece["rot"]):
			_end_game(true)
	_refresh_hud()

# ---------------------------------------------------------------- 毎フレーム

func _process(delta: float) -> void:
	if OS.has_feature("web"):
		web_state_update_timer -= delta
		if web_state_update_timer <= 0.0:
			web_state_update_timer = 0.5
			_publish_web_state()
	if demo and state != State.PLAY:
		demo_transition_time -= delta
		if demo_transition_time <= 0.0:
			_start_game()
	if state == State.PLAY:
		_update_effects(delta)
	if world:
		world.position = base_layout_pos + _shake_offset()
		world.queue_redraw()

func _shake_offset() -> Vector2:
	if shake_time <= 0.0:
		return Vector2.ZERO
	var mag := 10.0 * (shake_time / 0.25)
	return Vector2(rng.randf_range(-mag, mag), rng.randf_range(-mag, mag))

func _update_effects(delta: float) -> void:
	if shake_time > 0.0:
		shake_time = maxf(0.0, shake_time - delta)
	for f in clearing_flash:
		f["alpha"] = maxf(0.0, f["alpha"] - delta * 3.0)
	clearing_flash = clearing_flash.filter(func(f): return f["alpha"] > 0.0)

func _physics_process(delta: float) -> void:
	if state != State.PLAY:
		return
	var dt := delta
	if autoplay:
		dt = minf(delta * time_scale, 0.5)
	time_left = maxf(0.0, time_left - dt)
	_update_hud_text()
	if time_left <= 0.0:
		_end_game(false)
		return
	if autoplay:
		_autoplay_step()
	elif demo:
		_demo_step(dt)
	else:
		_advance_gravity(dt)

func _update_grounded() -> void:
	var can_fall = PL.try_soft_drop(board, current_piece) != null
	if can_fall:
		grounded = false
	elif not grounded:
		grounded = true
		lock_time_left = LOCK_DELAY
		lock_resets = 0

func _advance_gravity(dt: float) -> void:
	if grounded:
		lock_time_left -= dt
		if lock_time_left <= 0.0:
			_lock_current_piece()
		return
	var soft := soft_drop_drag or Input.is_key_pressed(KEY_DOWN)
	var interval := BL.fall_interval_for_level(level)
	if soft:
		interval = minf(interval, SOFT_DROP_INTERVAL)
	fall_timer -= dt
	if fall_timer <= 0.0:
		fall_timer += interval
		var moved = PL.try_soft_drop(board, current_piece)
		if moved != null:
			current_piece = moved
		_update_grounded()

func _lock_current_piece() -> void:
	var cells := PL.absolute_cells(current_piece)
	board = BL.lock_cells(board, cells, PL.color_id(current_piece["shape"]))
	var full_rows := BL.find_full_rows(board)
	var n := full_rows.size()
	if n > 0:
		_trigger_clear_fx(full_rows)
		board = BL.clear_rows(board, full_rows)
		total_lines += n
		combo += 1
		score += BL.score_for_clear(n, combo)
		max_clear = maxi(max_clear, n)
		level = BL.level_for_lines(total_lines)
	else:
		combo = 0
	grounded = false
	lock_time_left = 0.0
	lock_resets = 0
	_spawn_next()
	_refresh_hud()

func _trigger_clear_fx(rows: Array[int]) -> void:
	if autoplay:
		return
	for r in rows:
		clearing_flash.append({"row": r, "alpha": 1.0})
		var y := BOARD_ORIGIN.y + (r - BL.HIDDEN_ROWS) * CELL + CELL / 2.0
		_spawn_bubbles(Vector2(BOARD_ORIGIN.x + BOARD_PIXEL_W / 2.0, y))
	if rows.size() >= 3:
		shake_time = 0.25

func _spawn_bubbles(pos: Vector2) -> void:
	var p := CPUParticles2D.new()
	p.position = pos
	p.one_shot = true
	p.amount = 22
	p.lifetime = 0.6
	p.texture = BUBBLES[total_lines % BUBBLES.size()]
	p.explosiveness = 0.9
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(BOARD_PIXEL_W / 2.0, 8)
	p.direction = Vector2.UP
	p.spread = 40.0
	p.gravity = Vector2(0, -70)
	p.initial_velocity_min = 60.0
	p.initial_velocity_max = 160.0
	p.scale_amount_min = 7.0 / 192.0
	p.scale_amount_max = 13.0 / 192.0
	p.color = Color(1, 1, 1, 0.85)
	p.emitting = true
	particles_root.add_child(p)
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)

func _refresh_hud() -> void:
	_update_hud_text()
	_publish_web_state()

func _update_hud_text() -> void:
	var mins := int(time_left) / 60
	var secs := int(time_left) % 60
	hud_label.text = "のこり %02d:%02d\nスコア %d\nれつ %d\nLv %d" % [mins, secs, score, total_lines, level]

## Web 版の検証用: いまの状態を window.__sangozumi に置く(ブラウザ自動操作から読むだけ)。
func _publish_web_state() -> void:
	if not OS.has_feature("web"):
		return
	var button_pos := Vector2.ZERO
	if state != State.PLAY:
		button_pos = (start_button if state == State.TITLE else retry_button).get_global_rect().get_center()
	var st := {
		"state": ["title", "play", "result"][state],
		"pieces": pieces_spawned, "lines": total_lines, "score": score, "level": level,
		"max_clear": max_clear, "hold_used": hold_used, "hold_count": hold_count,
		"best": int(best.get("score", 0)), "demo": demo,
		"button_center": [button_pos.x, button_pos.y],
		"result_visible": result_panel != null and result_panel.visible,
		"errors": logger.get_errors(),
		"piece_rot": int(current_piece.get("rot", -1)), "piece_origin": str(current_piece.get("origin", "")),
	}
	JavaScriptBridge.eval("window.__sangozumi = %s;" % JSON.stringify(st), true)

# ---------------------------------------------------------------- 自動プレイ(検証用)

func _demo_step(dt: float) -> void:
	# AI の置き場所選択を通常の画面で見せる。駒を盤上で落としてから次へ進む。
	if demo_target.is_empty():
		demo_piece_time += dt
		if demo_piece_time < 0.3:
			return
		var shape: String = current_piece["shape"]
		var placement = AutoAI.best_placement(board, shape)
		if placement == null:
			_end_game(true)
			return
		demo_target = placement
		current_piece = {"shape": shape, "rot": placement["rot"], "origin": placement["origin"]}
		return
	demo_drop_time += dt
	if demo_drop_time < 0.035:
		return
	demo_drop_time -= 0.035
	var moved = PL.try_soft_drop(board, current_piece)
	if moved == null:
		_lock_current_piece()
	else:
		current_piece = moved

func _autoplay_step() -> void:
	if state != State.PLAY:
		return
	var shape: String = current_piece["shape"]
	var placement = AutoAI.best_placement(board, shape)
	if placement == null:
		_end_game(true)
		return
	var piece := {"shape": shape, "rot": placement["rot"], "origin": placement["origin"]}
	current_piece = PL.hard_drop(board, piece)
	_lock_current_piece()

func _finish_autoplay() -> void:
	var sizes := piece_sizes_seen.keys()
	sizes.sort()
	var errs := logger.get_errors()
	var out := {
		"pieces": pieces_spawned, "lines": total_lines, "max_clear": max_clear,
		"level": level, "score": score, "topped_out": topped_out,
		"piece_sizes": sizes, "errors": errs,
	}
	print(JSON.stringify(out))
	if errs > 0:
		printerr("errors: ", logger.first_errors)
	state = State.RESULT
	OS.remove_logger(logger)
	get_tree().quit(0 if errs == 0 else 1)

# ---------------------------------------------------------------- 描画

func _draw_world() -> void:
	var w := world
	var t := clampf(float(level - 1) / 9.0, 0.0, 1.0)
	var visible := get_viewport().get_visible_rect()
	var to_local := w.get_global_transform_with_canvas().affine_inverse()
	var area := Rect2(to_local * visible.position, to_local * visible.end - to_local * visible.position).grow(2.0)
	var source := Rect2(Vector2.ZERO, REEF_BG.get_size())
	# 比率を保った cover。expand で増えた左右・上下まで毎フレーム覆う。
	if area.size.x / area.size.y > source.size.x / source.size.y:
		source.size.y = source.size.x * area.size.y / area.size.x
		source.position.y = (REEF_BG.get_height() - source.size.y) / 2.0
	else:
		source.size.x = source.size.y * area.size.x / area.size.y
		source.position.x = (REEF_BG.get_width() - source.size.x) / 2.0
	var sea_tint := Color.WHITE.lerp(Color(0.28, 0.46, 0.6), t * 0.8)
	w.draw_texture_rect_region(REEF_BG, area, source, sea_tint)

	# 盤の枠
	w.draw_texture_rect(GLASS_WELL,
		Rect2(BOARD_ORIGIN - Vector2(40, 12), Vector2(BOARD_PIXEL_W + 80, BOARD_PIXEL_H + 24)), false)
	w.draw_rect(Rect2(BOARD_ORIGIN, Vector2(BOARD_PIXEL_W, BOARD_PIXEL_H)), Color(0.01, 0.055, 0.085, 0.88))

	# 格子線
	for c in range(BL.COLS + 1):
		var x := BOARD_ORIGIN.x + c * CELL
		w.draw_line(Vector2(x, BOARD_ORIGIN.y), Vector2(x, BOARD_ORIGIN.y + BOARD_PIXEL_H), Color(1, 1, 1, 0.05), 1.0)
	for r in range(BL.VISIBLE_ROWS + 1):
		var y := BOARD_ORIGIN.y + r * CELL
		w.draw_line(Vector2(BOARD_ORIGIN.x, y), Vector2(BOARD_ORIGIN.x + BOARD_PIXEL_W, y), Color(1, 1, 1, 0.05), 1.0)

	# 固定済みのマス
	for r in range(BL.HIDDEN_ROWS, BL.ROWS):
		for c in range(BL.COLS):
			var v := board[BL.idx(c, r)]
			if v != BL.EMPTY:
				_draw_cell(w, c, r, v, 1.0)

	# 消える演出(光の帯)
	for f in clearing_flash:
		var r: int = f["row"]
		if r < BL.HIDDEN_ROWS:
			continue
		var y := BOARD_ORIGIN.y + (r - BL.HIDDEN_ROWS) * CELL
		w.draw_texture_rect(CLEAR_BAND, Rect2(BOARD_ORIGIN.x, y, BOARD_PIXEL_W, CELL), false,
			Color(1, 1, 1, f["alpha"] * 0.8))

	if state == State.PLAY and not current_piece.is_empty():
		# 着地位置の薄い影
		var ghost := PL.hard_drop(board, current_piece)
		var ghost_id: int = PL.color_id(ghost["shape"])
		for p in PL.absolute_cells(ghost):
			_draw_cell(w, p.x, p.y, ghost_id, 0.25)
		# 落下中の形
		var current_id: int = PL.color_id(current_piece["shape"])
		for p in PL.absolute_cells(current_piece):
			_draw_cell(w, p.x, p.y, current_id, 1.0)

	# 「つぎ」
	# 三つの小皿が描かれた中央帯だけを使い、予告セルの位置とそろえる。
	w.draw_texture_rect_region(NEXT_FRAME, Rect2(68, 47, 254, 85), Rect2(27, 130, 410, 158))
	_ensure_queue(3)
	for i in range(mini(3, piece_queue.size())):
		_draw_shape_preview(w, piece_queue[i], NEXT_RECTS[i])

	# 「ひかえ」
	w.draw_texture_rect(HOLD_FRAME, HOLD_RECT, false, Color(1, 1, 1, 0.55 if hold_used else 1.0))
	if held_shape != null:
		_draw_shape_preview(w, held_shape, HOLD_RECT)

func _draw_cell(ci: CanvasItem, col: int, row: int, color_id: int, alpha: float) -> void:
	if row < BL.HIDDEN_ROWS:
		return
	var pos := BOARD_ORIGIN + Vector2(col * CELL, (row - BL.HIDDEN_ROWS) * CELL)
	ci.draw_texture_rect(CELLS[color_id - 1], Rect2(pos + Vector2(2, 2), Vector2(CELL - 4, CELL - 4)),
		false, Color(1, 1, 1, alpha))

func _draw_shape_preview(ci: CanvasItem, shape: String, rect: Rect2) -> void:
	var cells: Array = PL.SHAPES[shape]
	var min_c := PL.BOX
	var max_c := -1
	var min_r := PL.BOX
	var max_r := -1
	for p in cells:
		min_c = mini(min_c, p.x)
		max_c = maxi(max_c, p.x)
		min_r = mini(min_r, p.y)
		max_r = maxi(max_r, p.y)
	var w_cells := max_c - min_c + 1
	var h_cells := max_r - min_r + 1
	var cell := minf(rect.size.x / w_cells, rect.size.y / h_cells) * 0.8
	var total := Vector2(cell * w_cells, cell * h_cells)
	var origin := rect.position + (rect.size - total) / 2.0
	var tex: Texture2D = CELLS[PL.color_id(shape) - 1]
	for p in cells:
		var pos := origin + Vector2((p.x - min_c) * cell, (p.y - min_r) * cell)
		ci.draw_texture_rect(tex, Rect2(pos + Vector2(1, 1), Vector2(cell - 2, cell - 2)), false)
