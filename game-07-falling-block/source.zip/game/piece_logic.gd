class_name PieceLogic
## サンゴのかけら8種(3マス2種・5マス6種)の純粋関数。盤への反映(lock)以外は盤を変更しない。
## 権利の線: 4マスの形は1つも定義しない。配色・回転のずらし表は本作独自。

const BL := preload("res://board_logic.gd")
const BOX := 5  ## 各形はこのBOX×BOXの枠内で表す(回転はこの枠の中で90度ずつ)

## 各形は回転0の姿での(col,row)のマス目。枠は0..BOX-1。
const SHAPES := {
	"straight3": [Vector2i(1, 2), Vector2i(2, 2), Vector2i(3, 2)],
	"kagi3": [Vector2i(2, 1), Vector2i(2, 2), Vector2i(3, 2)],
	"p5": [Vector2i(1, 1), Vector2i(2, 1), Vector2i(1, 2), Vector2i(2, 2), Vector2i(1, 3)],
	"u5": [Vector2i(1, 1), Vector2i(3, 1), Vector2i(1, 2), Vector2i(2, 2), Vector2i(3, 2)],
	"t5": [Vector2i(1, 1), Vector2i(2, 1), Vector2i(3, 1), Vector2i(2, 2), Vector2i(2, 3)],
	"l5": [Vector2i(1, 0), Vector2i(1, 1), Vector2i(1, 2), Vector2i(1, 3), Vector2i(2, 3)],
	"v5": [Vector2i(1, 1), Vector2i(1, 2), Vector2i(1, 3), Vector2i(2, 3), Vector2i(3, 3)],
	"straight5": [Vector2i(0, 2), Vector2i(1, 2), Vector2i(2, 2), Vector2i(3, 2), Vector2i(4, 2)],
}

## 出現順を決める袋詰めで参照する並び(色idはこの並びの1始まりの番号)。
const SHAPE_ORDER := ["straight3", "kagi3", "p5", "u5", "t5", "l5", "v5", "straight5"]

## サンゴ色・珊瑚礁の海の独自パレット(既存作の水色棒/黄色四角…の対応を避ける)。
const COLORS := {
	"straight3": Color("ff7f6b"),
	"kagi3": Color("ffb648"),
	"p5": Color("ff5f96"),
	"u5": Color("2fd9c4"),
	"t5": Color("7f7bff"),
	"l5": Color("ffe15c"),
	"v5": Color("ff9ecf"),
	"straight5": Color("36c98a"),
}

## 本作独自の簡単なずらし表(既存作の壁けりの表をそのまま写さない)。
## (0,0) → (±1,0) → (0,-1) → (±2,0) の順に試す。
const KICKS: Array[Vector2i] = [
	Vector2i(0, 0), Vector2i(1, 0), Vector2i(-1, 0),
	Vector2i(0, -1), Vector2i(2, 0), Vector2i(-2, 0),
]

static func mass(shape: String) -> int:
	return SHAPES[shape].size()

static func color_id(shape: String) -> int:
	return SHAPE_ORDER.find(shape) + 1

static func shape_by_color_id(cid: int) -> String:
	return SHAPE_ORDER[cid - 1]

static func color_for_id(cid: int) -> Color:
	return COLORS[shape_by_color_id(cid)]

## BOX枠内で時計回りに90度 times 回す: (x,y) -> (BOX-1-y, x)
static func _rotate_cell(p: Vector2i, times: int) -> Vector2i:
	var r := p
	for _i in range(posmod(times, 4)):
		r = Vector2i(BOX - 1 - r.y, r.x)
	return r

static func local_cells(shape: String, rot: int) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	for p in SHAPES[shape]:
		out.append(_rotate_cell(p, rot))
	return out

## 出現時の原点(盤座標)。形の実際の幅で中央寄せし、形の上端が row0 に来るようにする。
static func spawn_origin(shape: String) -> Vector2i:
	var cells: Array = SHAPES[shape]
	var min_c := BOX
	var max_c := -1
	var min_r := BOX
	for p in cells:
		min_c = mini(min_c, p.x)
		max_c = maxi(max_c, p.x)
		min_r = mini(min_r, p.y)
	var width := max_c - min_c + 1
	var origin_col := int((BL.COLS - width) / 2) - min_c
	var origin_row := -min_r
	return Vector2i(origin_col, origin_row)

static func spawn(shape: String) -> Dictionary:
	return {"shape": shape, "rot": 0, "origin": spawn_origin(shape)}

## {pos:Vector2i, color:int} の配列(絶対盤座標)。
static func cells_with_color(piece: Dictionary) -> Array:
	var out := []
	var cid := color_id(piece["shape"])
	var origin: Vector2i = piece["origin"]
	for p in local_cells(piece["shape"], piece["rot"]):
		out.append({"pos": origin + p, "color": cid})
	return out

static func absolute_cells(piece: Dictionary) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	var origin: Vector2i = piece["origin"]
	for p in local_cells(piece["shape"], piece["rot"]):
		out.append(origin + p)
	return out

static func can_place(board: PackedByteArray, shape: String, origin: Vector2i, rot: int) -> bool:
	for p in local_cells(shape, rot):
		var ap := origin + p
		if not BL.cell_free(board, ap.x, ap.y):
			return false
	return true

static func try_move(board: PackedByteArray, piece: Dictionary, dcol: int):
	var no: Vector2i = piece["origin"] + Vector2i(dcol, 0)
	if not can_place(board, piece["shape"], no, piece["rot"]):
		return null
	var out := piece.duplicate()
	out["origin"] = no
	return out

static func try_soft_drop(board: PackedByteArray, piece: Dictionary):
	var no: Vector2i = piece["origin"] + Vector2i(0, 1)
	if not can_place(board, piece["shape"], no, piece["rot"]):
		return null
	var out := piece.duplicate()
	out["origin"] = no
	return out

static func hard_drop(board: PackedByteArray, piece: Dictionary) -> Dictionary:
	var cur := piece.duplicate()
	while true:
		var nxt = try_soft_drop(board, cur)
		if nxt == null:
			break
		cur = nxt
	return cur

## 時計回り(dir=1)/反時計回り(dir=-1)。回した先がふさがっていたら KICKS の順にずらして試す。
static func try_rotate(board: PackedByteArray, piece: Dictionary, dir: int):
	var new_rot := posmod(piece["rot"] + dir, 4)
	for k in KICKS:
		var no: Vector2i = piece["origin"] + k
		if can_place(board, piece["shape"], no, new_rot):
			var out := piece.duplicate()
			out["origin"] = no
			out["rot"] = new_rot
			return out
	return null

## 「ひかえ」の純粋な状態遷移。1個につき1回まで(used=trueなら不可)。
## held_shape が無ければ current を預けるだけ(呼び出し側が次の形を current に据える)。
static func apply_hold(current_shape: String, held_shape, used: bool) -> Dictionary:
	if used:
		return {"ok": false, "current": current_shape, "held": held_shape}
	if held_shape == null:
		return {"ok": true, "current": null, "held": current_shape}
	return {"ok": true, "current": held_shape, "held": current_shape}

## 回転後の姿の上端がちょうど row0 に来る行を返す(回転ごとに上端の位置が変わるため個別に計算する)。
static func _top_row_for_rotation(shape: String, rot: int) -> int:
	var min_r := BOX
	for p in local_cells(shape, rot):
		min_r = mini(min_r, p.y)
	return -min_r

## 有効な (origin, rot) の組を全部返す(自動プレイ/評価用)。各回転で上端が row0 に来る行に置いて列挙する。
static func enumerate_placements(board: PackedByteArray, shape: String) -> Array:
	var out := []
	for rot in range(4):
		var row := _top_row_for_rotation(shape, rot)
		for col in range(-(BOX - 1), BL.COLS):
			var origin := Vector2i(col, row)
			if can_place(board, shape, origin, rot):
				out.append({"origin": origin, "rot": rot})
	return out
