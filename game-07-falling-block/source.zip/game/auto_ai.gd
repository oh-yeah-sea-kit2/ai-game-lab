class_name AutoAI
## 自動プレイ用の評価器。置ける場所(列×向き)を全部試し、
## 「穴の数・高さ・でこぼこ・消える列」で評価して最良の場所を返す。

const BL := preload("res://board_logic.gd")
const PL := preload("res://piece_logic.gd")

const W_HOLES := -4.0
const W_HEIGHT := -0.55
const W_BUMPY := -0.35
const W_LINES := 2.0
const W_BIG_CLEAR := 1.5  ## 4列以上の同時消しをさらに優遇する

## 戻り値: {"origin":Vector2i, "rot":int} または、置ける場所が無ければ null。
static func best_placement(board: PackedByteArray, shape: String):
	var candidates := PL.enumerate_placements(board, shape)
	if candidates.is_empty():
		return null
	var best = null
	var best_score := -INF
	for cand in candidates:
		var piece := {"shape": shape, "rot": cand["rot"], "origin": cand["origin"]}
		var dropped := PL.hard_drop(board, piece)
		var cells := PL.absolute_cells(dropped)
		var locked := BL.lock_cells(board, cells, PL.color_id(shape))
		var full_rows := BL.find_full_rows(locked)
		var lines := full_rows.size()
		var after := BL.clear_rows(locked, full_rows) if lines > 0 else locked
		var heights := BL.column_heights(after)
		var holes := BL.count_holes(after)
		var bump := BL.bumpiness(heights)
		var agg := BL.aggregate_height(heights)
		var score := W_HOLES * float(holes) + W_HEIGHT * float(agg) + W_BUMPY * float(bump) + W_LINES * float(lines)
		if lines >= 4:
			score += W_BIG_CLEAR * float(lines)
		if score > best_score:
			best_score = score
			best = cand
	return best
