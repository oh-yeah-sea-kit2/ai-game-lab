extends Node2D

const MAX_ENEMIES := 1200
const CELL := 96.0
const DURATION := 480.0
const MIDGAME_VISIBLE_FLOOR := 45
const COLORS := [Color("596b9d"), Color("b057a0"), Color("66718b"), Color("9e765e"), Color("f4b94f")]
const ENEMY_DRAW_RADII := [18.0, 15.0, 27.0, 22.0, 62.0]
const WEAPON_NAMES := ["光弾", "光の輪", "連鎖稲妻", "波紋", "追尾光"]
const WEAPON_DETAILS := ["近くの敵へ自動発射・速くなる", "周りを回る光・輪が増える", "影から影へ飛び移る", "広がる波紋・範囲が伸びる", "獲物を追いかける光"]
const UI_FONT := preload("res://fonts/MPLUSRounded1c-Bold-subset.ttf")
const ARENA_BG := preload("res://art/arena_bg.png")
const TITLE_BG := preload("res://art/title_bg.png")
const SHADOWS := [preload("res://art/shadows_00.png"), preload("res://art/shadows_01.png"), preload("res://art/shadows_02.png"), preload("res://art/shadows_03.png"), preload("res://art/shadows_04.png")]
const ORBS := [preload("res://art/orbs_00.png"), preload("res://art/orbs_01.png"), preload("res://art/orbs_02.png"), preload("res://art/orbs_03.png"), preload("res://art/orbs_04.png"), preload("res://art/orbs_05.png"), preload("res://art/orbs_06.png"), preload("res://art/orbs_07.png")]
const EFFECTS := [preload("res://art/effects_00.png"), preload("res://art/effects_01.png"), preload("res://art/effects_02.png"), preload("res://art/effects_03.png")]
const UI_FRAMES := [preload("res://art/ui_frames_00.png"), preload("res://art/ui_frames_01.png"), preload("res://art/ui_frames_02.png")]
const ENEMY_OUTLINE_SHADER := """
shader_type canvas_item;
uniform vec4 outline_color : source_color = vec4(1.0, 0.902, 0.502, 1.0);
uniform float outline_uv = 0.07;
void fragment() {
	vec4 base = texture(TEXTURE, UV) * COLOR;
	vec2 directions[8] = vec2[8](vec2(1.0, 0.0), vec2(-1.0, 0.0), vec2(0.0, 1.0), vec2(0.0, -1.0), vec2(0.7071, 0.7071), vec2(-0.7071, 0.7071), vec2(0.7071, -0.7071), vec2(-0.7071, -0.7071));
	float minimum_alpha = 1.0;
	float maximum_alpha = 0.0;
	for (int i = 0; i < 8; i++) {
		float alpha = texture(TEXTURE, UV + directions[i] * outline_uv).a;
		minimum_alpha = min(minimum_alpha, alpha);
		maximum_alpha = max(maximum_alpha, alpha);
	}
	float edge = max(maximum_alpha - base.a, base.a - minimum_alpha);
	vec3 brighter_body = mix(base.rgb, vec3(0.72, 0.66, 0.90), 0.58);
	COLOR = vec4(mix(brighter_body, outline_color.rgb, edge), max(base.a, edge * outline_color.a));
}
"""

var rng := RandomNumberGenerator.new()
var state := "title"
var autoplay := false
var demo := false
var demo_wait := 0.0
var run_seconds := DURATION
var time_scale := 1.0
var debug_time_scale := 1.0
var enemies_onscreen := 0
var elapsed := 0.0
var spawn_budget := 0.0
var spawned := 0
var killed := 0
var max_alive := 0
var level := 1
var xp := 0
var xp_needed := 12
var hp := 18.0
var max_hp := 18.0
var invincible := 0.0
var player := Vector2.ZERO
var pointer_down := false
var pointer_origin := Vector2.ZERO
var pointer_now := Vector2.ZERO
var level_flash := 0.0
var shake := 0.0
var camera_shake_offset := Vector2.ZERO
var boss_spawned := false
var boss_dead := false
var best := 0
var best_kills := 0
var result_clear := false
var enemy_pos := PackedVector2Array()
var enemy_hp := PackedFloat32Array()
var enemy_type := PackedByteArray()
var enemy_age := PackedFloat32Array()
var grid: Dictionary = {}
var enemy_meshes: Array[MultiMeshInstance2D] = []
var background_sprite: Sprite2D
var last_touch_usec := -1000000
var touch_active := false
var bullets: Array[Dictionary] = []
var drops: Array[Dictionary] = []
var particles: Array[Dictionary] = []
var ripples: Array[Dictionary] = []
var bolt_lines: Array[Dictionary] = []
var weapons := [1, 0, 0, 0, 0]
var weapon_cooldowns := [0.0, 0.0, 0.0, 0.0, 0.0]
var cards: Array[int] = []
var orbit_tick := 0.0
var next_progress := 60.0
var background_points: Array[Vector2] = []
var reach_scale := 1.0
var simulated_view_size := Vector2.ZERO
var min_mid_onscreen := MAX_ENEMIES

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_parse_args()
	var web_seed := _parse_web_debug_params()
	rng.seed = int(_arg_value("--seed=", "1")) if autoplay else web_seed
	background_sprite = Sprite2D.new()
	background_sprite.z_index = -2
	add_child(background_sprite)
	_setup_mesh()
	# Keep the original RNG draws so the same seed produces the same waves and results.
	for i in 80:
		background_points.append(Vector2(rng.randf_range(-1400.0, 1400.0), rng.randf_range(-1400.0, 1400.0)))
	_load_best()
	_refresh_background()
	if autoplay:
		_start_game()
		print("AUTOPLAY engine_viewport=%s game_viewport=%s" % [get_viewport_rect().size, _game_view_size()])
	queue_redraw()

## 検証用: ブラウザの URL に ?debug_speed=8 で通常プレイでも時間経過を速められる（8分プレイを
## 手作業で待てないため）。?seed=1 で乱数を固定し、同条件の再現テストができる。ゲームには
## 出さない・パラメータが無ければ既定どおり（速度1倍・時刻ベースの乱数）で効果なし。
func _parse_web_debug_params() -> int:
	if not OS.has_feature("web"):
		return int(Time.get_ticks_usec())
	var search = JavaScriptBridge.eval("window.location.search", true)
	if typeof(search) == TYPE_STRING:
		demo = _query_enables_demo(search)
	var speed = JavaScriptBridge.eval("new URLSearchParams(window.location.search).get('debug_speed')", true)
	if not demo and typeof(speed) == TYPE_STRING and speed != "":
		debug_time_scale = clampf(float(speed), 1.0, 40.0)
	var seed_param = JavaScriptBridge.eval("new URLSearchParams(window.location.search).get('seed')", true)
	if typeof(seed_param) == TYPE_STRING and seed_param != "":
		return int(seed_param)
	return int(Time.get_ticks_usec())

func _query_enables_demo(search: String) -> bool:
	for parameter in search.trim_prefix("?").split("&"):
		if parameter == "demo=1":
			return true
	return false

func _parse_args() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg == "--autoplay":
			autoplay = true
	run_seconds = maxf(1.0, float(_arg_value("--seconds=", "480")))
	time_scale = clampf(float(_arg_value("--timescale=", "1")), 0.1, 40.0)
	if autoplay:
		var screen := _arg_value("--screen=", "")
		if screen != "":
			var dimensions := screen.split("x")
			if dimensions.size() == 2:
				var width := float(dimensions[0])
				var height := float(dimensions[1])
				if width > 0.0 and height > 0.0:
					var scale := minf(width / 720.0, height / 1280.0)
					simulated_view_size = Vector2(width, height) / scale

func _arg_value(prefix: String, default_value: String) -> String:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with(prefix):
			return arg.substr(prefix.length())
	return default_value

func _game_view_size() -> Vector2:
	return simulated_view_size if simulated_view_size != Vector2.ZERO else get_viewport_rect().size

func _setup_mesh() -> void:
	var outline_shader := Shader.new()
	outline_shader.code = ENEMY_OUTLINE_SHADER
	for kind in 5:
		var instance := MultiMeshInstance2D.new()
		instance.z_index = -1
		instance.texture = SHADOWS[kind]
		var outline_material := ShaderMaterial.new()
		outline_material.shader = outline_shader
		outline_material.set_shader_parameter("outline_color", Color("ffe680"))
		outline_material.set_shader_parameter("outline_uv", 4.0 / (2.0 * ENEMY_DRAW_RADII[kind]))
		instance.material = outline_material
		var quad := QuadMesh.new()
		quad.size = Vector2(2.0, 2.0)
		var multi := MultiMesh.new()
		multi.transform_format = MultiMesh.TRANSFORM_2D
		multi.mesh = quad
		multi.instance_count = MAX_ENEMIES
		multi.visible_instance_count = 0
		instance.multimesh = multi
		add_child(instance)
		enemy_meshes.append(instance)

func _start_game() -> void:
	state = "play"
	elapsed = 0.0
	spawn_budget = 0.0
	spawned = 0
	killed = 0
	max_alive = 0
	min_mid_onscreen = MAX_ENEMIES
	level = 1
	xp = 0
	xp_needed = 12
	hp = 18.0
	max_hp = 18.0
	invincible = 0.0
	player = Vector2.ZERO
	pointer_down = false
	level_flash = 0.0
	shake = 0.0
	camera_shake_offset = Vector2.ZERO
	boss_spawned = false
	boss_dead = false
	enemy_pos.clear()
	enemy_hp.clear()
	enemy_type.clear()
	enemy_age.clear()
	grid.clear()
	bullets.clear()
	drops.clear()
	particles.clear()
	ripples.clear()
	bolt_lines.clear()
	weapons = [1, 0, 0, 0, 0]
	weapon_cooldowns = [0.0, 0.0, 0.0, 0.0, 0.0]
	orbit_tick = 0.0
	next_progress = 10.0
	for instance in enemy_meshes:
		instance.multimesh.visible_instance_count = 0

func _process(delta: float) -> void:
	if demo and not autoplay and (state == "title" or state == "result"):
		demo_wait += delta
		if demo_wait >= (2.5 if state == "title" else 5.0):
			demo_wait = 0.0
			_start_game()
	var scale_for_state := time_scale if autoplay else debug_time_scale
	var dt := minf(delta * scale_for_state, 0.7)
	if state == "play":
		while dt > 0.0 and state == "play":
			var step := minf(dt, 0.05)
			_update_game(step)
			dt -= step
	elif state == "levelup" and (autoplay or demo):
		_choose_card(0)
	camera_shake_offset = Vector2(rng.randf_range(-3.0, 3.0), rng.randf_range(-3.0, 3.0)) if shake > 0.0 else Vector2.ZERO
	if state == "play" or state == "levelup":
		_update_mesh()
	_refresh_background()
	_publish_web_state()
	queue_redraw()

func _update_game(dt: float) -> void:
	elapsed += dt
	invincible = maxf(0.0, invincible - dt)
	level_flash = maxf(0.0, level_flash - dt)
	shake = maxf(0.0, shake - dt)
	_update_reach_scale()
	var direction := _movement_direction()
	player += direction * 270.0 * dt
	_spawn_wave(dt)
	if elapsed >= 420.0 and not boss_spawned:
		boss_spawned = true
		_spawn_enemy(4)
	_move_enemies(dt)
	_rebuild_grid()
	_update_weapons(dt)
	_cleanup_enemies()
	_maintain_midgame_density()
	_update_drops(dt)
	_update_effects(dt)
	if enemy_pos.size() > max_alive:
		max_alive = enemy_pos.size()
	if autoplay and elapsed >= next_progress:
		print("PROGRESS sec=%.0f spawned=%d killed=%d level=%d alive=%d onscreen=%d hp=%.0f" % [elapsed, spawned, killed, level, enemy_pos.size(), enemies_onscreen, hp])
		next_progress += 10.0 if next_progress < 60.0 else 60.0
	if hp <= 0.0 or elapsed >= run_seconds:
		_finish()

## stretch=canvas_items / aspect=expand は、基準 720×1280 と縦横比が離れた画面（横長のPCなど）ほど
## 実際に見える世界の範囲を大きく広げる。武器の射程が固定のままだと、広い画面ほど「届かない・
## 間に合わない」が起きて詰みうる（実測で発覚）。基準解像度の面積に対する比の平方根を全射程に掛けて
## 補う。基準に近い比率（スマホ縦画面など）では 1.0 のまま変わらない。
func _update_reach_scale() -> void:
	var size := _game_view_size()
	reach_scale = maxf(1.0, sqrt((size.x * size.y) / (720.0 * 1280.0)))

func _movement_direction() -> Vector2:
	if autoplay or demo:
		var t := elapsed
		return Vector2(cos(t * 1.0), sin(t * 1.0))
	var keyboard := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if keyboard.length_squared() > 0.0:
		return keyboard
	if pointer_down:
		return (pointer_now - pointer_origin).limit_length(80.0) / 80.0
	return Vector2.ZERO

func _spawn_wave(dt: float) -> void:
	var rate := 22.0 + elapsed * 0.24
	spawn_budget += rate * dt
	while spawn_budget >= 1.0 and enemy_pos.size() < MAX_ENEMIES:
		spawn_budget -= 1.0
		var roll := rng.randf()
		var kind := 0
		if elapsed > 55.0 and roll < minf(0.12 + elapsed / 1800.0, 0.34):
			kind = 1
		elif elapsed > 115.0 and roll < minf(0.23 + elapsed / 1700.0, 0.49):
			kind = 2
		elif elapsed > 170.0 and roll < minf(0.34 + elapsed / 1500.0, 0.64):
			kind = 3
		_spawn_enemy(kind)
	spawn_budget = minf(spawn_budget, 100.0)

func _spawn_enemy(kind: int, at: Vector2 = Vector2.INF) -> void:
	if enemy_pos.size() >= MAX_ENEMIES:
		return
	var location := at
	if location == Vector2.INF:
		var size := _game_view_size()
		var angle := rng.randf_range(0.0, TAU)
		var direction := Vector2.RIGHT.rotated(angle)
		# 画面が縦長でも横長でも、実際の矩形の縁のすぐ外側に湧かせる（円形距離だと
		# 短い辺の方向だけ無駄に遠く湧いて到着が遅れ、序盤が薄く見える原因になっていた）。
		var half := size * 0.5
		var edge_distance := INF
		if absf(direction.x) > 0.001:
			edge_distance = minf(edge_distance, half.x / absf(direction.x))
		if absf(direction.y) > 0.001:
			edge_distance = minf(edge_distance, half.y / absf(direction.y))
		location = player + direction * (edge_distance + rng.randf_range(30.0, 90.0))
	enemy_pos.append(location)
	enemy_hp.append([10.0, 15.0, 74.0, 29.0, 1850.0][kind])
	enemy_type.append(kind)
	enemy_age.append(0.0)
	spawned += 1

## 武器が育った後も画面内に群れが見えるよう、画面の縁近くへ不足分だけ補充する。
## 基準解像度ではなく現在の表示矩形を使うので、縦長と横長で同じ下限になる。
func _maintain_midgame_density() -> void:
	if elapsed < 120.0 or elapsed > 420.0:
		return
	var size := _game_view_size()
	var half := size * 0.5
	var visible := 0
	for i in enemy_pos.size():
		var relative := enemy_pos[i] - player
		if absf(relative.x) < half.x + 18.0 and absf(relative.y) < half.y + 18.0:
			visible += 1
	while visible < MIDGAME_VISIBLE_FLOOR and enemy_pos.size() < MAX_ENEMIES:
		var direction := Vector2.RIGHT.rotated(rng.randf_range(0.0, TAU))
		var edge_distance := minf(half.x / maxf(absf(direction.x), 0.001), half.y / maxf(absf(direction.y), 0.001))
		_spawn_enemy(0, player + direction * edge_distance * 0.9)
		visible += 1

func _move_enemies(dt: float) -> void:
	for i in enemy_pos.size():
		var target := player - enemy_pos[i]
		var distance := target.length()
		if distance > 0.01:
			var kind := enemy_type[i]
			var speed: float = [69.0, 150.0, 47.0, 78.0, 62.0][kind]
			enemy_pos[i] += target / distance * speed * dt
		enemy_age[i] += dt
		if distance < (32.0 if enemy_type[i] == 4 else 20.0) and invincible <= 0.0:
			hp -= 2.0 if enemy_type[i] == 4 else 1.0
			invincible = 0.72
			shake = 0.2

func _cell(point: Vector2) -> Vector2i:
	return Vector2i(floori(point.x / CELL), floori(point.y / CELL))

func _rebuild_grid() -> void:
	grid.clear()
	for i in enemy_pos.size():
		var key := _cell(enemy_pos[i])
		if not grid.has(key):
			grid[key] = []
		grid[key].append(i)

func _nearby(point: Vector2, radius: float) -> Array[int]:
	var found: Array[int] = []
	var low := _cell(point - Vector2.ONE * radius)
	var high := _cell(point + Vector2.ONE * radius)
	for y in range(low.y, high.y + 1):
		for x in range(low.x, high.x + 1):
			var key := Vector2i(x, y)
			if grid.has(key):
				for index in grid[key]:
					found.append(index)
	return found

func _nearest(point: Vector2, radius: float, excluded: Dictionary = {}) -> int:
	var best_index := -1
	var best_distance := radius * radius
	for index in _nearby(point, radius):
		if enemy_hp[index] <= 0.0 or excluded.has(index):
			continue
		var d := point.distance_squared_to(enemy_pos[index])
		if d < best_distance:
			best_index = index
			best_distance = d
	return best_index

## ボスは1体だけなので配列を線形に探す。7分以降の数十秒しか呼ばれず、敵数上限1,200でもコストは小さい。
func _find_boss() -> int:
	for i in enemy_type.size():
		if enemy_type[i] == 4 and enemy_hp[i] > 0.0:
			return i
	return -1

func _damage(index: int, amount: float) -> void:
	if index >= 0 and index < enemy_hp.size() and enemy_hp[index] > 0.0:
		enemy_hp[index] -= amount

func _update_weapons(dt: float) -> void:
	for i in 5:
		weapon_cooldowns[i] -= dt
	if weapon_cooldowns[0] <= 0.0:
		weapon_cooldowns[0] += maxf(0.055, 0.19 - 0.012 * weapons[0])
		var target := -1
		var boss_target := false
		if boss_spawned and not boss_dead:
			target = _find_boss()
			if target >= 0 and player.distance_to(enemy_pos[target]) < 540.0 * reach_scale:
				boss_target = true
			else:
				target = -1
		if target < 0:
			target = _nearest(player, 540.0 * reach_scale)
		if target >= 0:
			_fire_bullet(player, enemy_pos[target], false, boss_target)
	if weapons[1] > 0:
		orbit_tick -= dt
		if orbit_tick <= 0.0:
			orbit_tick = 0.12
			var count := mini(2 + weapons[1], 8)
			for n in count:
				var spot: Vector2 = player + Vector2.RIGHT.rotated(elapsed * 3.0 + TAU * n / count) * (80.0 + weapons[1] * 5.0)
				for index in _nearby(spot, 34.0):
					if spot.distance_squared_to(enemy_pos[index]) < 1000.0:
						_damage(index, 8.0 + weapons[1] * 2.5)
	if weapons[2] > 0 and weapon_cooldowns[2] <= 0.0:
		weapon_cooldowns[2] += maxf(0.35, 1.45 - weapons[2] * 0.09)
		var selected: Dictionary = {}
		var from := player
		for jump in mini(3 + weapons[2] * 2, 18):
			var target := _nearest(from, (320.0 if jump > 0 else 470.0) * reach_scale, selected)
			if target < 0:
				break
			selected[target] = true
			_damage(target, 38.0 + weapons[2] * 14.0)
			bolt_lines.append({"a": from, "b": enemy_pos[target], "life": 0.18})
			from = enemy_pos[target]
	if weapons[3] > 0 and weapon_cooldowns[3] <= 0.0:
		weapon_cooldowns[3] += maxf(0.7, 3.5 - weapons[3] * 0.23)
		ripples.append({"pos": player, "radius": 0.0, "max": (330.0 + weapons[3] * 28.0) * reach_scale, "speed": 430.0 * reach_scale, "hit": {}})
	if weapons[4] > 0 and weapon_cooldowns[4] <= 0.0:
		weapon_cooldowns[4] += maxf(0.11, 0.65 - weapons[4] * 0.055)
		var target := _nearest(player, 600.0 * reach_scale)
		if target >= 0:
			_fire_bullet(player, enemy_pos[target], true)
	_update_bullets(dt)
	_update_ripples(dt)

func _fire_bullet(from: Vector2, toward: Vector2, homing: bool, boss_target: bool = false) -> void:
	var direction := (toward - from).normalized()
	bullets.append({"pos": from, "vel": direction * (390.0 if homing else 620.0), "life": (1.8 if homing else 0.9) * reach_scale, "homing": homing, "boss_target": boss_target})

func _update_bullets(dt: float) -> void:
	for i in range(bullets.size() - 1, -1, -1):
		var shot := bullets[i]
		shot.life -= dt
		if shot.life <= 0.0:
			bullets.remove_at(i)
			continue
		if shot.boss_target:
			var boss_index := _find_boss()
			if boss_index < 0:
				bullets.remove_at(i)
				continue
			shot.vel = (enemy_pos[boss_index] - shot.pos).normalized() * 620.0
			shot.pos += shot.vel * dt
			if shot.pos.distance_squared_to(enemy_pos[boss_index]) < 35.0 * 35.0:
				_damage(boss_index, 19.0 + weapons[0] * 4.0)
				_spawn_particles(shot.pos, 2, Color("8cefff"))
				bullets.remove_at(i)
			continue
		if shot.homing:
			var target := _nearest(shot.pos, 300.0 * reach_scale)
			if target >= 0:
				shot.vel = shot.vel.lerp((enemy_pos[target] - shot.pos).normalized() * 390.0, minf(1.0, dt * 8.0))
		shot.pos += shot.vel * dt
		var hit := _nearest(shot.pos, 20.0)
		if hit >= 0 and shot.pos.distance_squared_to(enemy_pos[hit]) < 420.0:
			_damage(hit, 36.0 + weapons[4] * 12.0 if shot.homing else 19.0 + weapons[0] * 4.0)
			_spawn_particles(shot.pos, 2, Color("8cefff"))
			bullets.remove_at(i)

func _update_ripples(dt: float) -> void:
	for i in range(ripples.size() - 1, -1, -1):
		var pulse := ripples[i]
		var speed: float = pulse.speed
		pulse.radius += speed * dt
		for index in _nearby(pulse.pos, pulse.radius + 18.0):
			if pulse.hit.has(index):
				continue
			var distance: float = pulse.pos.distance_to(enemy_pos[index])
			if absf(distance - pulse.radius) < 30.0 + speed * dt:
				_damage(index, 24.0 + weapons[3] * 9.0)
				pulse.hit[index] = true
		if pulse.radius > pulse.max:
			ripples.remove_at(i)

func _cleanup_enemies() -> void:
	for i in range(enemy_pos.size() - 1, -1, -1):
		if enemy_hp[i] <= 0.0:
			killed += 1
			var kind := enemy_type[i]
			var spot := enemy_pos[i]
			if kind == 4:
				boss_dead = true
			if kind == 3:
				_spawn_enemy(0, spot + Vector2(15.0, 0.0))
				_spawn_enemy(0, spot + Vector2(-15.0, 0.0))
			if drops.size() < 1600:
				drops.append({"pos": spot, "value": 4 if kind == 2 else 2 if kind == 4 else 1})
			_spawn_particles(spot, 3, COLORS[kind])
			_remove_enemy(i)
		elif enemy_type[i] != 4 and (enemy_pos[i].distance_squared_to(player) > 2800.0 * 2800.0 or enemy_age[i] > 42.0):
			_remove_enemy(i)

func _remove_enemy(index: int) -> void:
	var last := enemy_pos.size() - 1
	if index != last:
		enemy_pos[index] = enemy_pos[last]
		enemy_hp[index] = enemy_hp[last]
		enemy_type[index] = enemy_type[last]
		enemy_age[index] = enemy_age[last]
	enemy_pos.remove_at(last)
	enemy_hp.remove_at(last)
	enemy_type.remove_at(last)
	enemy_age.remove_at(last)

func _update_drops(dt: float) -> void:
	for i in range(drops.size() - 1, -1, -1):
		var drop := drops[i]
		var distance: float = drop.pos.distance_to(player)
		var magnet_radius := 600.0 * reach_scale
		if distance < magnet_radius:
			drop.pos = drop.pos.move_toward(player, (650.0 + (magnet_radius - distance) * 2.0) * dt)
		if distance < 25.0:
			xp += drop.value
			drops.remove_at(i)
			if xp >= xp_needed:
				xp -= xp_needed
				level += 1
				xp_needed = int(12.0 + level * 5.0 + pow(level, 1.45))
				level_flash = 0.8
				_offer_cards()
				break

func _offer_cards() -> void:
	state = "levelup"
	cards.clear()
	for i in range(1, 5):
		if weapons[i] == 0:
			cards.append(i)
			break
	var next := level % 5
	while cards.size() < 3:
		if not cards.has(next):
			cards.append(next)
		next = (next + 1) % 5

func _choose_card(index: int) -> void:
	if state != "levelup" or index < 0 or index >= cards.size():
		return
	weapons[cards[index]] += 1
	hp = minf(max_hp, hp + 2.0)
	state = "play"
	level_flash = 0.8

func _update_effects(dt: float) -> void:
	for i in range(particles.size() - 1, -1, -1):
		particles[i].pos += particles[i].vel * dt
		particles[i].life -= dt
		if particles[i].life <= 0.0:
			particles.remove_at(i)
	for i in range(bolt_lines.size() - 1, -1, -1):
		bolt_lines[i].life -= dt
		if bolt_lines[i].life <= 0.0:
			bolt_lines.remove_at(i)

func _spawn_particles(spot: Vector2, count: int, color: Color) -> void:
	if particles.size() > 300:
		return
	for i in count:
		particles.append({"pos": spot, "vel": Vector2.RIGHT.rotated(rng.randf_range(0.0, TAU)) * rng.randf_range(30.0, 100.0), "life": rng.randf_range(0.2, 0.5), "color": color})

func _update_mesh() -> void:
	var size := _game_view_size()
	var center := size * 0.5
	var counts := [0, 0, 0, 0, 0]
	var onscreen := 0
	for i in enemy_pos.size():
		var kind := enemy_type[i]
		var scale_value: float = ENEMY_DRAW_RADII[kind]
		var screen_pos := enemy_pos[i] - player + center + camera_shake_offset
		enemy_meshes[kind].multimesh.set_instance_transform_2d(counts[kind], Transform2D(0.0, Vector2.ONE * scale_value, 0.0, screen_pos))
		counts[kind] += 1
		if screen_pos.x > -scale_value and screen_pos.x < size.x + scale_value and screen_pos.y > -scale_value and screen_pos.y < size.y + scale_value:
			onscreen += 1
	for kind in 5:
		enemy_meshes[kind].multimesh.visible_instance_count = counts[kind]
	enemies_onscreen = onscreen
	if autoplay and elapsed >= 240.0 and elapsed <= 420.0:
		min_mid_onscreen = mini(min_mid_onscreen, onscreen)

## Web 版の検証用: いまの状態を window.__hikari に置く（ブラウザ自動操作から読むだけ。ゲームには影響しない）
func _publish_web_state() -> void:
	if not OS.has_feature("web") or autoplay:
		return
	var st := {"state": state, "elapsed": snappedf(elapsed, 0.01), "alive": enemy_pos.size(),
		"onscreen": enemies_onscreen, "spawned": spawned, "killed": killed, "level": level,
		"hp": hp, "result_visible": state == "result", "cleared": result_clear}
	JavaScriptBridge.eval("window.__hikari = %s;" % JSON.stringify(st), true)

func _finish() -> void:
	state = "result"
	demo_wait = 0.0
	result_clear = elapsed >= DURATION and boss_dead and hp > 0.0
	var survived_seconds := int(elapsed)
	if survived_seconds > best or (survived_seconds == best and killed > best_kills):
		best = survived_seconds
		best_kills = killed
		_save_best()
	if autoplay:
		var output := {"spawned": spawned, "killed": killed, "max_alive": max_alive, "level": level, "survived_sec": snappedf(elapsed, 0.01), "cleared": result_clear, "errors": 0, "min_mid_onscreen": min_mid_onscreen}
		print(JSON.stringify(output))
		get_tree().quit()

func _load_best() -> void:
	if FileAccess.file_exists("user://best.json"):
		var file := FileAccess.open("user://best.json", FileAccess.READ)
		if file:
			var value = JSON.parse_string(file.get_as_text())
			if value is Dictionary:
				best = int(value.get("seconds", 0))
				best_kills = int(value.get("kills", 0))

func _save_best() -> void:
	var file := FileAccess.open("user://best.json", FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify({"seconds": best, "kills": best_kills}))

func _input(event: InputEvent) -> void:
	if demo and not autoplay:
		return
	if event is InputEventKey and event.pressed and not event.echo and state == "levelup":
		if event.keycode >= KEY_1 and event.keycode <= KEY_3:
			_choose_card(event.keycode - KEY_1)
	if event is InputEventScreenTouch:
		last_touch_usec = Time.get_ticks_usec()
		touch_active = event.pressed
		_pointer_event(event.position, event.pressed, false)
	elif event is InputEventScreenDrag:
		last_touch_usec = Time.get_ticks_usec()
		_pointer_event(event.position, true, true)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if not touch_active and Time.get_ticks_usec() - last_touch_usec > 250000:
			_pointer_event(event.position, event.pressed, false)
	elif event is InputEventMouseMotion and pointer_down and not touch_active:
		_pointer_event(event.position, true, true)

func _pointer_event(point: Vector2, pressed: bool, drag: bool) -> void:
	if autoplay:
		return
	if not drag and pressed:
		if state == "title" or state == "result":
			_start_game()
			return
		if state == "levelup":
			var index := _card_at(point)
			if index >= 0:
				_choose_card(index)
			return
		if state == "play":
			pointer_down = true
			pointer_origin = point
			pointer_now = point
	elif drag and pointer_down and state == "play":
		pointer_now = point
	elif not pressed:
		pointer_down = false

func _card_at(point: Vector2) -> int:
	var size := _visible_canvas_rect().size
	var scale_value := minf(1.0, size.x / 720.0)
	var width := minf(610.0 * scale_value, size.x - 36.0)
	var top := size.y * 0.5 - 232.0 * scale_value
	for i in 3:
		var rect := Rect2(Vector2((size.x - width) * 0.5, top + i * 156.0 * scale_value), Vector2(width, 138.0 * scale_value))
		if rect.has_point(point):
			return i
	return -1

func _visible_canvas_rect() -> Rect2:
	var viewport_rect := get_viewport().get_visible_rect()
	var inverse := get_viewport().get_canvas_transform().affine_inverse()
	var a := inverse * viewport_rect.position
	var b := inverse * viewport_rect.end
	return Rect2(a, b - a)

func _refresh_background() -> void:
	var rect := _visible_canvas_rect()
	var texture: Texture2D = TITLE_BG if state == "title" else ARENA_BG
	background_sprite.texture = texture
	background_sprite.position = rect.get_center()
	var cover := maxf(rect.size.x / texture.get_width(), rect.size.y / texture.get_height())
	background_sprite.scale = Vector2.ONE * cover

func _draw() -> void:
	var size := _visible_canvas_rect().size
	if state == "title":
		_draw_title(size)
		return
	_draw_world(size)
	if state == "levelup":
		_draw_levelup(size)
	_draw_hud(size)
	if state == "result":
		_draw_result(size)

func _sprite(texture: Texture2D, center: Vector2, diameter: Vector2, tint: Color = Color.WHITE) -> void:
	draw_texture_rect(texture, Rect2(center - diameter * 0.5, diameter), false, tint)

func _frame(texture: Texture2D, rect: Rect2, edge: float = 30.0, modulation: Color = Color.WHITE) -> void:
	var source := Vector2(texture.get_width(), texture.get_height())
	var x_src := [0.0, edge, source.x - edge, source.x]
	var y_src := [0.0, edge, source.y - edge, source.y]
	var x_dst := [rect.position.x, rect.position.x + edge, rect.end.x - edge, rect.end.x]
	var y_dst := [rect.position.y, rect.position.y + edge, rect.end.y - edge, rect.end.y]
	for y in 3:
		for x in 3:
			draw_texture_rect_region(texture, Rect2(x_dst[x], y_dst[y], x_dst[x + 1] - x_dst[x], y_dst[y + 1] - y_dst[y]), Rect2(x_src[x], y_src[y], x_src[x + 1] - x_src[x], y_src[y + 1] - y_src[y]), modulation)

func _screen(world: Vector2, size: Vector2) -> Vector2:
	return world - player + size * 0.5 + camera_shake_offset

func _draw_world(size: Vector2) -> void:
	for drop in drops:
		var point := _screen(drop.pos, size)
		if point.x > -10.0 and point.x < size.x + 10.0 and point.y > -10.0 and point.y < size.y + 10.0:
			_sprite(ORBS[4], point, Vector2.ONE * 12.0)
	for pulse in ripples:
		_sprite(EFFECTS[0], _screen(pulse.pos, size), Vector2.ONE * pulse.radius * 2.0, Color(1, 1, 1, 0.75))
	if weapons[1] > 0:
		var count := mini(2 + weapons[1], 8)
		for n in count:
			var position: Vector2 = size * 0.5 + camera_shake_offset + Vector2.RIGHT.rotated(elapsed * 3.0 + TAU * n / count) * (80.0 + weapons[1] * 5.0)
			_sprite(ORBS[3], position, Vector2.ONE * 28.0)
	for shot in bullets:
		var point := _screen(shot.pos, size)
		_sprite(ORBS[2] if shot.homing or shot.boss_target else ORBS[1], point, Vector2.ONE * (20.0 if shot.homing or shot.boss_target else 12.0))
	for bolt in bolt_lines:
		var a := _screen(bolt.a, size)
		var b := _screen(bolt.b, size)
		var delta := b - a
		draw_set_transform(a, delta.angle(), Vector2(delta.length() / EFFECTS[1].get_width(), 0.18))
		draw_texture(EFFECTS[1], Vector2(0, -EFFECTS[1].get_height() * 0.5))
		draw_set_transform(Vector2.ZERO)
	for particle in particles:
		_sprite(EFFECTS[3] if particle.life > 0.32 else ORBS[7], _screen(particle.pos, size), Vector2.ONE * (5.0 + particle.life * 7.0), Color(particle.color.r, particle.color.g, particle.color.b, 1.0))
	var core := size * 0.5 + camera_shake_offset
	if level_flash > 0.0:
		_sprite(EFFECTS[2], core, Vector2.ONE * (96.0 + level_flash * 140.0), Color(1, 1, 1, level_flash * 0.55))
	_sprite(ORBS[0], core, Vector2.ONE * 46.0, Color.WHITE if invincible > 0.0 and int(elapsed * 18.0) % 2 == 0 else Color(1, 1, 1, 0.95))
	if pointer_down:
		_sprite(ORBS[5], pointer_origin, Vector2.ONE * 104.0, Color(1, 1, 1, 0.65))
		_sprite(ORBS[6], pointer_origin + (pointer_now - pointer_origin).limit_length(52.0), Vector2.ONE * 38.0, Color(1, 1, 1, 0.75))

func _draw_hud(size: Vector2) -> void:
	var width := minf(size.x - 40.0, 680.0)
	var left := (size.x - width) * 0.5
	_frame(UI_FRAMES[0], Rect2(left, 26, width, 120))
	draw_rect(Rect2(left + 18, 45, width - 36, 9), Color("293a54"))
	draw_rect(Rect2(left + 18, 45, (width - 36) * hp / max_hp, 9), Color("ff8eaa"))
	draw_rect(Rect2(left + 18, 61, width - 36, 5), Color("293a54"))
	draw_rect(Rect2(left + 18, 61, (width - 36) * float(xp) / xp_needed, 5), Color("67f0d7"))
	draw_rect(Rect2(left + 10, 79, width - 20, 47), Color(0.0, 0.0, 0.0, 0.9))
	_text("%02d:%02d / 08:00" % [int(elapsed) / 60, int(elapsed) % 60], Vector2(left + 18, 109), 30, Color.WHITE)
	var status := "Lv%d 撃破%d" % [level, killed]
	var status_width := UI_FONT.get_string_size(status, HORIZONTAL_ALIGNMENT_LEFT, -1, 30).x
	_text(status, Vector2(left + width - status_width - 18, 109), 30, Color.WHITE)
	if boss_spawned and not boss_dead:
		_text_center("最後の影が出現", Vector2(size.x * 0.5, 166), 26, Color("ffd17e"))

func _draw_title(size: Vector2) -> void:
	var center := size * 0.5
	_sprite(EFFECTS[0], center + Vector2(0, -220), Vector2.ONE * 192.0, Color(1, 1, 1, 0.55))
	_sprite(ORBS[0], center + Vector2(0, -220), Vector2.ONE * 80.0)
	draw_rect(Rect2(center + Vector2(-285, -91), Vector2(570, 230)), Color(0.015, 0.035, 0.10, 0.72))
	_text_center("ヒカリノワ", center + Vector2(0, -45), 54, Color.WHITE)
	_text_center("影の群れを生き延びろ", center + Vector2(0, 5), 27, Color("a8d4ec"))
	_text_center("8分間 / 敵1万体", center + Vector2(0, 67), 27, Color("d1edff"))
	_text_center("自己ベスト　%02d:%02d ／ %d 撃破" % [best / 60, best % 60, best_kills], center + Vector2(0, 112), 26, Color("a5fff0"))
	_draw_button(center + Vector2(0, 228), "タップしてはじめる")
	_text_center("画面をなぞって移動", center + Vector2(0, 320), 26, Color("b2d6eb"))
	_text_center("PCはWASD/矢印キーでも移動", center + Vector2(0, 357), 26, Color("b2d6eb"))

func _draw_levelup(size: Vector2) -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.01, 0.02, 0.06, 0.82))
	var scale_value := minf(1.0, size.x / 720.0)
	_text_center("レベル %d" % level, Vector2(size.x * 0.5, size.y * 0.5 - 266.0 * scale_value), int(42 * scale_value), Color("c8fcff"))
	_text_center("強化を選ぼう", Vector2(size.x * 0.5, size.y * 0.5 - 234.0 * scale_value), int(26 * scale_value), Color("bddded"))
	var width := minf(610.0 * scale_value, size.x - 36.0)
	var top := size.y * 0.5 - 232.0 * scale_value
	for i in 3:
		var pos := Vector2((size.x - width) * 0.5, top + i * 156.0 * scale_value)
		_frame(UI_FRAMES[1], Rect2(pos, Vector2(width, 138.0 * scale_value)), 30.0, Color(0.72, 0.82, 1.0, 0.72))
		var weapon := cards[i]
		_text("0%d" % (i + 1), pos + Vector2(23.0, 49.0) * scale_value, int(26 * scale_value), Color("65e5e1"))
		_text(WEAPON_NAMES[weapon], pos + Vector2(112.0, 48.0) * scale_value, int(27 * scale_value), Color.WHITE)
		_text("新規習得" if weapons[weapon] == 0 else "Lv%d → %d" % [weapons[weapon], weapons[weapon] + 1], pos + Vector2(112.0, 80.0) * scale_value, int(26 * scale_value), Color("b0ffee"))
		_text(WEAPON_DETAILS[weapon], pos + Vector2(112.0, 113.0) * scale_value, int(26 * scale_value), Color("d0e3f5"))

func _draw_result(size: Vector2) -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.01, 0.02, 0.06, 0.84))
	var center := size * 0.5
	_text_center("光は生き残った" if result_clear else "光は消えた", center + Vector2(0, -270), 43, Color("b9fbff") if result_clear else Color("ffd3d8"))
	_text_center("生存時間　%02d:%02d" % [int(elapsed) / 60, int(elapsed) % 60], center + Vector2(0, -144), 27, Color.WHITE)
	_text_center("倒した数　%d" % killed, center + Vector2(0, -82), 27, Color.WHITE)
	_text_center("わいた総数　%d" % spawned, center + Vector2(0, -20), 27, Color.WHITE)
	_text_center("到達レベル　%d" % level, center + Vector2(0, 42), 27, Color.WHITE)
	_text_center("自己ベスト　%02d:%02d ／ %d 撃破" % [best / 60, best % 60, best_kills], center + Vector2(0, 130), 26, Color("7debdc"))
	_draw_button(center + Vector2(0, 248), "もう一度あそぶ")

func _draw_button(center: Vector2, label: String) -> void:
	var rect := Rect2(center - Vector2(230, 39), Vector2(460, 78))
	_frame(UI_FRAMES[2], rect)
	_text_center(label, center + Vector2(0, 10), 29, Color.WHITE)

func _text(value: String, position: Vector2, font_size: int, color: Color) -> void:
	draw_string(UI_FONT, position, value, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, color)

func _text_center(value: String, position: Vector2, font_size: int, color: Color) -> void:
	var width := UI_FONT.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	_text(value, position - Vector2(width * 0.5, 0.0), font_size, color)
