extends Node2D
## 合体の光（広がって消える輪）。

var color := Color.WHITE
var base_r := 20.0
var t := 0.0
const LIFE := 0.35

func _process(delta: float) -> void:
	t += delta
	if t >= LIFE:
		queue_free()
		return
	queue_redraw()

func _draw() -> void:
	var k := t / LIFE
	var c := color.lightened(0.5)
	c.a = (1.0 - k) * 0.8
	draw_circle(Vector2.ZERO, base_r * (0.6 + 0.9 * k), Color(1, 1, 1, (1.0 - k) * 0.35))
	draw_arc(Vector2.ZERO, base_r * (0.8 + 1.0 * k), 0, TAU, 48, c, 6.0 * (1.0 - k) + 1.0, true)
