extends Node2D
## ポコポコ星合体 — 本体。
## 画面の基準は 720x1280。横長でも縦長でも、箱を含む World ノードを画面中央に置き直す。

const ErrorCounter := preload("res://error_counter.gd")
const Fx := preload("res://fx.gd")
const BACKGROUND := preload("res://art/bg.png")

const BASE := Vector2(720, 1280)
const BOX_L := 80.0
const BOX_R := 640.0
const BOX_TOP := 300.0      # 見た目の壁の上端
const FLOOR_Y := 1180.0
const LINE_Y := 330.0       # これより上に静止した星が居続けたら終わり
const DROP_Y := 235.0
const OVER_LIMIT := 2.0     # 線越えの許容秒数
const DROP_COOLDOWN := 0.45
const CHAIN_WINDOW := 0.9   # この秒数以内に続いた合体を連鎖とみなす
const POINTS := [0, 1, 3, 6, 10, 15, 21, 28, 36, 45, 55]
const GALAXY_BONUS := 100
const BEST_PATH := "user://best.json"

enum State { TITLE, PLAY, OVER }

var state := State.TITLE
var rng := RandomNumberGenerator.new()
var logger: ErrorCounter

var world: Node2D
var stars_root: Node2D
var fx_root: Node2D
var stars: Array[Star] = []

var aim_x := 360.0
var aiming := false
var cooldown := 0.0
var current_stage := 0
var next_stage := 0
var score := 0
var max_stage := 0
var drops := 0
var merges := 0
var anomalies := 0
var chain := 0
var last_merge_time := -10.0
var play_time := 0.0
var danger := 0.0
var best := {"score": 0, "stage": 0}
var new_record := false

# 自動プレイ（検証用）
var autoplay := false
var auto_drops_target := 300
var auto_frames := 0
var auto_since_drop := 0
var auto_after_last := 0

# UI
var ui_layer: CanvasLayer
var title_panel: Control
var result_panel: Control
var score_label: Label
var best_label: Label
var result_label: Label
var result_icon: Control
var sounds: Array[AudioStreamWAV] = []
var drop_sound: AudioStreamWAV
var players: Array[AudioStreamPlayer] = []
var player_idx := 0

func _ready() -> void:
	logger = ErrorCounter.new()
	OS.add_logger(logger)
	_parse_args()
	_load_best()
	_build_world()
	_build_ui()
	_build_sounds()
	get_viewport().size_changed.connect(_layout)
	_layout()
	if autoplay:
		_start_game()
	else:
		_show_title()

func _parse_args() -> void:
	var args := OS.get_cmdline_user_args()
	args.append_array(OS.get_cmdline_args())
	var seed_val := int(Time.get_unix_time_from_system())
	for a in args:
		if a == "--autoplay":
			autoplay = true
		elif a.begins_with("--drops="):
			auto_drops_target = int(a.get_slice("=", 1))
		elif a == "--inject-error":
			# 検証の陽性対照: わざとエラーを1件出し、errors が数えられることを確かめる
			push_error.call_deferred("inject-error: 検証用のわざとのエラー")
		elif a.begins_with("--seed="):
			seed_val = int(a.get_slice("=", 1))
	rng.seed = seed_val

# ---------------------------------------------------------------- 組み立て

func _build_world() -> void:
	world = Node2D.new()
	world.name = "World"
	add_child(world)
	world.draw.connect(_draw_world)

	var walls := StaticBody2D.new()
	var mat := PhysicsMaterial.new()
	mat.friction = 0.4
	walls.physics_material_override = mat
	# 左右の壁は見た目より上まで伸ばして、星が箱の外へこぼれないようにする
	_add_wall(walls, Rect2(BOX_L - 100, -800, 100, FLOOR_Y + 900))
	_add_wall(walls, Rect2(BOX_R, -800, 100, FLOOR_Y + 900))
	_add_wall(walls, Rect2(BOX_L - 100, FLOOR_Y, BOX_R - BOX_L + 200, 100))
	world.add_child(walls)

	stars_root = Node2D.new()
	world.add_child(stars_root)
	fx_root = Node2D.new()
	world.add_child(fx_root)

	score_label = _label(40, Color.WHITE)
	score_label.position = Vector2(BOX_L, 70)
	world.add_child(score_label)
	best_label = _label(22, Color(0.8, 0.82, 1.0))
	best_label.position = Vector2(BOX_L, 130)
	world.add_child(best_label)
	var cap := _label(22, Color(0.8, 0.82, 1.0))
	cap.text = "スコア"
	cap.position = Vector2(BOX_L, 40)
	world.add_child(cap)
	var nxt := _label(22, Color(0.8, 0.82, 1.0))
	nxt.text = "つぎ"
	nxt.position = Vector2(BOX_R - 110, 40)
	world.add_child(nxt)

func _add_wall(body: StaticBody2D, r: Rect2) -> void:
	var shape := RectangleShape2D.new()
	shape.size = r.size
	var cs := CollisionShape2D.new()
	cs.shape = shape
	cs.position = r.position + r.size / 2.0
	body.add_child(cs)

func _label(size: int, col: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0.05, 0.05, 0.12))
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	ui_layer.layer = 10
	add_child(ui_layer)

	# タイトル
	title_panel = _overlay()
	var tv := title_panel.get_meta("box") as VBoxContainer
	var t1 := _label(60, Color("ffe38a"))
	t1.text = "ポコポコ星合体"
	t1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tv.add_child(t1)
	var t2 := _label(26, Color.WHITE)
	t2.text = "同じ星どうしがふれると\nひとつ大きな星になる。\n11段目の「銀河」をめざそう。"
	t2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tv.add_child(t2)
	var ladder := Control.new()
	ladder.custom_minimum_size = Vector2(528, 80)
	ladder.draw.connect(func(): _draw_ladder(ladder, Vector2(0, 40), 528.0, 10))
	tv.add_child(ladder)
	var t3 := _label(22, Color(0.8, 0.82, 1.0))
	t3.text = "おして左右になぞる → はなすと落ちる\nPC: ←→ で移動、スペースで落とす"
	t3.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tv.add_child(t3)
	var b1 := _button("あそぶ")
	b1.pressed.connect(_start_game)
	tv.add_child(b1)

	# 結果
	result_panel = _overlay()
	var rv := result_panel.get_meta("box") as VBoxContainer
	var r1 := _label(52, Color("ffe38a"))
	r1.text = "おしまい"
	r1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rv.add_child(r1)
	result_icon = Control.new()
	result_icon.custom_minimum_size = Vector2(200, 180)
	result_icon.draw.connect(func():
		Star.paint(result_icon, result_icon.size / 2.0, minf(80.0, Star.RADII[max_stage]), max_stage))
	rv.add_child(result_icon)
	result_label = _label(30, Color.WHITE)
	result_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rv.add_child(result_label)
	var b2 := _button("もう一度")
	b2.pressed.connect(_start_game)
	rv.add_child(b2)
	result_panel.visible = false

func _overlay() -> Control:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	var dim := ColorRect.new()
	dim.color = Color(0.03, 0.03, 0.1, 0.55)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)
	# 文字が後ろの星と重なって読みにくかったので、角丸の板を敷く
	var card := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.09, 0.09, 0.2, 0.94)
	sb.border_color = Color(0.62, 0.66, 1.0, 0.7)
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(36)
	sb.set_content_margin_all(36)
	card.add_theme_stylebox_override("panel", sb)
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.custom_minimum_size = Vector2(600, 0)
	center.add_child(card)
	var box := VBoxContainer.new()
	box.name = "Box"
	box.add_theme_constant_override("separation", 24)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(box)
	root.set_meta("box", box)
	ui_layer.add_child(root)
	return root

func _button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(320, 96)
	b.add_theme_font_size_override("font_size", 40)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color("ff9f43")
	sb.set_corner_radius_all(48)
	b.add_theme_stylebox_override("normal", sb)
	var sbh := sb.duplicate() as StyleBoxFlat
	sbh.bg_color = Color("ffb86b")
	b.add_theme_stylebox_override("hover", sbh)
	var sbp := sb.duplicate() as StyleBoxFlat
	sbp.bg_color = Color("e0852c")
	b.add_theme_stylebox_override("pressed", sbp)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", Color("2a1740"))
	b.add_theme_color_override("font_hover_color", Color("2a1740"))
	b.add_theme_color_override("font_pressed_color", Color("2a1740"))
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	return b

func _build_sounds() -> void:
	# 段が上がるほど高い音（五音音階で上がっていく）。コードで波形を作る。
	var semis := [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24]
	for s in semis:
		sounds.append(_tone(392.0 * pow(2.0, s / 12.0), 0.32))
	drop_sound = _tone(196.0, 0.12)
	for i in 6:
		var p := AudioStreamPlayer.new()
		p.volume_db = -8.0
		add_child(p)
		players.append(p)

func _tone(freq: float, dur: float) -> AudioStreamWAV:
	var rate := 22050
	var n := int(rate * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / rate
		var env := exp(-t * 9.0) * minf(1.0, t * 400.0)
		var v := sin(TAU * freq * t) * 0.7 + sin(TAU * freq * 2.0 * t) * 0.2
		data.encode_s16(i * 2, int(clampf(v * env, -1.0, 1.0) * 26000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	return w

func _play(stream: AudioStreamWAV) -> void:
	if autoplay:
		# headless の Dummy 音声ドライバでは再生が終わらず、終了時に AudioStreamPlaybackWAV のリーク警告が出たため鳴らさない
		return
	var p := players[player_idx]
	player_idx = (player_idx + 1) % players.size()
	p.stream = stream
	p.play()

# ---------------------------------------------------------------- 画面配置

func _layout() -> void:
	var vp := get_viewport_rect().size
	world.position = ((vp - BASE) / 2.0).floor()
	world.queue_redraw()

# ---------------------------------------------------------------- 状態遷移

func _show_title() -> void:
	state = State.TITLE
	title_panel.visible = true
	result_panel.visible = false
	_refresh_hud()

func _start_game() -> void:
	for s in stars:
		if is_instance_valid(s):
			s.queue_free()
	stars.clear()
	for f in fx_root.get_children():
		f.queue_free()
	score = 0
	max_stage = 0
	drops = 0
	merges = 0
	chain = 0
	play_time = 0.0
	danger = 0.0
	cooldown = 0.3
	aiming = false
	new_record = false
	current_stage = _roll_stage()
	next_stage = _roll_stage()
	title_panel.visible = false
	result_panel.visible = false
	state = State.PLAY
	_refresh_hud()

func _roll_stage() -> int:
	# 下から5段目まで。小さい星ほど出やすくする
	var w := [30, 26, 20, 14, 10]
	var r := rng.randi_range(1, 100)
	var acc := 0
	for i in w.size():
		acc += w[i]
		if r <= acc:
			return i
	return 0

func _game_over() -> void:
	if state != State.PLAY:
		return
	state = State.OVER
	aiming = false
	if not autoplay:
		if score > int(best["score"]):
			best["score"] = score
			new_record = true
		best["stage"] = maxi(int(best["stage"]), max_stage)
		_save_best()
	if autoplay:
		_finish_autoplay(true)
		return
	await get_tree().create_timer(0.8).timeout
	if state != State.OVER:
		return
	result_label.text = "スコア  %d%s\n最大の星  %s\n自己ベスト  %d" % [
		score, "  (新記録！)" if new_record else "", Star.NAMES[max_stage], int(best["score"])]
	result_icon.queue_redraw()
	result_panel.visible = true
	_publish_web_state()

func _load_best() -> void:
	if not FileAccess.file_exists(BEST_PATH):
		return
	var f := FileAccess.open(BEST_PATH, FileAccess.READ)
	if f == null:
		return
	var d = JSON.parse_string(f.get_as_text())
	if d is Dictionary:
		best["score"] = int(d.get("score", 0))
		best["stage"] = int(d.get("stage", 0))

func _save_best() -> void:
	var f := FileAccess.open(BEST_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("best.json を書けなかった: %s" % FileAccess.get_open_error())
		return
	f.store_string(JSON.stringify(best))

# ---------------------------------------------------------------- 入力

func _pointer_local(screen_pos: Vector2) -> Vector2:
	return world.get_global_transform_with_canvas().affine_inverse() * screen_pos

func _unhandled_input(event: InputEvent) -> void:
	if state != State.PLAY or autoplay:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			aiming = true
			_set_aim(_pointer_local(event.position).x)
		elif aiming:
			aiming = false
			_set_aim(_pointer_local(event.position).x)
			_try_drop()
	elif event is InputEventMouseMotion:
		# 押している間（スマホのなぞり）と、PC でマウスを動かしたときに照準が動く
		_set_aim(_pointer_local(event.position).x)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_SPACE or event.keycode == KEY_DOWN:
			_try_drop()

func _set_aim(x: float) -> void:
	var r: float = Star.RADII[current_stage]
	aim_x = clampf(x, BOX_L + r + 2, BOX_R - r - 2)

func _try_drop() -> void:
	if state != State.PLAY or cooldown > 0.0:
		return
	_set_aim(aim_x)
	var s := _spawn(current_stage, Vector2(aim_x, DROP_Y))
	s.linear_velocity = Vector2(0, 120)
	drops += 1
	cooldown = DROP_COOLDOWN
	current_stage = next_stage
	next_stage = _roll_stage()
	_set_aim(aim_x)
	_play(drop_sound)
	_publish_web_state()

func _spawn(stage: int, pos: Vector2) -> Star:
	var s := Star.new()
	s.setup(stage)
	s.position = pos
	stars_root.add_child(s)
	stars.append(s)
	return s

# ---------------------------------------------------------------- 毎フレーム

func _process(delta: float) -> void:
	if state == State.PLAY and not autoplay:
		var dir := 0.0
		if Input.is_key_pressed(KEY_LEFT):
			dir -= 1.0
		if Input.is_key_pressed(KEY_RIGHT):
			dir += 1.0
		if dir != 0.0:
			_set_aim(aim_x + dir * 520.0 * delta)
	world.queue_redraw()

func _physics_process(delta: float) -> void:
	if state != State.PLAY:
		return
	play_time += delta
	cooldown = maxf(0.0, cooldown - delta)
	_check_merges()
	_check_bounds()
	_check_over(delta)
	if autoplay:
		_autoplay_step()

func _check_merges() -> void:
	# 同じ段どうしが触れていたら合体。merging の印で、同じフレームの二重合体を防ぐ
	var snapshot := stars.duplicate()
	for a in snapshot:
		if not is_instance_valid(a) or a.merging:
			continue
		for body in a.get_colliding_bodies():
			var b := body as Star
			if b == null or b == a or b.merging or b.stage != a.stage:
				continue
			_merge(a, b)
			break

func _merge(a: Star, b: Star) -> void:
	a.merging = true
	b.merging = true
	var mid := (a.position + b.position) / 2.0
	var vel := (a.linear_velocity + b.linear_velocity) / 2.0
	var st := a.stage
	stars.erase(a)
	stars.erase(b)
	a.queue_free()
	b.queue_free()
	merges += 1
	if play_time - last_merge_time <= CHAIN_WINDOW:
		chain += 1
	else:
		chain = 1
	last_merge_time = play_time
	var mult := 1.0 + 0.5 * (chain - 1)
	var gained := 0
	var col: Color = Star.COLORS[st]
	var fx_r: float = Star.RADII[st]
	if st < Star.MAX_STAGE:
		var ns := st + 1
		var r: float = Star.RADII[ns]
		mid.x = clampf(mid.x, BOX_L + r, BOX_R - r)
		mid.y = minf(mid.y, FLOOR_Y - r)
		var s := _spawn(ns, mid)
		s.linear_velocity = vel * 0.5
		gained = int(round(POINTS[ns] * mult))
		max_stage = maxi(max_stage, ns)
		col = Star.COLORS[ns]
		fx_r = r
		_play(sounds[ns])
	else:
		# 銀河どうしは消えてボーナス
		gained = int(round(GALAXY_BONUS * mult))
		_play(sounds[Star.MAX_STAGE])
	score += gained
	_effect(mid, fx_r, col, gained)
	_refresh_hud()

func _effect(pos: Vector2, r: float, col: Color, gained: int) -> void:
	var f := Fx.new()
	f.position = pos
	f.color = col
	f.base_r = r
	fx_root.add_child(f)
	var p := CPUParticles2D.new()
	p.position = pos
	p.one_shot = true
	p.amount = 14
	p.lifetime = 0.55
	p.explosiveness = 1.0
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = r * 0.6
	p.direction = Vector2.UP
	p.spread = 180.0
	p.gravity = Vector2(0, 260)
	p.initial_velocity_min = 90.0
	p.initial_velocity_max = 240.0
	p.scale_amount_min = 3.0
	p.scale_amount_max = 6.0
	p.color = col.lightened(0.35)
	p.emitting = true
	fx_root.add_child(p)
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)
	if autoplay:
		return
	var l := _label(30 if chain < 2 else 36, Color("fff3b0"))
	l.text = "+%d" % gained if chain < 2 else "れんさ×%d  +%d" % [chain, gained]
	l.position = pos + Vector2(-60, -r - 40)
	fx_root.add_child(l)
	var tw := l.create_tween()
	tw.tween_property(l, "position:y", l.position.y - 60, 0.7)
	tw.parallel().tween_property(l, "modulate:a", 0.0, 0.7)
	tw.tween_callback(l.queue_free)

func _check_bounds() -> void:
	for s in stars.duplicate():
		var p: Vector2 = s.position
		if p.x < BOX_L - 4 or p.x > BOX_R + 4 or p.y > FLOOR_Y + 4 or p.y < -900 or is_nan(p.x) or is_nan(p.y):
			anomalies += 1
			push_warning("箱の外に出た星を回収: stage=%d pos=%s" % [s.stage, p])
			stars.erase(s)
			s.queue_free()

func _check_over(delta: float) -> void:
	danger = 0.0
	for s in stars:
		if s.merging:
			continue
		var above := s.position.y - s.radius < LINE_Y
		var still := s.linear_velocity.length() < 35.0
		if above and still and s.age > 1.2:
			s.over_time += delta
		else:
			s.over_time = 0.0
		danger = maxf(danger, s.over_time)
		if s.over_time >= OVER_LIMIT:
			_game_over()
			return

func _refresh_hud() -> void:
	score_label.text = str(score)
	_publish_web_state()
	best_label.text = "自己ベスト %d" % maxi(int(best["score"]), score if not autoplay else 0)

## Web 版の検証用: いまの状態を window.__pokopoko に置く（ブラウザ自動操作から読むだけ。ゲームには影響しない）
func _publish_web_state() -> void:
	if not OS.has_feature("web"):
		return
	var st := {"state": ["title", "play", "over"][state], "drops": drops, "merges": merges,
		"score": score, "max_stage": max_stage + 1, "result_visible": result_panel != null and result_panel.visible,
		"errors": logger.get_errors()}
	JavaScriptBridge.eval("window.__pokopoko = %s;" % JSON.stringify(st), true)

# ---------------------------------------------------------------- 描画

func _draw_world() -> void:
	var w := world
	var visible := get_viewport().get_visible_rect()
	var to_world := w.get_screen_transform().affine_inverse()
	var p0: Vector2 = to_world * visible.position
	var p1: Vector2 = to_world * Vector2(visible.end.x, visible.position.y)
	var p2: Vector2 = to_world * visible.end
	var p3: Vector2 = to_world * Vector2(visible.position.x, visible.end.y)
	var visible_left := minf(minf(p0.x, p1.x), minf(p2.x, p3.x))
	var visible_top := minf(minf(p0.y, p1.y), minf(p2.y, p3.y))
	var visible_right := maxf(maxf(p0.x, p1.x), maxf(p2.x, p3.x))
	var visible_bottom := maxf(maxf(p0.y, p1.y), maxf(p2.y, p3.y))
	var visible_world := Rect2(Vector2(visible_left, visible_top),
		Vector2(visible_right - visible_left, visible_bottom - visible_top))
	var cover_scale := maxf(visible_world.size.x / BACKGROUND.get_width(),
		visible_world.size.y / BACKGROUND.get_height())
	var background_size := Vector2(BACKGROUND.get_size()) * cover_scale
	var background_rect := Rect2(visible_world.get_center() - background_size / 2.0, background_size)
	w.draw_texture_rect(BACKGROUND, background_rect, false)
	# 背景の上で HUD と成長一覧を読めるよう、薄い暗色の帯を敷く。
	w.draw_rect(Rect2(52, 22, 616, 174), Color(0.03, 0.06, 0.17, 0.57))
	w.draw_rect(Rect2(0, 1196, BASE.x, 84), Color(0.03, 0.06, 0.17, 0.58))
	# 箱の座標は固定したまま、内側の透けと二重の細い縁でガラスに見せる。
	w.draw_rect(Rect2(BOX_L, BOX_TOP, BOX_R - BOX_L, FLOOR_Y - BOX_TOP), Color(0.63, 0.78, 1.0, 0.08))
	var rim_glow := Color(0.49, 0.79, 1.0, 0.17)
	var rim := Color(0.80, 0.94, 1.0, 0.78)
	for edge_x in [BOX_L, BOX_R]:
		w.draw_line(Vector2(edge_x, BOX_TOP), Vector2(edge_x, FLOOR_Y), rim_glow, 12.0, true)
		w.draw_line(Vector2(edge_x, BOX_TOP), Vector2(edge_x, FLOOR_Y), rim, 3.0, true)
	w.draw_line(Vector2(BOX_L, FLOOR_Y), Vector2(BOX_R, FLOOR_Y), rim_glow, 12.0, true)
	w.draw_line(Vector2(BOX_L, FLOOR_Y), Vector2(BOX_R, FLOOR_Y), rim, 3.0, true)
	# 危険な線（越えている時間に応じて赤く点滅）
	var line_col := Color(1, 1, 1, 0.35)
	if danger > 0.0:
		var blink := 0.5 + 0.5 * sin(Time.get_ticks_msec() / 70.0)
		line_col = Color(1, 0.3, 0.3, 0.5 + 0.5 * blink)
	var x := BOX_L
	while x < BOX_R:
		w.draw_line(Vector2(x, LINE_Y), Vector2(minf(x + 18, BOX_R), LINE_Y), line_col, 4.0)
		x += 30
	# 次の星
	var nr := minf(Star.RADII[next_stage], 40.0)
	Star.paint(w, Vector2(BOX_R - 70, 150), nr, next_stage)
	# 落とす星と、落ちる先のガイド
	if state == State.PLAY:
		var r: float = Star.RADII[current_stage]
		var a := 1.0 if cooldown <= 0.0 else 0.35
		var gx := aim_x
		var y := DROP_Y + r + 6
		while y < FLOOR_Y:
			w.draw_line(Vector2(gx, y), Vector2(gx, minf(y + 14, FLOOR_Y)), Color(1, 1, 1, 0.18), 2.0)
			y += 28
		Star.paint(w, Vector2(aim_x, DROP_Y), r, current_stage, a)
	# 星の成長（箱の下）
	_draw_ladder(w, Vector2(BOX_L - 30, FLOOR_Y + 55), BOX_R - BOX_L + 60, max_stage)

func _draw_ladder(ci: CanvasItem, origin: Vector2, width: float, reached: int) -> void:
	var n := Star.NAMES.size()
	for i in n:
		var cx := origin.x + width * (i + 0.5) / n
		var r := 8.0 + i * 1.6
		Star.paint(ci, Vector2(cx, origin.y), r, i, 1.0 if i <= reached else 0.3)

# ---------------------------------------------------------------- 自動プレイ（検証用）

func _autoplay_step() -> void:
	auto_frames += 1
	auto_since_drop += 1
	if drops < auto_drops_target:
		if auto_since_drop >= 36 and cooldown <= 0.0:
			var r: float = Star.RADII[current_stage]
			aim_x = rng.randf_range(BOX_L + r + 2, BOX_R - r - 2)
			_try_drop()
			auto_since_drop = 0
	else:
		auto_after_last += 1
		if auto_after_last >= 180:
			_finish_autoplay(false)
	if auto_frames > 60 * 60 * 20:
		push_error("自動プレイが時間切れ")
		_finish_autoplay(false)

func _finish_autoplay(over: bool) -> void:
	var errs := logger.get_errors() + anomalies
	var out := {
		"drops": drops, "merges": merges, "max_stage": max_stage + 1, "score": score,
		"game_over": over, "errors": errs,
	}
	print(JSON.stringify(out))
	if logger.get_errors() > 0:
		printerr("errors: ", logger.first_errors)
	state = State.OVER
	# 再生中の音を止めてから終わる（止めないと終了時に AudioStreamWAV のリーク警告が出た）
	for p in players:
		p.stop()
		p.stream = null
	OS.remove_logger(logger)
	get_tree().quit(0 if errs == 0 else 1)
