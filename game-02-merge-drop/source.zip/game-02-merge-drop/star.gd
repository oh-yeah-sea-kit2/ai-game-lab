class_name Star
extends RigidBody2D
## 1個の星。物理半径はそのままに、段階ごとの絵を同じ直径で描く。

const NAMES := ["ちり", "すな星", "こいし星", "いわ星", "こおり星", "つき星",
	"わく星", "わっか星", "たいよう星", "きょせい", "銀河"]
const RADII := [20.0, 28.0, 37.0, 47.0, 58.0, 70.0, 84.0, 99.0, 115.0, 132.0, 150.0]
const COLORS := [
	Color("b9b2a6"), Color("e8c27a"), Color("9fb7c9"), Color("b07a5a"), Color("8fe3f0"),
	Color("f2eec2"), Color("6fc07a"), Color("d9a35f"), Color("ffb13b"), Color("ff6b5b"),
	Color("9b7bff"),
]
const TEXTURES := [
	preload("res://art/stars_00.png"), preload("res://art/stars_01.png"),
	preload("res://art/stars_02.png"), preload("res://art/stars_03.png"),
	preload("res://art/stars_04.png"), preload("res://art/stars_05.png"),
	preload("res://art/stars_06.png"), preload("res://art/stars_07.png"),
	preload("res://art/stars_08.png"), preload("res://art/stars_09.png"),
	preload("res://art/stars_10.png"),
]
const MAX_STAGE := 10  # 0 始まり。10 = 銀河

var stage := 0
var radius := 20.0
var merging := false   # 合体が決まったら true。同じフレームで二重に合体しないための印
var age := 0.0         # 生まれてからの秒数
var over_time := 0.0   # 静止したまま線を越えている秒数

func setup(p_stage: int) -> void:
	stage = p_stage
	radius = RADII[stage]
	var shape := CircleShape2D.new()
	shape.radius = radius
	var cs := CollisionShape2D.new()
	cs.shape = shape
	add_child(cs)
	contact_monitor = true
	max_contacts_reported = 8
	mass = 0.4 + radius * radius / 900.0
	var mat := PhysicsMaterial.new()
	mat.friction = 0.35
	mat.bounce = 0.08
	physics_material_override = mat
	linear_damp = 0.2
	angular_damp = 1.0
	can_sleep = true

func _physics_process(delta: float) -> void:
	age += delta

func _draw() -> void:
	paint(self, Vector2.ZERO, radius, stage)

## 星を1つ描く。プレビューや「星の成長」一覧からも使う。
static func paint(ci: CanvasItem, pos: Vector2, r: float, st: int, alpha := 1.0) -> void:
	var tex: Texture2D = TEXTURES[st]
	ci.draw_texture_rect(tex, Rect2(pos - Vector2(r, r), Vector2(r * 2.0, r * 2.0)),
		false, Color(1, 1, 1, alpha))
