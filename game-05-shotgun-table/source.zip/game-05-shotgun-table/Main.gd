extends Node2D
## ヒバナ卓 — 本体。単一スクリプトで、盤面ロジック（純粋関数・隠れた並びに触れない）と
## 見た目（カスタム描画・タイマー駆動の演出）を分けて持つ。
## 盤面ロジックは Dictionary（G / gs）で表し、対話プレイと --autoplay の検証シミュレーションが
## 同じ関数（_load_chamber / _fire / _apply_item / _dealer_decide 等）を呼ぶことで、
## 見た目とルールがずれないようにしている。

const ROUND_CANDLES := [10, 10, 10]
const ITEM_IDS := ["peek", "pull", "coil", "heal", "stun", "mix"]
const ITEM_LABEL := {
	"peek": "のぞき窓",
	"pull": "抜き取り",
	"coil": "強化コイル",
	"heal": "薬湯",
	"stun": "しびれ粉",
	"mix": "かき混ぜ",
}
const ITEM_DESC := {
	"peek": "次のカプセルが当たりか空か、自分だけ見る。",
	"pull": "次のカプセルを取り出して捨てる（中身は両者に見える）。",
	"coil": "次にレバーを引いた時、当たりならしびれ2倍。",
	"heal": "ろうそくを1本ともし直す（上限まで）。",
	"stun": "相手の次の番を1回飛ばす。",
	"mix": "残りのカプセルの順番を混ぜ直す。",
}
const SHELF_MAX := 8

const BOX_CENTER := Vector2(360, 650)
const BOX_SIZE := Vector2(230, 260)
const SHELF_TOP := 970.0
const SHELF_COLS := 3
const SHELF_CELL := Vector2(210, 135)
const SHELF_GAP := Vector2(15, 20)

const IDLE_LINES := [
	"さあ、決めてくれ。",
	"火花箱が、静かにうたう。",
	"次はどちらに？",
	"灯を、大事にな。",
	"箱の中で、何かが軋む。",
]
const THINK_LINES := [
	"わたしの番だ。",
	"指先が、少し冷たい。",
	"運は、机の上にしかない。",
	"静かに、レバーを引こう。",
]
const HIT_LINES := [
	"ビリッと、灯が揺れた。",
	"当たりだ。灯が一つ消える。",
]
const MISS_LINES := [
	"カチリ。今日はここまで。",
	"空だ。続けてくれ。",
]

const JP_FONT := preload("res://fonts/MPLUSRounded1c-Bold-subset.ttf")
const BG_MENU := preload("res://art/bg_menu.png")
const BG_PLAY := preload("res://art/bg_play.png")
const STAGE := [
	preload("res://art/stage_00.png"), preload("res://art/stage_01.png"),
	preload("res://art/stage_02.png"), preload("res://art/stage_03.png"),
	preload("res://art/stage_04.png"), preload("res://art/stage_05.png"),
	preload("res://art/stage_06.png"), preload("res://art/stage_07.png"),
]
const ROUNDS := [
	preload("res://art/rounds_00.png"), preload("res://art/rounds_01.png"),
	preload("res://art/rounds_02.png"), preload("res://art/rounds_03.png"),
	preload("res://art/rounds_04.png"),
]
const TOOLS := [
	preload("res://art/tools_00.png"), preload("res://art/tools_01.png"),
	preload("res://art/tools_02.png"), preload("res://art/tools_03.png"),
	preload("res://art/tools_04.png"), preload("res://art/tools_05.png"),
]
const UI := [
	preload("res://art/ui_00.png"), preload("res://art/ui_01.png"),
	preload("res://art/ui_02.png"), preload("res://art/ui_03.png"),
	preload("res://art/ui_04.png"), preload("res://art/ui_05.png"),
]

var rng := RandomNumberGenerator.new()
var fx_rng := RandomNumberGenerator.new()
var state := "title" # title, play, result
var phase := "player_turn"
var autoplay := false
var demo_mode := false
var demo_wait := 0.0
var demo_target := ""
var autoplay_games := 100
var time_scale := 1.0
var seed_value := 1
var anim_time := 0.0

var G: Dictionary = {}
var pending_item := ""
var dealer_line := ""
var toast_text := ""
var toast_timer := 0.0
var spark_flash := 0.0
var click_flash := 0.0
var shake := 0.0
var particles: Array = []
var dealer_action_count := 0

var round_intro_wait := 0.0
var reload_wait := 0.0
var skip_wait := 0.0
var dealer_wait := 0.0
var reveal_wait := 0.0

var best_rounds := 0
var best_turns := -1

const BEST_PATH := "user://best.json"

# ---------------------------------------------------------------- 起動

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	fx_rng.randomize()
	_parse_args()
	_load_best()
	if autoplay:
		var result := _run_autoplay(autoplay_games, seed_value)
		print(JSON.stringify(result))
		get_tree().quit()
		return
	if OS.has_feature("web"):
		demo_mode = _is_demo_query(String(JavaScriptBridge.eval("window.location.search")))
		if demo_mode:
			time_scale = 1.0
			demo_wait = 2.5
	queue_redraw()

func _is_demo_query(search: String) -> bool:
	for part in search.split("&"):
		if part == "?demo=1" or part == "demo=1":
			return true
	return false

func _parse_args() -> void:
	var args := OS.get_cmdline_user_args()
	var seed_given := false
	for a in args:
		if a == "--autoplay":
			autoplay = true
		elif a.begins_with("--games="):
			autoplay_games = maxi(1, int(a.substr(8)))
		elif a.begins_with("--seed="):
			seed_value = int(a.substr(7))
			seed_given = true
		elif a.begins_with("--timescale="):
			time_scale = clampf(float(a.substr(12)), 0.1, 60.0)
	if not seed_given:
		seed_value = int(Time.get_ticks_usec())
	rng.seed = seed_value

# ---------------------------------------------------------------- 自己ベスト

func _load_best() -> void:
	if not FileAccess.file_exists(BEST_PATH):
		return
	var f := FileAccess.open(BEST_PATH, FileAccess.READ)
	if f == null:
		return
	var data = JSON.parse_string(f.get_as_text())
	if data is Dictionary:
		best_rounds = int(data.get("rounds", 0))
		best_turns = int(data.get("best_turns", -1))

func _save_best() -> void:
	var f := FileAccess.open(BEST_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("best.json を書けなかった: %s" % FileAccess.get_open_error())
		return
	f.store_string(JSON.stringify({"rounds": best_rounds, "best_turns": best_turns}))

func _update_best() -> void:
	var changed := false
	if int(G["rounds_cleared"]) > best_rounds:
		best_rounds = int(G["rounds_cleared"])
		changed = true
	if int(G["rounds_cleared"]) == 3 and (best_turns < 0 or int(G["turns_taken"]) < best_turns):
		best_turns = int(G["turns_taken"])
		changed = true
	if changed:
		_save_best()

# ---------------------------------------------------------------- 盤面ロジック（純粋関数）
# これらの関数は「公開情報＋自分だけが知る情報」の構造体（Dictionary）だけを引数に取り、
# 本物の隠れた並び（capsules）を卓の主の判断関数へ渡さない。

func _shuffle_array(arr: Array, r: RandomNumberGenerator) -> void:
	var i := arr.size() - 1
	while i > 0:
		var j := r.randi_range(0, i)
		var tmp = arr[i]
		arr[i] = arr[j]
		arr[j] = tmp
		i -= 1

func _new_game_state(r: RandomNumberGenerator) -> Dictionary:
	var cap: int = ROUND_CANDLES[0]
	return {
		"round": 1,
		"player_candles": cap, "player_max": cap,
		"dealer_candles": cap, "dealer_max": cap,
		"capsules": [], "chamber_index": 0,
		"remaining_hits": 0, "remaining_empties": 0,
		"player_known_next": -1, "player_known_index": -1,
		"dealer_known_next": -1, "dealer_known_index": -1,
		"player_items": {}, "dealer_items": {},
		"player_coil": false, "dealer_coil": false,
		"player_skip": false, "dealer_skip": false,
		"turn": "player",
		"turns_taken": 0,
		"items_used": 0,
		"personality": r.randf_range(-0.08, 0.08),
		"rounds_cleared": 0,
		"dealer_rounds_won": 0,
		"game_over": false,
		"winner": "",
	}

func _load_chamber(gs: Dictionary, r: RandomNumberGenerator) -> void:
	var total := r.randi_range(2, 8)
	var hits := r.randi_range(1, total - 1)
	var empties := total - hits
	var arr: Array = []
	for i in hits:
		arr.append(true)
	for i in empties:
		arr.append(false)
	_shuffle_array(arr, r)
	gs["capsules"] = arr
	gs["chamber_index"] = 0
	gs["remaining_hits"] = hits
	gs["remaining_empties"] = empties
	gs["player_known_next"] = -1
	gs["player_known_index"] = -1
	gs["dealer_known_next"] = -1
	gs["dealer_known_index"] = -1

func _deal_items(gs: Dictionary, who: String, r: RandomNumberGenerator) -> void:
	var items: Dictionary = gs["%s_items" % who]
	var current := 0
	for v in items.values():
		current += int(v)
	var count := r.randi_range(2, 4)
	for i in count:
		if current >= SHELF_MAX:
			break
		var item_id: String = ITEM_IDS[r.randi_range(0, ITEM_IDS.size() - 1)]
		items[item_id] = int(items.get(item_id, 0)) + 1
		current += 1

func _ensure_chamber(gs: Dictionary, r: RandomNumberGenerator) -> bool:
	var capsules: Array = gs["capsules"]
	if int(gs["chamber_index"]) < capsules.size():
		return false
	_load_chamber(gs, r)
	_deal_items(gs, "player", r)
	_deal_items(gs, "dealer", r)
	return true

## 「公開情報＋自分だけが知る情報」だけの構造体。隠れた並び（capsules）は含まない。
func _build_info(gs: Dictionary, who: String) -> Dictionary:
	var opp := "dealer" if who == "player" else "player"
	var known := -1
	if int(gs["%s_known_index" % who]) == int(gs["chamber_index"]):
		known = int(gs["%s_known_next" % who])
	return {
		"remaining_hits": int(gs["remaining_hits"]),
		"remaining_empties": int(gs["remaining_empties"]),
		"known_next": known,
		"own_hp": int(gs["%s_candles" % who]),
		"own_max": int(gs["%s_max" % who]),
		"opp_hp": int(gs["%s_candles" % opp]),
		"opp_max": int(gs["%s_max" % opp]),
		"own_items": (gs["%s_items" % who] as Dictionary).duplicate(),
		"own_coil_active": bool(gs["%s_coil" % who]),
		"personality": float(gs["personality"]) if who == "dealer" else 0.0,
	}

func _info_equal(a: Dictionary, b: Dictionary) -> bool:
	if a.keys().size() != b.keys().size():
		return false
	for k in a.keys():
		if not b.has(k):
			return false
		var av = a[k]
		var bv = b[k]
		if av is Dictionary and bv is Dictionary:
			if not _info_equal(av, bv):
				return false
		elif av != bv:
			return false
	return true

func _apply_item(gs: Dictionary, who: String, item_id: String, r: RandomNumberGenerator) -> Dictionary:
	var items: Dictionary = gs["%s_items" % who]
	items[item_id] = int(items.get(item_id, 0)) - 1
	if int(items[item_id]) <= 0:
		items.erase(item_id)
	gs["items_used"] = int(gs["items_used"]) + 1
	var event := {"type": "item", "who": who, "item": item_id}
	match item_id:
		"peek":
			var idx: int = int(gs["chamber_index"])
			var capsules: Array = gs["capsules"]
			var val := false
			if idx < capsules.size():
				val = bool(capsules[idx])
			gs["%s_known_next" % who] = 1 if val else 0
			gs["%s_known_index" % who] = idx
			event["peek_result"] = val
		"pull":
			var capsules2: Array = gs["capsules"]
			var idx2: int = int(gs["chamber_index"])
			var val2 := false
			if idx2 < capsules2.size():
				val2 = bool(capsules2[idx2])
				gs["chamber_index"] = idx2 + 1
				if val2:
					gs["remaining_hits"] = maxi(0, int(gs["remaining_hits"]) - 1)
				else:
					gs["remaining_empties"] = maxi(0, int(gs["remaining_empties"]) - 1)
			gs["player_known_next"] = -1
			gs["player_known_index"] = -1
			gs["dealer_known_next"] = -1
			gs["dealer_known_index"] = -1
			event["pulled"] = val2
		"coil":
			gs["%s_coil" % who] = true
		"heal":
			var maxc: int = int(gs["%s_max" % who])
			gs["%s_candles" % who] = mini(maxc, int(gs["%s_candles" % who]) + 1)
		"stun":
			var opp := "dealer" if who == "player" else "player"
			gs["%s_skip" % opp] = true
		"mix":
			var capsules3: Array = gs["capsules"]
			var idx3: int = int(gs["chamber_index"])
			var tail: Array = capsules3.slice(idx3, capsules3.size())
			_shuffle_array(tail, r)
			for k in tail.size():
				capsules3[idx3 + k] = tail[k]
			gs["player_known_next"] = -1
			gs["player_known_index"] = -1
			gs["dealer_known_next"] = -1
			gs["dealer_known_index"] = -1
	return event

func _fire(gs: Dictionary, who: String, target: String, r: RandomNumberGenerator) -> Dictionary:
	var capsules: Array = gs["capsules"]
	var idx: int = int(gs["chamber_index"])
	var hit := false
	if idx < capsules.size():
		hit = bool(capsules[idx])
		gs["chamber_index"] = idx + 1
		if hit:
			gs["remaining_hits"] = maxi(0, int(gs["remaining_hits"]) - 1)
		else:
			gs["remaining_empties"] = maxi(0, int(gs["remaining_empties"]) - 1)
	if int(gs["player_known_index"]) == idx:
		gs["player_known_next"] = -1
		gs["player_known_index"] = -1
	if int(gs["dealer_known_index"]) == idx:
		gs["dealer_known_next"] = -1
		gs["dealer_known_index"] = -1
	var damage := 0
	if hit:
		var coil_key := "%s_coil" % who
		damage = 2 if bool(gs[coil_key]) else 1
		gs[coil_key] = false
		var victim := who if target == "self" else ("dealer" if who == "player" else "player")
		var hp_key := "%s_candles" % victim
		gs[hp_key] = maxi(0, int(gs[hp_key]) - damage)
	gs["turns_taken"] = int(gs["turns_taken"]) + 1
	if target == "self" and not hit:
		gs["turn"] = who
	else:
		gs["turn"] = "dealer" if who == "player" else "player"
	return {"type": "fire", "who": who, "target": target, "hit": hit, "damage": damage}

func _check_round_end(gs: Dictionary) -> String:
	if int(gs["player_candles"]) <= 0:
		return "dealer_round_win"
	if int(gs["dealer_candles"]) <= 0:
		return "player_round_win"
	return "continue"

## 勝敗・ラウンド進行の共通処理。対話プレイと自動プレイの両方から呼ぶ。
func _resolve_round_transition(gs: Dictionary) -> String:
	var outcome := _check_round_end(gs)
	if outcome == "continue":
		return "continue"
	if outcome == "player_round_win":
		gs["rounds_cleared"] = int(gs["rounds_cleared"]) + 1
	else:
		gs["dealer_rounds_won"] = int(gs["dealer_rounds_won"]) + 1
	if int(gs["round"]) >= 3:
		gs["game_over"] = true
		gs["winner"] = "player" if int(gs["rounds_cleared"]) >= 2 else "dealer"
		return "%s_game_win" % gs["winner"]
	gs["round"] = int(gs["round"]) + 1
	var cap: int = ROUND_CANDLES[int(gs["round"]) - 1]
	gs["player_candles"] = cap
	gs["player_max"] = cap
	gs["dealer_candles"] = cap
	gs["dealer_max"] = cap
	var capsules: Array = gs["capsules"]
	gs["chamber_index"] = capsules.size()
	gs["turn"] = "player"
	return "round_advance"

## 卓の主の判断。引数は「公開情報＋自分だけが知る情報」の構造体だけで、本物の並びを渡せない。
func _dealer_decide(info: Dictionary, r: RandomNumberGenerator) -> Dictionary:
	var total: int = int(info["remaining_hits"]) + int(info["remaining_empties"])
	var p := 0.5
	if int(info["known_next"]) != -1:
		p = 1.0 if int(info["known_next"]) == 1 else 0.0
	elif total > 0:
		p = float(info["remaining_hits"]) / float(total)
	var items: Dictionary = info["own_items"]
	if int(info["known_next"]) == -1 and int(items.get("peek", 0)) > 0 and p > 0.25 and p < 0.85 and r.randf() < 0.2:
		return {"action": "peek"}
	if int(info["own_hp"]) <= 1 and int(info["own_hp"]) < int(info["own_max"]) and int(items.get("heal", 0)) > 0 and r.randf() < 0.35:
		return {"action": "heal"}
	if p >= 0.75 and int(items.get("coil", 0)) > 0 and not bool(info["own_coil_active"]) and r.randf() < 0.2:
		return {"action": "coil"}
	if p >= 0.7 and int(items.get("stun", 0)) > 0 and int(info["own_hp"]) <= int(info["opp_hp"]) and r.randf() < 0.08:
		return {"action": "stun"}
	if p <= 0.2 and total >= 3 and int(items.get("mix", 0)) > 0 and r.randf() < 0.05:
		return {"action": "mix"}
	var threshold: float = clampf(0.5 + float(info["personality"]) + r.randf_range(-0.08, 0.08), 0.05, 0.95)
	if p >= threshold:
		return {"action": "fire", "target": "opponent"}
	return {"action": "fire", "target": "self"}

## 自動プレイ用の「素直な手」。公開情報＋自分の知る情報だけで、道具は使わない。
func _player_autoplay_decide(info: Dictionary) -> Dictionary:
	var total: int = int(info["remaining_hits"]) + int(info["remaining_empties"])
	var p := 0.5
	if int(info["known_next"]) != -1:
		p = 1.0 if int(info["known_next"]) == 1 else 0.0
	elif total > 0:
		p = float(info["remaining_hits"]) / float(total)
	return {"action": "fire", "target": "opponent" if p >= 0.5 else "self"}

func _decision_equal(a: Dictionary, b: Dictionary) -> bool:
	if String(a.get("action", "")) != String(b.get("action", "")):
		return false
	if String(a.get("action", "")) == "fire":
		return String(a.get("target", "")) == String(b.get("target", ""))
	return true

## フェア検査: 公開情報＋卓の主の知識は同じまま、隠れた並び（見えていない部分）だけを
## 別の並びに変えた盤面を作る。判断関数には並びを渡していないので、構造上いつも同じ判断になる。
func _fabricate_hidden_variant(gs: Dictionary, salt: int) -> Dictionary:
	var v: Dictionary = gs.duplicate(true)
	var idx: int = int(v["chamber_index"])
	var start := idx
	if int(v["dealer_known_index"]) == idx and int(v["dealer_known_next"]) != -1:
		start = idx + 1
	var capsules: Array = v["capsules"]
	var tail: Array = capsules.slice(start, capsules.size())
	var local_rng := RandomNumberGenerator.new()
	local_rng.seed = salt
	_shuffle_array(tail, local_rng)
	for k in tail.size():
		capsules[start + k] = tail[k]
	return v

func _dealer_fairness_check(gs: Dictionary, info: Dictionary, r: RandomNumberGenerator) -> bool:
	var variant_a := _fabricate_hidden_variant(gs, 1013)
	var variant_b := _fabricate_hidden_variant(gs, 7919)
	var info_a := _build_info(variant_a, "dealer")
	var info_b := _build_info(variant_b, "dealer")
	if not _info_equal(info_a, info) or not _info_equal(info_b, info):
		return false
	var rng_a := RandomNumberGenerator.new()
	rng_a.seed = r.seed
	rng_a.state = r.state
	var rng_b := RandomNumberGenerator.new()
	rng_b.seed = r.seed
	rng_b.state = r.state
	var decide_a := _dealer_decide(info_a, rng_a)
	var decide_b := _dealer_decide(info_b, rng_b)
	return _decision_equal(decide_a, decide_b)

# ---------------------------------------------------------------- 自動プレイ（検証用）

## player_wins / dealer_wins は決着したラウンド単位の集計。1ゲームで必ず3件を数える。
## test_headless.sh が確認するのはゲーム勝率ではなくラウンド勝率。
func _run_autoplay(games: int, seed_val: int) -> Dictionary:
	var round_player_wins := 0
	var round_dealer_wins := 0
	var total_turns := 0
	var total_items := 0
	var fair_violations := 0
	var errors := 0
	var game_rng := RandomNumberGenerator.new()
	game_rng.seed = seed_val
	for g in games:
		var gs := _new_game_state(game_rng)
		var safety := 0
		while not bool(gs["game_over"]):
			safety += 1
			if safety > 5000:
				errors += 1
				push_error("autoplay: 終了しないゲームを検出 seed=%d game=%d" % [seed_val, g])
				gs["game_over"] = true
				gs["winner"] = "dealer"
				break
			_ensure_chamber(gs, game_rng)
			var turn := String(gs["turn"])
			var skip_key := "%s_skip" % turn
			if bool(gs[skip_key]):
				gs[skip_key] = false
				gs["turn"] = "dealer" if turn == "player" else "player"
				continue
			if turn == "dealer":
				var actions := 0
				while true:
					actions += 1
					var info := _build_info(gs, "dealer")
					if not _dealer_fairness_check(gs, info, game_rng):
						fair_violations += 1
					var decision := _dealer_decide(info, game_rng)
					if String(decision["action"]) == "fire" or actions > 5:
						var target: String = String(decision.get("target", "self"))
						_fire(gs, "dealer", target, game_rng)
						break
					_apply_item(gs, "dealer", String(decision["action"]), game_rng)
			else:
				var info2 := _build_info(gs, "player")
				var decision2 := _player_autoplay_decide(info2)
				_fire(gs, "player", String(decision2["target"]), game_rng)
			var round_result := _check_round_end(gs)
			_resolve_round_transition(gs)
			match round_result:
				"dealer_round_win":
					round_dealer_wins += 1
				"player_round_win":
					round_player_wins += 1
		total_turns += int(gs["turns_taken"])
		total_items += int(gs["items_used"])
	return {
		"games": games,
		"player_wins": round_player_wins,
		"dealer_wins": round_dealer_wins,
		"avg_turns": (float(total_turns) / float(games)) if games > 0 else 0.0,
		"items_used": total_items,
		"fair_violations": fair_violations,
		"errors": errors,
	}

# ---------------------------------------------------------------- 対話プレイ（見た目つき）

func _start_game() -> void:
	G = _new_game_state(rng)
	particles.clear()
	spark_flash = 0.0
	click_flash = 0.0
	shake = 0.0
	toast_timer = 0.0
	pending_item = ""
	state = "play"
	phase = "round_intro"
	round_intro_wait = 1.1
	dealer_line = _random_line(IDLE_LINES)

func _enter_turn() -> void:
	if _ensure_chamber(G, rng):
		toast_text = "補充: 当たり%d・空%d" % [int(G["remaining_hits"]), int(G["remaining_empties"])]
		toast_timer = 1.6
		phase = "reload_intro"
		reload_wait = 1.1
		return
	_start_turn_after_reload()

func _start_turn_after_reload() -> void:
	var who: String = String(G["turn"])
	var skip_key := "%s_skip" % who
	if bool(G[skip_key]):
		G[skip_key] = false
		toast_text = ("あなた" if who == "player" else "卓の主") + "の番はしびれて飛んだ"
		toast_timer = 1.4
		G["turn"] = "dealer" if who == "player" else "player"
		phase = "skip_msg"
		skip_wait = 1.0
		return
	if who == "player":
		phase = "player_turn"
		if demo_mode:
			demo_wait = 0.6
		dealer_line = _random_line(IDLE_LINES)
	else:
		phase = "dealer_think"
		dealer_wait = 0.5
		dealer_action_count = 0
		dealer_line = _random_line(THINK_LINES)

func _dealer_step() -> void:
	dealer_action_count += 1
	var info := _build_info(G, "dealer")
	var decision := _dealer_decide(info, rng)
	if String(decision["action"]) == "fire" or dealer_action_count > 5:
		var fallback := "opponent" if int(info["remaining_hits"]) >= int(info["remaining_empties"]) else "self"
		var target: String = String(decision.get("target", fallback))
		_do_fire("dealer", target)
		return
	var event := _apply_item(G, "dealer", String(decision["action"]), rng)
	_apply_item_visual(event, "dealer")
	dealer_wait = 0.85
	phase = "dealer_think"

func _use_player_item() -> void:
	var event := _apply_item(G, "player", pending_item, rng)
	_apply_item_visual(event, "player")
	pending_item = ""
	phase = "player_turn"

func _apply_item_visual(event: Dictionary, who: String) -> void:
	var actor := "あなた" if who == "player" else "卓の主"
	var item_id: String = String(event["item"])
	match item_id:
		"peek":
			if who == "player":
				toast_text = "のぞき窓: 次は%s" % ("当たり" if bool(event["peek_result"]) else "空")
			else:
				toast_text = "%sが のぞき窓 を使った" % actor
		"pull":
			toast_text = "%sが 抜き取り で%sを捨てた" % [actor, "当たり" if bool(event["pulled"]) else "空"]
		"coil":
			toast_text = "%sが 強化コイル を仕込んだ" % actor
		"heal":
			toast_text = "%sが 薬湯 でろうそくを1本ともした" % actor
		"stun":
			toast_text = "%sが しびれ粉 をまいた" % actor
		"mix":
			toast_text = "%sが かき混ぜ で並びを混ぜた" % actor
	toast_timer = 1.6

func _do_fire(who: String, target: String) -> void:
	var victim := who if target == "self" else ("dealer" if who == "player" else "player")
	var before_count := int(G["%s_candles" % victim])
	var max_count := int(G["%s_max" % victim])
	var event := _fire(G, who, target, rng)
	if bool(event["hit"]):
		var after_count := int(G["%s_candles" % victim])
		spark_flash = 1.0
		shake = 0.6
		for idx in range(after_count, before_count):
			_spawn_smoke(_candle_pos(victim == "dealer", idx, max_count))
		dealer_line = _random_line(HIT_LINES)
		reveal_wait = 1.0
	else:
		click_flash = 1.0
		dealer_line = _random_line(MISS_LINES)
		reveal_wait = 0.55
	phase = "reveal"

func _after_fire_resolution() -> void:
	var outcome := _resolve_round_transition(G)
	match outcome:
		"dealer_game_win":
			_finish_game("dealer")
		"player_game_win":
			_finish_game("player")
		"round_advance":
			phase = "round_intro"
			round_intro_wait = 1.1
		_:
			_enter_turn()

func _finish_game(winner: String) -> void:
	G["game_over"] = true
	G["winner"] = winner
	_update_best()
	state = "result"
	if demo_mode:
		demo_wait = 3.0

func _random_line(arr: Array) -> String:
	return String(arr[fx_rng.randi_range(0, arr.size() - 1)])

func _candle_pos(is_dealer: bool, index: int, max_count: int) -> Vector2:
	var spacing := 70.0
	var start_x := 360.0 - (max_count - 1) * spacing * 0.5
	return Vector2(start_x + index * spacing, 230.0 if is_dealer else 890.0)

func _spawn_smoke(pos: Vector2) -> void:
	for i in 6:
		particles.append({
			"pos": pos + Vector2(fx_rng.randf_range(-6.0, 6.0), 0.0),
			"vel": Vector2(fx_rng.randf_range(-14.0, 14.0), fx_rng.randf_range(-70.0, -30.0)),
			"life": 1.0,
			"max_life": 1.0,
			"radius": fx_rng.randf_range(6.0, 12.0),
			"color": Color(0.6, 0.6, 0.6),
		})

func _update_particles(delta: float) -> void:
	for p in particles:
		p["pos"] = (p["pos"] as Vector2) + (p["vel"] as Vector2) * delta
		p["vel"] = (p["vel"] as Vector2) + Vector2(0.0, 40.0) * delta
		p["life"] = float(p["life"]) - delta
	var i := particles.size() - 1
	while i >= 0:
		if float(particles[i]["life"]) <= 0.0:
			particles.remove_at(i)
		i -= 1

# ---------------------------------------------------------------- 入力

func _origin() -> Vector2:
	var size := get_viewport_rect().size
	return Vector2((size.x - 720.0) * 0.5, maxf(0.0, (size.y - 1280.0) * 0.5))

func _input(event: InputEvent) -> void:
	if autoplay or demo_mode:
		return
	if state == "play" and event is InputEventKey and event.pressed and not event.echo:
		if phase == "player_aim_choice":
			if event.keycode == KEY_1:
				_do_fire("player", "self")
				return
			elif event.keycode == KEY_2:
				_do_fire("player", "opponent")
				return
		elif phase == "player_turn":
			var keys := [KEY_Q, KEY_W, KEY_E, KEY_R, KEY_T, KEY_Y]
			var ki := keys.find(event.keycode)
			if ki >= 0 and int((G["player_items"] as Dictionary).get(ITEM_IDS[ki], 0)) > 0:
				pending_item = ITEM_IDS[ki]
				phase = "player_item_confirm"
				return
	if event is InputEventScreenTouch and event.pressed:
		_handle_tap(event.position)
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_handle_tap(event.position)

## タップ直後にブラウザが送る「マウス互換イベント」で同じ場所へ二重発火し、
## タップ後に表示が切り替わった直後のボタンをゴースト操作してしまうのを防ぐデバウンス。
var _last_tap_msec := -100000

func _handle_tap(screen_pos: Vector2) -> void:
	if autoplay or demo_mode:
		return
	var now := Time.get_ticks_msec()
	if now - _last_tap_msec < 350:
		return
	_last_tap_msec = now
	var p := screen_pos - _origin()
	match state:
		"title":
			if _button_rect(Vector2(360, 900)).has_point(p):
				_start_game()
		"result":
			if _button_rect(Vector2(360, 760)).has_point(p):
				_start_game()
		"play":
			_handle_play_tap(p)

func _handle_play_tap(p: Vector2) -> void:
	match phase:
		"player_turn":
			if _box_rect().has_point(p):
				phase = "player_aim_choice"
				return
			var idx := _shelf_index_at(p)
			if idx >= 0:
				var item_id: String = ITEM_IDS[idx]
				if int((G["player_items"] as Dictionary).get(item_id, 0)) > 0:
					pending_item = item_id
					phase = "player_item_confirm"
		"player_aim_choice":
			if _aim_button_rect(true).has_point(p):
				_do_fire("player", "self")
			elif _aim_button_rect(false).has_point(p):
				_do_fire("player", "opponent")
			elif _cancel_button_rect().has_point(p):
				phase = "player_turn"
		"player_item_confirm":
			if _confirm_yes_rect().has_point(p):
				_use_player_item()
			elif _confirm_no_rect().has_point(p):
				pending_item = ""
				phase = "player_turn"
		_:
			pass

func _shelf_index_at(p: Vector2) -> int:
	for i in ITEM_IDS.size():
		if _shelf_rect(i).has_point(p):
			return i
	return -1

# ---------------------------------------------------------------- レイアウト（当たり判定と描画で共有）

func _button_rect(center: Vector2, w := 460.0, h := 100.0) -> Rect2:
	return Rect2(center - Vector2(w, h) * 0.5, Vector2(w, h))

func _box_rect() -> Rect2:
	return Rect2(BOX_CENTER - BOX_SIZE * 0.5, BOX_SIZE)

func _aim_button_rect(is_self: bool) -> Rect2:
	var cy := 505.0 if is_self else 635.0
	return Rect2(Vector2(360.0 - 280.0, cy - 55.0), Vector2(560.0, 110.0))

func _cancel_button_rect() -> Rect2:
	return Rect2(Vector2(360.0 - 110.0, 712.0), Vector2(220.0, 90.0))

func _confirm_yes_rect() -> Rect2:
	return Rect2(Vector2(90.0, 730.0), Vector2(260.0, 90.0))

func _confirm_no_rect() -> Rect2:
	return Rect2(Vector2(370.0, 730.0), Vector2(260.0, 90.0))

func _shelf_rect(i: int) -> Rect2:
	var col := i % SHELF_COLS
	var row := i / SHELF_COLS
	var total_w := SHELF_COLS * SHELF_CELL.x + (SHELF_COLS - 1) * SHELF_GAP.x
	var start_x := (720.0 - total_w) * 0.5
	var x := start_x + col * (SHELF_CELL.x + SHELF_GAP.x)
	var y := SHELF_TOP + row * (SHELF_CELL.y + SHELF_GAP.y)
	return Rect2(Vector2(x, y), SHELF_CELL)

# ---------------------------------------------------------------- 毎フレーム

func _process(delta: float) -> void:
	anim_time += delta
	if autoplay:
		return
	if state == "play":
		spark_flash = maxf(0.0, spark_flash - delta * 2.2)
		click_flash = maxf(0.0, click_flash - delta * 3.0)
		shake = maxf(0.0, shake - delta * 1.8)
		if toast_timer > 0.0:
			toast_timer = maxf(0.0, toast_timer - delta)
		_update_particles(delta)
		var dt := delta * time_scale
		match phase:
			"round_intro":
				round_intro_wait -= dt
				if round_intro_wait <= 0.0:
					_enter_turn()
			"reload_intro":
				reload_wait -= dt
				if reload_wait <= 0.0:
					_start_turn_after_reload()
			"skip_msg":
				skip_wait -= dt
				if skip_wait <= 0.0:
					_enter_turn()
			"dealer_think":
				dealer_wait -= dt
				if dealer_wait <= 0.0:
					_dealer_step()
			"reveal":
				reveal_wait -= dt
				if reveal_wait <= 0.0:
					_after_fire_resolution()
			_:
				pass
	if demo_mode:
		_process_demo(delta)
	_publish_web_state()
	queue_redraw()

func _process_demo(delta: float) -> void:
	if state == "title" or state == "result":
		demo_wait -= delta
		if demo_wait <= 0.0:
			_start_game()
		return
	if state != "play":
		return
	if phase != "player_turn" and phase != "player_aim_choice":
		return
	demo_wait -= delta
	if demo_wait > 0.0:
		return
	if phase == "player_turn":
		var decision := _player_autoplay_decide(_build_info(G, "player"))
		demo_target = String(decision["target"])
		phase = "player_aim_choice"
		demo_wait = 0.6
	else:
		_do_fire("player", demo_target)

## Web 版の検証用: いまの状態を window.__hibana に置く（ブラウザ自動操作から読むだけ。ゲームには影響しない）
func _publish_web_state() -> void:
	if not OS.has_feature("web"):
		return
	var st := {
		"state": state,
		"phase": phase,
		"round": int(G.get("round", 0)) if state != "title" else 0,
		"player_candles": int(G.get("player_candles", 0)),
		"dealer_candles": int(G.get("dealer_candles", 0)),
		"rounds_cleared": int(G.get("rounds_cleared", 0)),
		"winner": String(G.get("winner", "")),
	}
	JavaScriptBridge.eval("window.__hibana = %s;" % JSON.stringify(st), true)

# ---------------------------------------------------------------- 描画

func _text(value: String, pos: Vector2, size: int, color: Color) -> void:
	draw_string(JP_FONT, pos, value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func _text_center(value: String, pos: Vector2, size: int, color: Color) -> void:
	var w := JP_FONT.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	_text(value, pos - Vector2(w * 0.5, 0.0), size, color)

func _sprite(texture: Texture2D, center: Vector2, bounds: Vector2, tint := Color.WHITE) -> void:
	var scale := minf(bounds.x / texture.get_width(), bounds.y / texture.get_height())
	var drawn := texture.get_size() * scale
	draw_texture_rect(texture, Rect2(center - drawn * 0.5, drawn), false, tint)

func _panel(texture: Texture2D, rect: Rect2, tint := Color.WHITE) -> void:
	# 角と縁を伸ばさず、中央だけを伸ばす。
	var src := texture.get_size()
	var sx := minf(30.0, src.x / 3.0)
	var sy := minf(30.0, src.y / 3.0)
	var dx := minf(18.0, rect.size.x / 3.0)
	var dy := minf(18.0, rect.size.y / 3.0)
	var sw := [sx, src.x - 2.0 * sx, sx]
	var sh := [sy, src.y - 2.0 * sy, sy]
	var dw := [dx, rect.size.x - 2.0 * dx, dx]
	var dh := [dy, rect.size.y - 2.0 * dy, dy]
	var src_y := 0.0
	var dst_y := rect.position.y
	for row in 3:
		var src_x := 0.0
		var dst_x := rect.position.x
		for col in 3:
			draw_texture_rect_region(texture, Rect2(dst_x, dst_y, dw[col], dh[row]), Rect2(src_x, src_y, sw[col], sh[row]), tint)
			src_x += sw[col]
			dst_x += dw[col]
		src_y += sh[row]
		dst_y += dh[row]

func _visible_local_rect() -> Rect2:
	# stretch expand では viewport の論理サイズが720x1280より広がる。
	var visible := get_viewport().get_visible_rect()
	var inverse := get_global_transform_with_canvas().affine_inverse()
	var p0 := inverse * visible.position
	var p1 := inverse * visible.end
	return Rect2(p0, p1 - p0).abs()

func _draw_background(texture: Texture2D) -> void:
	var visible := _visible_local_rect()
	var scale := maxf(visible.size.x / texture.get_width(), visible.size.y / texture.get_height())
	var drawn := texture.get_size() * scale
	draw_texture_rect(texture, Rect2(visible.get_center() - drawn * 0.5, drawn), false)

func _draw() -> void:
	_draw_background(BG_PLAY if state == "play" else BG_MENU)
	var origin := _origin()
	if shake > 0.0:
		origin += Vector2(fx_rng.randf_range(-1.0, 1.0), fx_rng.randf_range(-1.0, 1.0)) * shake * 10.0
	draw_set_transform(origin)
	match state:
		"title":
			_draw_title()
		"play":
			_draw_play()
		"result":
			_draw_result()
	draw_set_transform(Vector2.ZERO)

func _draw_wide_button(center: Vector2, label: String) -> void:
	var rect := _button_rect(center)
	_panel(UI[0], rect)
	_text_center(label, center + Vector2(0, 10), 32, Color("f7e9c0"))

func _draw_choice_button(rect: Rect2, label: String, small := false) -> void:
	_panel(UI[1], rect, Color(0.72, 0.72, 0.72) if small else Color.WHITE)
	_text_center(label, rect.position + rect.size * 0.5 + Vector2(0, 8), 20 if small else 26, Color("f7e9c0"))

func _draw_title() -> void:
	_text_center("ヒバナ卓", Vector2(360, 420), 60, Color("f4e3b5"))
	_text_center("当たりと空の賭け卓上ゲーム", Vector2(360, 480), 24, Color("bcae86"))
	_draw_spark_box_static(Vector2(360, 660))
	_text_center("火花箱のランプを 自分 か 相手 へ向けて レバーを引く", Vector2(360, 800), 22, Color("d8cba0"))
	_draw_wide_button(Vector2(360, 900), "はじめる")
	_text_center("スマホ: タップだけで進む", Vector2(360, 985), 26, Color("e2d9b9"))
	_text_center("PC: クリック / 1・2・Q〜Y", Vector2(360, 1025), 26, Color("e2d9b9"))
	_text_center("自己ベスト　勝ち抜き %d ラウンド" % best_rounds, Vector2(360, 1160), 24, Color("cfead1"))
	if best_turns >= 0:
		_text_center("全勝最少 %d 手" % best_turns, Vector2(360, 1200), 24, Color("cfead1"))

func _draw_spark_box_static(center: Vector2) -> void:
	_sprite(STAGE[0], center, BOX_SIZE)
	_sprite(ROUNDS[0], center + Vector2(0, -20), Vector2(70, 70))
	_sprite(STAGE[1], center + Vector2(125, 0), Vector2(42, 125))

func _draw_play() -> void:
	_text("ラウンド %d/3　勝 %d - %d" % [int(G["round"]), int(G["rounds_cleared"]), int(G["dealer_rounds_won"])], Vector2(24, 34), 20, Color("cfead1"))
	_draw_dealer_hands()
	_draw_candle_row(Vector2(360, 230), int(G["dealer_candles"]), int(G["dealer_max"]), true)
	_draw_speech_bubble()
	_draw_public_counts()
	match phase:
		"round_intro":
			_draw_round_banner()
		"reload_intro", "skip_msg":
			_draw_center_message()
		"player_aim_choice":
			_draw_aim_choice()
		"player_item_confirm":
			_draw_item_confirm()
		_:
			_draw_spark_box()
	_draw_candle_row(Vector2(360, 890), int(G["player_candles"]), int(G["player_max"]), false)
	_draw_known_text()
	_draw_shelf()
	_draw_particles()

func _draw_dealer_hands() -> void:
	var bob := sin(anim_time * 1.6) * 6.0
	_sprite(STAGE[2], Vector2(210, 115 + bob), Vector2(180, 145))
	_sprite(STAGE[3], Vector2(510, 115 - bob), Vector2(180, 145))

func _draw_candle_row(center: Vector2, count: int, max_count: int, is_dealer: bool) -> void:
	if max_count <= 0:
		return
	var spacing := 70.0
	var start_x := center.x - (max_count - 1) * spacing * 0.5
	for i in max_count:
		var cx := start_x + i * spacing
		_draw_candle(Vector2(cx, center.y), i < count)

func _draw_candle(pos: Vector2, lit: bool) -> void:
	var flick := 1.0 + sin(anim_time * 9.0 + pos.x) * 0.04 if lit else 1.0
	_sprite(STAGE[4] if lit else STAGE[5], pos + Vector2(0, -2 if lit else 9), Vector2(44, 92 * flick))

func _draw_speech_bubble() -> void:
	var rect := Rect2(Vector2(80, 280), Vector2(560, 80))
	_panel(UI[2], rect)
	_text_center(dealer_line, rect.position + Vector2(rect.size.x * 0.5, rect.size.y * 0.5 + 8), 22, Color("d7e8d2"))

func _draw_public_counts() -> void:
	draw_rect(Rect2(Vector2(80, 388), Vector2(560, 98)), Color(0.015, 0.035, 0.025, 0.75))
	_text_center("残り", Vector2(150, 430), 24, Color("cfead1"))
	_sprite(ROUNDS[3], Vector2(242, 419), Vector2(34, 34))
	_text_center("当たり%d" % int(G["remaining_hits"]), Vector2(330, 430), 24, Color("cfead1"))
	_sprite(ROUNDS[4], Vector2(436, 419), Vector2(34, 34))
	_text_center("空%d" % int(G["remaining_empties"]), Vector2(512, 430), 24, Color("cfead1"))
	if toast_timer > 0.0 and phase != "reload_intro" and phase != "skip_msg":
		_text_center(toast_text, Vector2(360, 468), 20, Color("fff3c4"))

func _draw_center_message() -> void:
	_panel(UI[3], _box_rect())
	if phase == "reload_intro":
		_text_center("補充", BOX_CENTER + Vector2(0, -12), 24, Color("f2e9cf"))
		_text_center("当たり%d・空%d" % [int(G["remaining_hits"]), int(G["remaining_empties"])], BOX_CENTER + Vector2(0, 20), 22, Color("f2e9cf"))
	else:
		_text_center(toast_text, BOX_CENTER, 24, Color("f2e9cf"))

func _draw_spark_box() -> void:
	var c := BOX_CENTER
	_sprite(STAGE[0], c, BOX_SIZE)
	var lamp_center := c + Vector2(0, -20)
	var lamp := ROUNDS[1] if spark_flash > 0.0 else (ROUNDS[2] if click_flash > 0.0 else ROUNDS[0])
	_sprite(lamp, lamp_center, Vector2(70, 70))
	if spark_flash > 0.0:
		_sprite(STAGE[7], lamp_center, Vector2(120, 120), Color(1, 1, 1, spark_flash))
	var lever_pull := 26.0 if phase == "reveal" else 0.0
	_sprite(STAGE[1], c + Vector2(125, lever_pull), Vector2(42, 125))
	if phase == "player_turn":
		_text_center("タップして向き先を選ぶ", c + Vector2(0, BOX_SIZE.y * 0.5 + 46), 20, Color("cfead1"))

func _draw_aim_choice() -> void:
	_draw_choice_button(_aim_button_rect(true), "自分に向ける")
	_draw_choice_button(_aim_button_rect(false), "相手に向ける")
	if demo_mode:
		draw_rect(_aim_button_rect(demo_target == "self"), Color("f4e3b5"), false, 4.0)
	_draw_choice_button(_cancel_button_rect(), "やめる", true)

func _draw_item_confirm() -> void:
	var panel := Rect2(Vector2(60, 540), Vector2(600, 300))
	_panel(UI[3], panel)
	_text_center("『%s』を使いますか？" % ITEM_LABEL[pending_item], panel.position + Vector2(panel.size.x * 0.5, 90), 24, Color("f2e9cf"))
	_text_center(String(ITEM_DESC.get(pending_item, "")), panel.position + Vector2(panel.size.x * 0.5, 140), 18, Color("b9ac86"))
	_draw_choice_button(_confirm_yes_rect(), "使う")
	_draw_choice_button(_confirm_no_rect(), "やめる", true)

func _draw_round_banner() -> void:
	_panel(UI[3], Rect2(Vector2(0, 560), Vector2(720, 180)))
	_text_center("ラウンド %d" % int(G["round"]), Vector2(360, 650), 44, Color("f4e3b5"))
	var target: int = ROUND_CANDLES[int(G["round"]) - 1]
	_text_center("ろうそく %d本ずつ" % target, Vector2(360, 700), 22, Color("d8cba0"))

func _draw_known_text() -> void:
	if int(G["player_known_index"]) == int(G["chamber_index"]) and int(G["player_known_next"]) != -1:
		var txt := "のぞき窓: 次は当たり" if int(G["player_known_next"]) == 1 else "のぞき窓: 次は空"
		draw_rect(Rect2(Vector2(160, 914), Vector2(400, 42)), Color(0.015, 0.035, 0.025, 0.78))
		_sprite(ROUNDS[3] if int(G["player_known_next"]) == 1 else ROUNDS[4], Vector2(207, 935), Vector2(28, 28))
		_text_center(txt, Vector2(377, 945), 20, Color("9fd6ff"))

func _draw_shelf() -> void:
	var items: Dictionary = G["player_items"]
	for i in ITEM_IDS.size():
		var id: String = ITEM_IDS[i]
		var rect := _shelf_rect(i)
		var count := int(items.get(id, 0))
		var active := count > 0 and phase == "player_turn"
		_panel(UI[4] if active else UI[5], rect)
		_sprite(TOOLS[i], rect.position + Vector2(rect.size.x * 0.5, 45), Vector2(60, 58), Color.WHITE if count > 0 else Color(0.48, 0.48, 0.48))
		_text_center(ITEM_LABEL[id], rect.position + Vector2(rect.size.x * 0.5, 92), 23, Color("cfead1") if count > 0 else Color("c5d2be"))
		_text_center("×%d" % count, rect.position + Vector2(rect.size.x * 0.5, 120), 21, Color("f2e9cf") if count > 0 else Color("b7c4b1"))

func _draw_particles() -> void:
	for p in particles:
		var a := clampf(float(p["life"]) / float(p["max_life"]), 0.0, 1.0)
		var diameter := float(p["radius"]) * 2.0
		_sprite(STAGE[6], p["pos"], Vector2(diameter, diameter * 2.0), Color(1, 1, 1, a * 0.7))

func _draw_result() -> void:
	var won := String(G["winner"]) == "player"
	_text_center("勝ち越し！" if won else "惜敗", Vector2(360, 380), 46, Color("f4e3b5") if won else Color("e0a9a9"))
	_text_center("勝ち抜いたラウンド数　%d" % int(G["rounds_cleared"]), Vector2(360, 470), 26, Color.WHITE)
	_text_center("かかった手数　%d" % int(G["turns_taken"]), Vector2(360, 520), 26, Color.WHITE)
	_text_center("使った道具数　%d" % int(G["items_used"]), Vector2(360, 570), 26, Color.WHITE)
	var best_txt := "自己ベスト　勝ち抜き %d ラウンド" % best_rounds
	if best_turns >= 0:
		best_txt += "　全勝最少 %d 手" % best_turns
	_text_center(best_txt, Vector2(360, 630), 22, Color("cfead1"))
	_draw_wide_button(Vector2(360, 760), "もう一度")
