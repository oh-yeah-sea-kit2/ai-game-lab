extends Logger
## エンジンが出したエラー（スクリプトエラー含む）を数える。

var _mutex := Mutex.new()
var error_count := 0
var warning_count := 0
var first_errors: Array[String] = []

func _log_error(function: String, file: String, line: int, code: String, rationale: String,
		_editor_notify: bool, error_type: int, _script_backtraces: Array[ScriptBacktrace]) -> void:
	_mutex.lock()
	if error_type == ERROR_TYPE_WARNING:
		warning_count += 1
	else:
		error_count += 1
		if first_errors.size() < 10:
			first_errors.append("%s:%d %s %s %s" % [file, line, function, code, rationale])
	_mutex.unlock()

func _log_message(_message: String, _error: bool) -> void:
	pass

func get_errors() -> int:
	_mutex.lock()
	var n := error_count
	_mutex.unlock()
	return n
