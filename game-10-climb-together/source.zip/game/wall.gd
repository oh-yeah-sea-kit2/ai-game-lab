class_name Wall
extends RefCounted
## 岩壁のデータ（岩の位置・種類）と、岩同士の「届く関係」グラフ、最短経路探索（握力の消費を重み
## にする）をまとめる。壁の形は常に同じ内部シード（WALL_SEED）で作るので、実行時の --seed の
## 影響を受けない（「壁の形は毎回同じ」の要件）。

const PX_PER_M := 20.0
const WALL_HEIGHT_M := 300.0
const WALL_SEED := 20260928

const TAP_REACH := 150.0
const JUMP_REACH := 280.0
const JUMP_COST := 30.0
const CRUMBLE_SECONDS := 3.0
const ICE_PENALTY_SECONDS := 2.0
const ICE_REACH_PENALTY := 30.0
const WIND_MAX_AMPLITUDE := 34.0

enum HoldType { GOOD, NORMAL, BAD, CRUMBLE, ICE, LEDGE, TOP }

const TAP_COST := {
	HoldType.GOOD: 6.0,
	HoldType.NORMAL: 10.0,
	HoldType.BAD: 16.0,
	HoldType.CRUMBLE: 12.0,
	HoldType.ICE: 14.0,
	HoldType.LEDGE: 0.0,
	HoldType.TOP: 0.0,
}

## ぶら下がっているだけで秒あたりに減る量（両手の平均。「悪い岩ほど早く減る」）
const IDLE_DRAIN := {
	HoldType.GOOD: 1.1,
	HoldType.NORMAL: 1.9,
	HoldType.BAD: 3.1,
	HoldType.CRUMBLE: 2.3,
	HoldType.ICE: 2.6,
	HoldType.LEDGE: 0.0,
	HoldType.TOP: 0.0,
}

const HOLD_COLORS := {
	HoldType.GOOD: Color("8bd46b"),
	HoldType.NORMAL: Color("b79a6b"),
	HoldType.BAD: Color("7a5a4a"),
	HoldType.CRUMBLE: Color("c98b4a"),
	HoldType.ICE: Color("bfe9ff"),
	HoldType.LEDGE: Color("d8cfa8"),
	HoldType.TOP: Color("ffd27a"),
}

## holds[i] = {idx, pos: Vector2, type: int, height_m: float, candy: bool, radius: float}
## height_m の昇順に並ぶ（生成時に必ずそうなる）。ledge_indices は type==LEDGE または 0 番（ふもと）。
var holds: Array = []
var top_idx: int = 0
var ledge_indices: Array = []

func _init() -> void:
	_build()

func _build() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = WALL_SEED
	holds = []
	holds.append({
		"idx": 0, "pos": Vector2(360.0, 0.0), "type": HoldType.LEDGE,
		"height_m": 0.0, "candy": false, "radius": 34.0,
	})
	var h := 0.0
	var prev_x := 360.0
	var step_idx := 1
	while h < WALL_HEIGHT_M - 0.01:
		# 最初の岩棚までは、短い間隔で光る岩を連続してつかめる練習区間。
		var dy: float = rng.randf_range(1.4, 1.9) if h < 30.0 else rng.randf_range(2.2, 3.6)
		h = min(WALL_HEIGHT_M, h + dy)
		var dx: float = rng.randf_range(-45.0, 45.0) if h < 30.0 else rng.randf_range(-95.0, 95.0)
		var x: float = clampf(prev_x + dx, 90.0, 630.0)
		prev_x = x
		var is_top: bool = h >= WALL_HEIGHT_M - 0.01
		var is_ledge: bool = (not is_top) and ((h < 30.0 and step_idx % 8 == 0) or (h >= 30.0 and step_idx % 11 == 0))
		var t: int
		if is_top:
			t = HoldType.TOP
			x = 360.0
		elif is_ledge:
			t = HoldType.LEDGE
		else:
			t = _roll_type(rng, h, step_idx)
		var candy: bool = (not is_top) and (not is_ledge) and (step_idx % 16 == 6)
		var idx := holds.size()
		holds.append({
			"idx": idx, "pos": Vector2(x, -h * PX_PER_M), "type": t,
			"height_m": h, "candy": candy, "radius": 30.0 if t == HoldType.LEDGE else 26.0,
		})
		# 中盤は左右の二択。安全な緑の岩は寄り道になり、速い直進には悪い岩も混ざる。
		if h >= 45.0 and h < 255.0 and step_idx % 5 == 0 and not is_ledge:
			var branch_x: float = clampf(x + (72.0 if step_idx % 2 == 0 else -72.0), 90.0, 630.0)
			holds.append({
				"idx": holds.size(), "pos": Vector2(branch_x, -h * PX_PER_M),
				"type": HoldType.GOOD, "height_m": h, "candy": false, "radius": 26.0,
			})
		step_idx += 1
	top_idx = holds.size() - 1
	ledge_indices = []
	for hold in holds:
		if int(hold.type) == HoldType.LEDGE:
			ledge_indices.append(int(hold.idx))

func _roll_type(rng: RandomNumberGenerator, h: float, idx: int) -> int:
	if idx <= 3:
		return HoldType.GOOD
	var r: float = rng.randf()
	if h > 230.0:
		if r < 0.32:
			return HoldType.ICE
		elif r < 0.55:
			return HoldType.BAD
		elif r < 0.68:
			return HoldType.CRUMBLE
		elif r < 0.86:
			return HoldType.NORMAL
		return HoldType.GOOD
	if r < 0.12:
		return HoldType.CRUMBLE
	elif r < 0.34:
		return HoldType.BAD
	elif r < 0.70:
		return HoldType.NORMAL
	return HoldType.GOOD

func hold(idx: int) -> Dictionary:
	return holds[idx]

## i から j へ届くか（j の方が高い岩のみ。タップ／飛びつきの2種）。戻り値: "" | "tap" | "jump"
## タップの判定は、風で届く範囲がずれる分（最大 WIND_MAX_AMPLITUDE）と、i が凍った岩なら滑る分
## （ICE_REACH_PENALTY）を安全マージンとして差し引いた、いつでも確実に届く距離で行う。ここで
## 「タップで届く」と判定した経路は、実プレイの風のタイミングに関わらず必ずタップで届く
## （壁チェックが保証する経路の頑健性のため）。
func edge_kind(i: int, j: int) -> String:
	var a: Dictionary = holds[i]
	var b: Dictionary = holds[j]
	if float(b.height_m) <= float(a.height_m):
		return ""
	var d: float = Vector2(a.pos).distance_to(Vector2(b.pos))
	var safe_tap: float = TAP_REACH - WIND_MAX_AMPLITUDE
	if int(a.type) == HoldType.ICE:
		safe_tap -= ICE_REACH_PENALTY
	if d <= safe_tap:
		return "tap"
	elif d <= JUMP_REACH:
		return "jump"
	return ""

func move_cost(i: int, j: int) -> float:
	var kind := edge_kind(i, j)
	if kind == "tap":
		return float(TAP_COST[int(holds[j].type)])
	elif kind == "jump":
		return JUMP_COST
	return -1.0

## 区間 [from_idx, to_idx]（holds は高さ昇順なので配列添字の範囲）内だけで、from_idx から to_idx への
## 最小コスト経路を求める（DAG なので配列順に1回のDPで解ける）。戻り値: {cost, path: Array[int]} か null。
func _shortest_in_range(from_idx: int, to_idx: int) -> Variant:
	var n := to_idx - from_idx + 1
	var dist := PackedFloat64Array()
	dist.resize(n)
	var parent := PackedInt64Array()
	parent.resize(n)
	for k in range(n):
		dist[k] = INF
		parent[k] = -1
	dist[0] = 0.0
	for a in range(n):
		if dist[a] == INF:
			continue
		var i := from_idx + a
		for b in range(a + 1, n):
			var j := from_idx + b
			var cost := move_cost(i, j)
			if cost < 0.0:
				continue
			var nd: float = dist[a] + cost
			if nd < dist[b]:
				dist[b] = nd
				parent[b] = a
	var last := n - 1
	if dist[last] == INF:
		return null
	var path: Array = []
	var cur := last
	while cur != -1:
		path.push_front(from_idx + cur)
		cur = int(parent[cur])
	return {"cost": dist[last], "path": path}

## ふもと(0)から頂上(top_idx)まで、休憩できる岩棚ごとに区間を区切って各区間の最小握力消費を求める。
## 岩棚で握力は満タンに戻るので、区間ごとの最小消費が上限(100)以内であれば全体として登り切れる。
func check_route() -> Dictionary:
	var boundaries: Array = [0]
	for li in ledge_indices:
		if li != 0 and li != top_idx and not boundaries.has(li):
			boundaries.append(li)
	boundaries.append(top_idx)
	boundaries.sort()
	var full_path: Array = []
	var max_needed := 0.0
	for k in range(boundaries.size() - 1):
		var seg = _shortest_in_range(int(boundaries[k]), int(boundaries[k + 1]))
		if seg == null:
			return {"route_exists": false, "route_holds": false, "min_stamina_needed": -1.0, "path": []}
		max_needed = max(max_needed, float(seg.cost))
		var seg_path: Array = seg.path
		if full_path.size() > 0:
			seg_path = seg_path.slice(1)
		full_path.append_array(seg_path)
	return {
		"route_exists": true,
		"route_holds": max_needed <= 100.0,
		"min_stamina_needed": snappedf(max_needed, 0.01),
		"path": full_path,
	}
