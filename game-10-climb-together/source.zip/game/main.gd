extends Node2D
## よじのぼり岳 — 本体。岩壁データと最短経路探索は Wall(wall.gd) に集約し、ここでは
## 入力・状態遷移・演出・自動プレイ・Web向けの状態出力を扱う。

const ErrorCounter := preload("res://error_counter.gd")
const GAME_FONT := preload("res://fonts/MPLUSRounded1c-Bold-subset.ttf")
const CLIFF_LOWER := preload("res://art/cliff_lower.png")
const CLIFF_UPPER := preload("res://art/cliff_upper.png")
const HOLD_ART := [preload("res://art/holds_00.png"), preload("res://art/holds_01.png"), preload("res://art/holds_02.png"), preload("res://art/holds_03.png"), preload("res://art/holds_04.png"), preload("res://art/holds_05.png"), preload("res://art/holds_06.png")]
const CLIMBER_BODY := preload("res://art/climbers_00.png")
const CLIMBER_UPPER_ARM := preload("res://art/climbers_01.png")
const CLIMBER_FOREARM := preload("res://art/climbers_02.png")
const CLIMBER_GLOVE := preload("res://art/climbers_03.png")
const RIVAL_ART := preload("res://art/climbers_04.png")
const CANDY_ART := preload("res://art/pickups_fx_00.png")
const FX_ART := [preload("res://art/pickups_fx_01.png"), preload("res://art/pickups_fx_02.png"), preload("res://art/pickups_fx_03.png")]
const BUTTON_PLATE := preload("res://art/ui_plates_00.png")
const GAUGE_PLATE := preload("res://art/ui_plates_01.png")
const PANEL_PLATE := preload("res://art/ui_plates_02.png")

const BASE := Vector2(720, 1280)
const BEST_PATH := "user://best.json"
const BUTTON_COLOR := Color("ff7b54")
const FIXED_DT := 1.0 / 60.0
const BODY_DROP := 46.0
const CANCEL_RADIUS := 18.0
const MAX_TIME_SEC := 480.0
const AUTOPLAY_FAST_INTERVAL := 0.26
const DEMO_THINK_MIN := 0.6
const DEMO_THINK_MAX := 1.2
const DEMO_REACH_SECONDS := 0.45
const AUTOPLAY_FORCE_FALL_AFTER_GRABS := 5
const DEMO_TITLE_SECONDS := 2.0
const DEMO_RESULT_SECONDS := 3.0
const WIND_FREQ := 0.55
const UPPER_ARM_LEN := 95.0
const FOREARM_LEN := 95.0
const SHOULDER_OFFSET: Array[Vector2] = [Vector2(-20.0, -8.0), Vector2(20.0, -8.0)]
const RIVAL_X_OFFSET := 78.0
const RIVAL_SPEED_MPS := 2.35
const RIVAL_TARGET_TIME := 150.0
const RIVAL_FALL_PAUSE := 3.5

enum State { TITLE, PLAY, RESULT }

var state := State.TITLE
var logger: ErrorCounter
var wall: Wall
var route: Dictionary = {}
var qa_path_holds: Array = []
var qa_path_kind: Array = []
var rng := RandomNumberGenerator.new()
var fx_rng := RandomNumberGenerator.new()

# ---- CLI ----
var autoplay := false
var demo_mode := false
var wall_check_mode := false
var seed_val := 1
var timescale := 1.0
var autoplay_strategy := "steady"

# ---- ノード ----
var world: Node2D
var ui_layer: CanvasLayer
var title_panel: Control
var result_panel: Control
var height_label: Label
var time_label: Label
var result_text: Label
var result_best: Label
var title_best: Label
var stamina_label: Label
var gauge_plate: TextureRect
var stamina_bar_bg: ColorRect
var stamina_bar_fg: ColorRect
var camera_anchor_y := 600.0

# ---- プレイヤーの状態 ----
var hand_idx := [0, 0]
var free_hand := 0
var grabbed_time := [0.0, 0.0]
var stamina := 100.0
var ice_timer := 0.0
var candy_collected: Dictionary = {}
var camera_y := 0.0
var body_pos := Vector2.ZERO
var wind_phase := 0.0
var wind_offset_x := 0.0
var fall_shake := 0.0

var aiming := false
var press_pos := Vector2.ZERO
var drag_pos := Vector2.ZERO

# ---- 統計 ----
var time_sec := 0.0
var falls := 0
var grabs := 0
var jumps := 0
var stat_cleared := false
var max_height_m := 0.0
var first_ledge_time_sec := -1.0

# ---- 自動プレイ ----
var autoplay_path_pos := 1
var autoplay_move_cd := 0.0
var forced_fall_done := false
var reset_to_start_ok := false
var demo_transition_timer := 0.0
var planned_falls := 0

# ---- ライバル ----
var rival_height_m := 0.0
var rival_fall_time := 0.0
var rival_fallen := false
var rival_pause := 0.0
var rival_finish_time := -1.0

# ---- 演出 ----
var fx_list: Array = []

var best := {"best_time_sec": -1.0, "best_height_m": 0.0}

# ---------------------------------------------------------------- 起動

func _ready() -> void:
	logger = ErrorCounter.new()
	OS.add_logger(logger)
	fx_rng.randomize()
	wall = Wall.new()
	route = wall.check_route()
	qa_path_holds = route.get("path", [])
	for i in range(1, qa_path_holds.size()):
		qa_path_kind.append(wall.edge_kind(int(qa_path_holds[i - 1]), int(qa_path_holds[i])))
	_parse_args()
	if OS.has_feature("web") and not autoplay and not wall_check_mode:
		var query := String(JavaScriptBridge.eval("window.location.search", true)).trim_prefix("?")
		for parameter in query.split("&"):
			if parameter == "demo=1":
				demo_mode = true
				timescale = 1.0
				break
	rng.seed = seed_val
	if wall_check_mode:
		call_deferred("_run_wall_check")
		return
	_load_best()
	_build_world()
	_build_ui()
	get_viewport().size_changed.connect(_on_viewport_resized)
	_layout()
	if autoplay:
		_start_game()
	else:
		_show_title()
	# 折り返しLabelの最小高さは最初のコンテナ整列後に確定する。
	# 初回の大きな高さを保持しないよう、その後に正しい寸法で再配置する。
	call_deferred("_layout")

func _parse_args() -> void:
	var args := OS.get_cmdline_user_args()
	args.append_array(OS.get_cmdline_args())
	for a in args:
		if a == "--autoplay":
			autoplay = true
		elif a == "--wall-check":
			wall_check_mode = true
		elif a.begins_with("--seed="):
			seed_val = int(a.get_slice("=", 1))
		elif a.begins_with("--timescale="):
			timescale = float(a.get_slice("=", 1))
		elif a.begins_with("--strategy="):
			autoplay_strategy = a.get_slice("=", 1)
		elif a == "--inject-error":
			push_error.call_deferred("inject-error: 検証用のわざとのエラー")

func _run_wall_check() -> void:
	var out := {
		"route_exists": route.route_exists,
		"route_holds": route.get("route_holds", false),
		"min_stamina_needed": route.get("min_stamina_needed", -1.0),
		"errors": logger.get_errors(),
	}
	print(JSON.stringify(out))
	get_tree().quit(0 if logger.get_errors() == 0 else 1)

func _load_best() -> void:
	if FileAccess.file_exists(BEST_PATH):
		var f := FileAccess.open(BEST_PATH, FileAccess.READ)
		var parsed = JSON.parse_string(f.get_as_text())
		if typeof(parsed) == TYPE_DICTIONARY:
			best = parsed

func _save_best() -> void:
	var f := FileAccess.open(BEST_PATH, FileAccess.WRITE)
	f.store_string(JSON.stringify(best))

# ---------------------------------------------------------------- 組み立て

func _build_world() -> void:
	world = Node2D.new()
	world.name = "World"
	add_child(world)
	world.draw.connect(_draw_world)
	var hud_band := ColorRect.new()
	hud_band.color = Color(0.04, 0.09, 0.16, 0.64)
	hud_band.position = Vector2(0, 0)
	hud_band.size = Vector2(720, 116)
	world.add_child(hud_band)

	height_label = _label(30, Color.WHITE)
	height_label.position = Vector2(24, 30)
	world.add_child(height_label)
	time_label = _label(26, Color(0.9, 0.92, 1.0))
	time_label.position = Vector2(24, 70)
	world.add_child(time_label)

	gauge_plate = TextureRect.new()
	gauge_plate.texture = GAUGE_PLATE
	gauge_plate.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	gauge_plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	world.add_child(gauge_plate)
	stamina_label = _label(28, Color.WHITE)
	world.add_child(stamina_label)
	stamina_bar_bg = ColorRect.new()
	stamina_bar_bg.color = Color(0.04, 0.1, 0.12, 0.8)
	world.add_child(stamina_bar_bg)
	stamina_bar_fg = ColorRect.new()
	stamina_bar_fg.color = Color(0.4, 1.0, 0.5)
	world.add_child(stamina_bar_fg)

func _label(size: int, col: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_override("font", GAME_FONT)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0.05, 0.05, 0.1))
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

## タイトル/結果のオーバーレイ内の説明文用。コンテナ幅（520px）で折り返す設定を追加する
## （HUDの単発Labelにこれを付けると幅0扱いで1文字ずつ縦に折り返される事故になるため、
## VBoxContainer に入れる説明文にだけ個別に呼ぶ）。
func _wrap_label(l: Label) -> Label:
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

func _button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(300, 84)
	b.add_theme_font_override("font", GAME_FONT)
	b.add_theme_font_size_override("font_size", 30)
	var sb := StyleBoxTexture.new()
	sb.texture = BUTTON_PLATE
	sb.texture_margin_left = 55.0
	sb.texture_margin_right = 55.0
	sb.texture_margin_top = 35.0
	sb.texture_margin_bottom = 35.0
	b.add_theme_stylebox_override("normal", sb)
	var sb2 := sb.duplicate()
	sb2.modulate_color = Color(1.15, 1.15, 1.15)
	b.add_theme_stylebox_override("hover", sb2)
	b.add_theme_stylebox_override("pressed", sb2)
	b.add_theme_color_override("font_color", Color("17273b"))
	b.add_theme_color_override("font_hover_color", Color("17273b"))
	b.add_theme_color_override("font_pressed_color", Color("17273b"))
	return b

func _overlay() -> Control:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color(0.05, 0.06, 0.14, 0.86)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(bg)
	var plate := TextureRect.new()
	plate.texture = PANEL_PLATE
	plate.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	plate.set_anchors_preset(Control.PRESET_CENTER)
	plate.position = Vector2(-310, -280)
	plate.size = Vector2(620, 560)
	plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(plate)
	var box := VBoxContainer.new()
	# 折り返しLabelを幅0の中央アンカーで初期化すると、縦の最小サイズが
	# 数千pxまで膨らみ、後で幅を指定してもその高さが残る。
	box.set_anchors_preset(Control.PRESET_TOP_LEFT)
	box.custom_minimum_size = Vector2(520, 0)
	box.size = Vector2(520, 0)
	box.add_theme_constant_override("separation", 20)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	root.add_child(box)
	root.set_meta("box", box)
	return root

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	ui_layer.layer = 10
	add_child(ui_layer)

	title_panel = _overlay()
	var tb := title_panel.get_meta("box") as VBoxContainer
	var t1 := _label(50, Color("ffd27a"))
	t1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t1.text = "よじのぼり岳"
	tb.add_child(t1)
	var t2 := _wrap_label(_label(26, Color.WHITE))
	t2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t2.text = "光る岩をタップしてつかみ、体を寄せながら登る\n上へなぞって離すと遠い岩へ飛びつける"
	tb.add_child(t2)
	var t3 := _wrap_label(_label(26, Color(0.82, 0.85, 1.0)))
	t3.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t3.text = "握力が尽きるとふもとまで落ちて最初から。日没（8分）までに山頂を目指そう"
	tb.add_child(t3)
	title_best = _wrap_label(_label(26, Color("ffd27a")))
	title_best.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tb.add_child(title_best)
	var start_btn := _button("はじめる")
	start_btn.pressed.connect(_start_game)
	var start_wrap := CenterContainer.new()
	start_wrap.add_child(start_btn)
	tb.add_child(start_wrap)
	title_panel.visible = false
	ui_layer.add_child(title_panel)

	result_panel = _overlay()
	var rb := result_panel.get_meta("box") as VBoxContainer
	result_text = _wrap_label(_label(28, Color("ffd27a")))
	result_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rb.add_child(result_text)
	result_best = _wrap_label(_label(26, Color(0.85, 0.9, 1.0)))
	result_best.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rb.add_child(result_best)
	var retry_btn := _button("もういちど")
	retry_btn.pressed.connect(_start_game)
	var retry_wrap := CenterContainer.new()
	retry_wrap.add_child(retry_btn)
	rb.add_child(retry_wrap)
	result_panel.visible = false
	ui_layer.add_child(result_panel)

func _layout() -> void:
	if world == null:
		return
	var vp := get_viewport().get_visible_rect().size
	world.position = ((vp - BASE) / 2.0).floor()
	var visible_local: Rect2 = world.get_global_transform_with_canvas().affine_inverse() * get_viewport().get_visible_rect()
	camera_anchor_y = visible_local.position.y + visible_local.size.y * 0.52 - BODY_DROP
	_layout_stamina_panel(visible_local)
	_layout_overlay(title_panel)
	_layout_overlay(result_panel)
	world.queue_redraw()

func _on_viewport_resized() -> void:
	_layout()
	call_deferred("_layout")

## タイトル・結果パネルの絵と文字を、実際の可視矩形の内側に収める。
func _layout_overlay(panel: Control) -> void:
	if panel == null:
		return
	var visible_rect := get_viewport().get_visible_rect()
	var margin := 24.0
	var safe_rect := visible_rect.grow(-margin)
	var fit := minf(1.0, minf(safe_rect.size.x / 620.0, safe_rect.size.y / 560.0))
	var plate_size := Vector2(620.0, 560.0) * fit
	var plate := panel.get_child(1) as Control
	plate.set_anchors_preset(Control.PRESET_TOP_LEFT)
	plate.position = safe_rect.position + (safe_rect.size - plate_size) * 0.5
	plate.size = plate_size
	var box := panel.get_meta("box") as VBoxContainer
	var box_size := Vector2(520.0, 480.0) * fit
	box.custom_minimum_size = Vector2(box_size.x, 0.0)
	box.size = box_size
	box.position = safe_rect.position + (safe_rect.size - box.size) * 0.5

## 画面下部の握力パネルを、expand を含む実可視矩形の内側に配置する。
## 同じ ui_plates の板の中にラベルとゲージをまとめ、空の板だけが見える状態をなくす。
func _layout_stamina_panel(visible_local: Rect2) -> void:
	var margin := 12.0
	var panel_size := Vector2(minf(448.0, visible_local.size.x - margin * 2.0),
		minf(96.0, visible_local.size.y - margin * 2.0))
	if panel_size.x <= 0.0 or panel_size.y <= 0.0:
		gauge_plate.visible = false
		stamina_label.visible = false
		stamina_bar_bg.visible = false
		stamina_bar_fg.visible = false
		return
	var panel_pos := Vector2(
		visible_local.position.x + (visible_local.size.x - panel_size.x) * 0.5,
		visible_local.end.y - margin - panel_size.y
	)
	# 元画像は726×201px。TextureRectの最小サイズを無視し、指定の448×96内へ縮める。
	var scale_x := panel_size.x / 448.0
	var scale_y := panel_size.y / 96.0
	gauge_plate.visible = true
	gauge_plate.position = panel_pos
	gauge_plate.size = panel_size
	stamina_label.visible = true
	stamina_label.position = panel_pos + Vector2(42.0 * scale_x, 30.0 * scale_y)
	stamina_label.size = Vector2(152.0 * scale_x, 36.0 * scale_y)
	stamina_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	stamina_label.add_theme_font_size_override("font_size", maxi(18, roundi(28.0 * minf(scale_x, scale_y))))
	stamina_bar_bg.visible = true
	stamina_bar_bg.position = panel_pos + Vector2(206.0 * scale_x, 40.0 * scale_y)
	stamina_bar_bg.size = Vector2((panel_size.x - 248.0 * scale_x), 16.0 * scale_y)
	stamina_bar_fg.visible = true
	stamina_bar_fg.position = stamina_bar_bg.position
	stamina_bar_fg.size = Vector2(stamina_bar_bg.size.x * clamp(stamina / 100.0, 0.0, 1.0), stamina_bar_bg.size.y)

# ---------------------------------------------------------------- 状態遷移

func _reset_player() -> void:
	hand_idx = [0, 0]
	free_hand = 0
	grabbed_time = [0.0, 0.0]
	stamina = 100.0
	ice_timer = 0.0
	candy_collected.clear()
	fall_shake = 0.0

func _start_game() -> void:
	state = State.PLAY
	title_panel.visible = false
	result_panel.visible = false
	_reset_player()
	time_sec = 0.0
	falls = 0
	grabs = 0
	jumps = 0
	stat_cleared = false
	max_height_m = 0.0
	first_ledge_time_sec = -1.0
	autoplay_path_pos = 1
	autoplay_move_cd = _next_autoplay_delay() if autoplay or demo_mode else 0.0
	forced_fall_done = false
	planned_falls = 0
	reset_to_start_ok = false
	demo_transition_timer = 0.0
	fx_list.clear()
	rival_height_m = 0.0
	rival_fallen = false
	rival_pause = 0.0
	rival_finish_time = -1.0
	rival_fall_time = RIVAL_TARGET_TIME * rng.randf_range(0.35, 0.65)
	_refresh_web_state()

func _height_m() -> float:
	return max(float(wall.hold(hand_idx[0]).height_m), float(wall.hold(hand_idx[1]).height_m))

func _fall() -> void:
	falls += 1
	_reset_player()
	if autoplay or demo_mode:
		autoplay_path_pos = 1
		autoplay_move_cd = _next_autoplay_delay()
	fall_shake = 1.0
	_spawn_fx("fall", Vector2(360.0, 0.0))

func _finish_run(cleared: bool) -> void:
	state = State.RESULT
	stat_cleared = cleared
	var h := _height_m()
	if h > float(best.get("best_height_m", 0.0)):
		best["best_height_m"] = h
	var new_record_time := false
	if cleared:
		var bt: float = float(best.get("best_time_sec", -1.0))
		if bt < 0.0 or time_sec < bt:
			best["best_time_sec"] = time_sec
			new_record_time = true
		_save_best()
	else:
		_save_best()
	_refresh_web_state()
	if autoplay:
		_output_autoplay_json()
		get_tree().quit(0 if logger.get_errors() == 0 else 1)
	else:
		_show_result(cleared, new_record_time)
		if demo_mode:
			demo_transition_timer = DEMO_RESULT_SECONDS

func _show_title() -> void:
	state = State.TITLE
	title_panel.visible = true
	result_panel.visible = false
	title_best.text = _best_summary(true)
	if demo_mode:
		demo_transition_timer = DEMO_TITLE_SECONDS
	_refresh_web_state()

func _best_summary(show_missing_time: bool = false) -> String:
	var bh: float = float(best.get("best_height_m", 0.0))
	var bt: float = float(best.get("best_time_sec", -1.0))
	var summary := "自己ベスト高さ: %dm" % [int(bh)]
	if bt >= 0.0:
		summary += "　自己ベストタイム: %ds" % [int(bt)]
	elif show_missing_time:
		summary += "　自己ベストタイム: なし"
	return summary

func _show_result(cleared: bool, new_record_time: bool) -> void:
	title_panel.visible = false
	result_panel.visible = true
	var h := _height_m()
	var diff := time_sec - rival_finish_time if rival_finish_time > 0.0 else -1.0
	if cleared:
		result_text.text = "登頂成功！\n高さ %dm　タイム %ds" % [int(h), int(time_sec)]
	else:
		result_text.text = "日没で終了…\n到達 %dm" % [int(h)]
	var extra := "落下 %d回　握った回数 %d　飛びつき %d" % [falls, grabs, jumps]
	if rival_finish_time > 0.0:
		if diff < 0.0:
			extra += "\nライバルより %ds 速く登頂！" % [int(abs(diff))]
		else:
			extra += "\nライバルに %ds 及ばず" % [int(diff)]
	else:
		extra += "\nライバルはまだ山頂に着いていない"
	extra += "\n" + _best_summary()
	if new_record_time:
		extra += "\n新記録！"
	result_best.text = extra
	_refresh_web_state()

# ---------------------------------------------------------------- 入力（ポインターのみ）

func _to_wall(p_screen: Vector2) -> Vector2:
	return Vector2(p_screen.x, p_screen.y + camera_y)

func _effective_tap_reach() -> float:
	return Wall.TAP_REACH - (Wall.ICE_REACH_PENALTY if ice_timer > 0.0 else 0.0)

## 届く範囲の基準点。自由な手が次の岩を探す起点は「動かない方の手（アンカー）」の位置とする
## （壁データの届く関係グラフ = Wall.edge_kind() も同じくホールド同士の距離で判定しているので、
## 実プレイの届く範囲判定をこれに一致させないと、壁チェックが「登れる」と保証した経路が実際には
## タップで届かない、という食い違いが起きる。Web版の実プレイボット検証でこの食い違いを発見した）。
## 風で「揺れている間は届く範囲がずれる」を表すため、体の横揺れ分だけ基準点をずらす。
func _reach_origin() -> Vector2:
	return wall.hold(hand_idx[1 - free_hand]).pos + Vector2(wind_offset_x, 0.0)

func _reachable_holds() -> Array:
	var out: Array = []
	var reach := _effective_tap_reach()
	var cur_h := _height_m()
	var origin := _reach_origin()
	for h in wall.holds:
		if int(h.idx) == hand_idx[0] or int(h.idx) == hand_idx[1]:
			continue
		if float(h.height_m) <= cur_h - 0.001:
			continue
		if origin.distance_to(h.pos) <= reach:
			out.append(h)
	return out

## タップでは届かないが飛びつきなら届く岩（方向はどれでもよい。Web検証ボットが正しい方向へ
## ドラッグできるよう、狙うべき岩の座標を教えるためのもの）。
func _jumpable_holds() -> Array:
	var out: Array = []
	var reach := _effective_tap_reach()
	var cur_h := _height_m()
	var origin := _reach_origin()
	for h in wall.holds:
		if int(h.idx) == hand_idx[0] or int(h.idx) == hand_idx[1]:
			continue
		if float(h.height_m) <= cur_h - 0.001:
			continue
		var d: float = origin.distance_to(h.pos)
		if d > reach and d <= Wall.JUMP_REACH:
			out.append(h)
	return out

func _find_tap_target(p_wall: Vector2) -> int:
	var best_idx := -1
	var best_d := INF
	for h in _reachable_holds():
		var d: float = p_wall.distance_to(h.pos)
		if d <= float(h.radius) + 16.0 and d < best_d:
			best_d = d
			best_idx = int(h.idx)
	return best_idx

func _input(event: InputEvent) -> void:
	if autoplay or demo_mode or wall_check_mode:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		var p: Vector2 = world.get_global_transform_with_canvas().affine_inverse() * event.position
		if event.pressed:
			if state == State.PLAY:
				var target := _find_tap_target(_to_wall(p))
				if target != -1:
					_grab_hold_finish(target, false)
				else:
					aiming = true
					press_pos = p
					drag_pos = p
		else:
			if aiming:
				aiming = false
				var drag_vec: Vector2 = drag_pos - press_pos
				if drag_vec.length() >= CANCEL_RADIUS:
					_try_jump(drag_vec.normalized())
	elif event is InputEventMouseMotion and aiming:
		drag_pos = world.get_global_transform_with_canvas().affine_inverse() * event.position

## 飛びつき。タップでも届く近い岩も候補に含める（狙いが多少ずれても、なぞった方向に一番近い
## 岩へ飛びつけた方が理不尽な失敗が減る。タップより握力を多く使う点で損なだけにしてある）。
func _try_jump(dir: Vector2) -> void:
	var best_idx := -1
	var best_dot := -INF
	var cur_h := _height_m()
	var origin := _reach_origin()
	for h in wall.holds:
		if int(h.idx) == hand_idx[0] or int(h.idx) == hand_idx[1]:
			continue
		if float(h.height_m) <= cur_h - 0.001:
			continue
		var d: float = origin.distance_to(h.pos)
		if d > Wall.JUMP_REACH:
			continue
		var to_dir: Vector2 = (Vector2(h.pos) - origin).normalized()
		var dt: float = to_dir.dot(dir)
		if dt < 0.3:
			continue
		# なぞった方向に一番近い（角度がぴったり合う）岩へ飛びつく（距離では選ばない。狙った先に
		# 近い別の岩へ意図せず飛んでしまうのを防ぐ）。
		if dt > best_dot:
			best_dot = dt
			best_idx = int(h.idx)
	if best_idx == -1:
		stamina = max(0.0, stamina - Wall.JUMP_COST)
		_fall()
	else:
		_grab_hold_finish(best_idx, true)

# ---------------------------------------------------------------- 掴む・進む（実プレイ／自動プレイ共通）

func _grab_hold_finish(target_idx: int, is_jump: bool) -> void:
	var hold: Dictionary = wall.hold(target_idx)
	var cost: float = Wall.JUMP_COST if is_jump else float(Wall.TAP_COST[int(hold.type)])
	hand_idx[free_hand] = target_idx
	grabbed_time[free_hand] = 0.0
	var t: int = int(hold.type)
	if t == Wall.HoldType.LEDGE or t == Wall.HoldType.TOP:
		hand_idx[1 - free_hand] = target_idx
		grabbed_time[1 - free_hand] = 0.0
	free_hand = 1 - free_hand
	stamina = max(0.0, stamina - cost)
	if is_jump:
		jumps += 1
	else:
		grabs += 1
	if bool(hold.candy) and not candy_collected.get(target_idx, false):
		candy_collected[target_idx] = true
		stamina = min(100.0, stamina + 40.0)
		_spawn_fx("candy", hold.pos)
	if t == Wall.HoldType.ICE:
		ice_timer = Wall.ICE_PENALTY_SECONDS
	if t == Wall.HoldType.LEDGE or t == Wall.HoldType.TOP:
		stamina = 100.0
	if t == Wall.HoldType.LEDGE and first_ledge_time_sec < 0.0:
		first_ledge_time_sec = time_sec
	max_height_m = maxf(max_height_m, _height_m())
	_spawn_fx("grab", hold.pos)
	if stamina <= 0.0:
		_fall()

# ---------------------------------------------------------------- 自動プレイ

func _autoplay_step(dt: float) -> void:
	autoplay_move_cd -= dt
	if autoplay_move_cd > 0.0:
		return
	var path: Array = route.get("path", [])
	if autoplay_path_pos >= path.size():
		return
	var prev_idx: int = int(path[autoplay_path_pos - 1])
	var target_idx: int = int(path[autoplay_path_pos])
	var kind := wall.edge_kind(prev_idx, target_idx)
	var is_jump: bool = kind == "jump"
	_grab_hold_finish(target_idx, is_jump)
	# 握力切れや崩落で手が0番へ戻った場合、古い経路位置を進めない。
	if _height_m() <= 0.001:
		return
	autoplay_path_pos += 1
	autoplay_move_cd = _next_autoplay_delay()
	if int(wall.hold(target_idx).type) == Wall.HoldType.LEDGE and autoplay_strategy != "fast":
		autoplay_move_cd += 2.0
	var should_fall := false
	if autoplay_strategy == "fast":
		should_fall = not forced_fall_done and (grabs + jumps) >= AUTOPLAY_FORCE_FALL_AFTER_GRABS
	elif planned_falls < 3:
		var fall_height: float = [55.0, 165.0, 220.0][planned_falls]
		should_fall = _height_m() >= fall_height
	if should_fall:
		forced_fall_done = true
		planned_falls += 1
		stamina = 0.0
		_fall()
		reset_to_start_ok = _height_m() <= 0.001

func _next_autoplay_delay() -> float:
	if autoplay_strategy == "fast":
		return AUTOPLAY_FAST_INTERVAL
	var think := rng.randf_range(DEMO_THINK_MIN, DEMO_THINK_MAX)
	if autoplay_strategy == "cautious":
		think = DEMO_THINK_MAX
	return think + DEMO_REACH_SECONDS

# ---------------------------------------------------------------- ライバル

func _update_rival(dt: float) -> void:
	if rival_finish_time > 0.0:
		return
	if not rival_fallen and time_sec >= rival_fall_time:
		rival_fallen = true
		rival_height_m = 0.0
		rival_pause = RIVAL_FALL_PAUSE
		return
	if rival_pause > 0.0:
		rival_pause = max(0.0, rival_pause - dt)
		return
	rival_height_m = min(Wall.WALL_HEIGHT_M, rival_height_m + RIVAL_SPEED_MPS * dt)
	if rival_height_m >= Wall.WALL_HEIGHT_M - 0.001 and rival_finish_time < 0.0:
		rival_finish_time = time_sec

func _rival_screen_x(h: float) -> float:
	var frac: float = clamp(h / Wall.WALL_HEIGHT_M, 0.0, 1.0)
	var idx: int = int(round(frac * float(wall.holds.size() - 1)))
	idx = clampi(idx, 0, wall.holds.size() - 1)
	return clampf(float(wall.hold(idx).pos.x) + RIVAL_X_OFFSET, 90.0, 700.0)

# ---------------------------------------------------------------- フレーム更新

func _tick(dt: float) -> void:
	time_sec += dt
	wind_phase += dt * WIND_FREQ
	if ice_timer > 0.0:
		ice_timer = max(0.0, ice_timer - dt)
	if fall_shake > 0.0:
		fall_shake = max(0.0, fall_shake - dt * 0.7)

	for i in range(2):
		var t: int = int(wall.hold(hand_idx[i]).type)
		if t == Wall.HoldType.CRUMBLE:
			grabbed_time[i] += dt
			if grabbed_time[i] > Wall.CRUMBLE_SECONDS:
				_fall()
				return
		else:
			grabbed_time[i] = 0.0

	var t0: int = int(wall.hold(hand_idx[0]).type)
	var t1: int = int(wall.hold(hand_idx[1]).type)
	var rate: float = (float(Wall.IDLE_DRAIN[t0]) + float(Wall.IDLE_DRAIN[t1])) / 2.0
	stamina = max(0.0, stamina - rate * dt)
	if stamina <= 0.0:
		_fall()
		return

	if autoplay or demo_mode:
		_autoplay_step(dt)

	_update_rival(dt)
	_age_fx(dt)

	if _height_m() >= Wall.WALL_HEIGHT_M - 0.001:
		_finish_run(true)
		return
	if time_sec >= MAX_TIME_SEC:
		_finish_run(false)
		return

func _physics_process(delta: float) -> void:
	if wall_check_mode:
		return
	if state != State.PLAY:
		if demo_mode:
			demo_transition_timer -= delta
			if demo_transition_timer <= 0.0:
				_start_game()
		return
	var n := int(max(1.0, timescale))
	for _i in range(n):
		_tick(FIXED_DT)
		if state != State.PLAY:
			break

func _process(_delta: float) -> void:
	if wall_check_mode:
		return
	_update_body()
	_refresh_hud()
	_refresh_web_state()
	if world:
		world.queue_redraw()

func _update_body() -> void:
	var p0: Vector2 = wall.hold(hand_idx[0]).pos
	var p1: Vector2 = wall.hold(hand_idx[1]).pos
	var mid: Vector2 = (p0 + p1) / 2.0
	var h: float = _height_m()
	var amp: float = clamp(h / Wall.WALL_HEIGHT_M, 0.0, 1.0) * Wall.WIND_MAX_AMPLITUDE
	wind_offset_x = sin(wind_phase) * amp
	body_pos = mid + Vector2(wind_offset_x, BODY_DROP)
	camera_y = mid.y - camera_anchor_y

func _refresh_hud() -> void:
	if height_label == null:
		return
	height_label.text = "高さ %dm / 300m" % [int(_height_m())]
	var remain: int = int(max(0.0, MAX_TIME_SEC - time_sec))
	time_label.text = "残り %d:%02d" % [remain / 60, remain % 60]
	if stamina_bar_fg:
		stamina_bar_fg.size.x = stamina_bar_bg.size.x * clamp(stamina / 100.0, 0.0, 1.0)
		stamina_bar_fg.color = Color(0.4, 1.0, 0.5) if stamina > 30.0 else Color(1.0, 0.4, 0.35)
	if stamina_label:
		stamina_label.text = "握力 %d%%" % [int(round(stamina))]

func _refresh_web_state() -> void:
	if not OS.has_feature("web"):
		return
	var reachable_px: Array = []
	var jumpable_px: Array = []
	var qa_path_px: Array = []
	var qa_path_height_m: Array = []
	if state == State.PLAY:
		for h in _reachable_holds():
			reachable_px.append(_global_px(h.pos))
		for h in _jumpable_holds():
			jumpable_px.append(_global_px(h.pos))
		for idx in qa_path_holds:
			qa_path_px.append(_global_px(wall.hold(int(idx)).pos))
			qa_path_height_m.append(float(wall.hold(int(idx)).height_m))
	var st := {
		"state": ["title", "play", "result"][state],
		"height_m": _height_m(),
		"stamina": stamina,
		"aiming": aiming,
		"result_visible": state == State.RESULT,
		"top_reached": stat_cleared,
		"errors": logger.get_errors(),
		"viewport": [get_viewport_rect().size.x, get_viewport_rect().size.y],
		"reachable_px": reachable_px,
		"jumpable_px": jumpable_px,
		"body_px": _global_px(_reach_origin()),
		"qa_path_px": qa_path_px,
		"qa_path_kind": qa_path_kind,
		"qa_path_height_m": qa_path_height_m,
	}
	if title_panel and title_panel.visible:
		st["start_btn_px"] = _button_center_px(title_panel)
	if result_panel and result_panel.visible:
		st["retry_btn_px"] = _button_center_px(result_panel)
	JavaScriptBridge.eval("window.__climb = %s;" % JSON.stringify(st), true)

func _button_center_px(panel: Control) -> Array:
	var box := panel.get_meta("box") as VBoxContainer
	for c in box.get_children():
		if c is CenterContainer:
			for gc in c.get_children():
				if gc is Button:
					var gp: Vector2 = gc.global_position + gc.size / 2.0
					return [gp.x, gp.y]
	return []

func _local_screen_pos(world_pos: Vector2) -> Vector2:
	return Vector2(world_pos.x, world_pos.y - camera_y)

func _global_px(world_pos: Vector2) -> Array:
	var lp := _local_screen_pos(world_pos)
	var gp: Vector2 = world.position + lp
	return [gp.x, gp.y]

# ---------------------------------------------------------------- 演出

func _spawn_fx(kind: String, pos: Vector2) -> void:
	fx_list.append({"kind": kind, "pos": pos, "age": 0.0, "life": 0.5 if kind != "fall" else 1.0})
	while fx_list.size() > 40:
		fx_list.pop_front()

func _age_fx(delta: float) -> void:
	var i := fx_list.size() - 1
	while i >= 0:
		fx_list[i].age = float(fx_list[i].age) + delta
		if float(fx_list[i].age) >= float(fx_list[i].life):
			fx_list.remove_at(i)
		i -= 1

# ---------------------------------------------------------------- IK（肩・ひじ・手の2関節）

func _ik_elbow(shoulder: Vector2, hand: Vector2, l1: float, l2: float, bend: float) -> Vector2:
	var diff: Vector2 = hand - shoulder
	var d: float = clamp(diff.length(), absf(l1 - l2) + 0.5, l1 + l2 - 0.5)
	var dir: Vector2 = diff.normalized() if diff.length() > 0.001 else Vector2.DOWN
	var a: float = (d * d + l1 * l1 - l2 * l2) / (2.0 * d)
	var hgt: float = sqrt(max(0.0, l1 * l1 - a * a))
	var mid: Vector2 = shoulder + dir * a
	var perp: Vector2 = Vector2(-dir.y, dir.x)
	return mid + perp * hgt * bend

# ---------------------------------------------------------------- 描画

func _sky_color(h: float) -> Color:
	var k: float = clamp(h / Wall.WALL_HEIGHT_M, 0.0, 1.0)
	var low := Color(0.55, 0.72, 0.85)
	var mid := Color(0.75, 0.82, 0.92)
	var high := Color(0.10, 0.14, 0.32)
	if k < 0.45:
		return low.lerp(mid, k / 0.45)
	return mid.lerp(high, (k - 0.45) / 0.55)

func _draw_world() -> void:
	var h := _height_m()
	var visible_local: Rect2 = world.get_global_transform_with_canvas().affine_inverse() * get_viewport().get_visible_rect()
	var off: Vector2 = Vector2.ZERO
	if fall_shake > 0.01:
		off = Vector2(fx_rng.randf_range(-1.0, 1.0), fx_rng.randf_range(-1.0, 1.0)) * fall_shake * 14.0

	# visible_rect を world の canvas 変換で戻し、expand で増えた範囲も比率を保って覆う。
	var cover_scale: float = max(visible_local.size.x / CLIFF_LOWER.get_width(), visible_local.size.y / CLIFF_LOWER.get_height())
	var bg_size: Vector2 = CLIFF_LOWER.get_size() * cover_scale
	var bg_rect := Rect2(visible_local.get_center() - bg_size / 2.0, bg_size)
	world.draw_texture_rect(CLIFF_LOWER, bg_rect, false)
	var upper_mix: float = smoothstep(90.0, 250.0, h)
	if upper_mix > 0.0:
		world.draw_texture_rect(CLIFF_UPPER, bg_rect, false, Color(1, 1, 1, upper_mix))
	world.draw_rect(visible_local, _sky_color(h).darkened(0.3) * Color(1, 1, 1, 0.06))

	for cand in wall.holds:
		if not bool(cand.candy) or candy_collected.get(int(cand.idx), false):
			continue
		var cp := _local_screen_pos(cand.pos) + off
		world.draw_texture_rect(CANDY_ART, Rect2(cp + Vector2(-16, -50), Vector2(32, 28)), false)
		world.draw_arc(cp + Vector2(0, -36.0), 16.0, 0, TAU, 12, Color("fff3c0", 0.55), 2.0)

	for hd in wall.holds:
		var reachable: bool = _is_reachable(hd)
		var p := _local_screen_pos(hd.pos) + off
		if p.y < visible_local.position.y - 160.0 or p.y > visible_local.end.y + 160.0:
			continue
		if int(hd.type) == Wall.HoldType.CRUMBLE:
			var shake := 0.0
			if int(hd.idx) == hand_idx[0]:
				shake = grabbed_time[0] / Wall.CRUMBLE_SECONDS
			elif int(hd.idx) == hand_idx[1]:
				shake = grabbed_time[1] / Wall.CRUMBLE_SECONDS
			if shake > 0.0:
				p += Vector2(fx_rng.randf_range(-1, 1), fx_rng.randf_range(-1, 1)) * shake * 4.0
		var radius: float = float(hd.radius)
		world.draw_texture_rect(HOLD_ART[int(hd.type)], Rect2(p - Vector2(radius, radius), Vector2(radius * 2.0, radius * 2.0)), false)
		if int(hd.type) == Wall.HoldType.ICE:
			world.draw_arc(p, radius + 1.0, 0, TAU, 18, Color(1, 1, 1, 0.7), 2.0)
		if reachable:
			world.draw_arc(p, float(hd.radius) + 6.0, 0, TAU, 28, Color(1, 1, 0.55, 0.95), 4.0)

	_draw_rival(off)
	_draw_player(off)
	_draw_fx(off)

	if aiming:
		_draw_aim_line()

func _is_reachable(hd: Dictionary) -> bool:
	if state != State.PLAY:
		return false
	if int(hd.idx) == hand_idx[0] or int(hd.idx) == hand_idx[1]:
		return false
	if float(hd.height_m) <= _height_m() - 0.001:
		return false
	return _reach_origin().distance_to(hd.pos) <= _effective_tap_reach()

func _draw_aim_line() -> void:
	var drag_vec: Vector2 = drag_pos - press_pos
	if drag_vec.length() < CANCEL_RADIUS:
		return
	var body_screen := _local_screen_pos(body_pos)
	world.draw_line(body_screen, body_screen + drag_vec, Color(1, 1, 1, 0.85), 4.0, true)
	world.draw_circle(body_screen + drag_vec, 8.0, Color(1, 0.9, 0.4, 0.9))

func _draw_arm(shoulder: Vector2, hand: Vector2, bend: float, tremble: float) -> void:
	var elbow := _ik_elbow(shoulder, hand, UPPER_ARM_LEN, FOREARM_LEN, bend)
	if tremble > 0.0:
		elbow += Vector2(fx_rng.randf_range(-1, 1), fx_rng.randf_range(-1, 1)) * tremble * 3.0
	_draw_limb(CLIMBER_UPPER_ARM, shoulder, elbow, 24.0)
	_draw_limb(CLIMBER_FOREARM, elbow, hand, 21.0)
	world.draw_texture_rect(CLIMBER_GLOVE, Rect2(hand - Vector2(12, 12), Vector2(24, 24)), false)

func _draw_limb(texture: Texture2D, start: Vector2, end: Vector2, width: float) -> void:
	var diff := end - start
	world.draw_set_transform(start, Vector2.DOWN.angle_to(diff), Vector2.ONE)
	world.draw_texture_rect(texture, Rect2(-width / 2.0, 0.0, width, diff.length()), false)
	world.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _draw_player(off: Vector2) -> void:
	var body_screen := _local_screen_pos(body_pos) + off
	var hand_screen := [
		_local_screen_pos(wall.hold(hand_idx[0]).pos) + off,
		_local_screen_pos(wall.hold(hand_idx[1]).pos) + off,
	]
	var tremble: float = clamp(1.0 - stamina / 35.0, 0.0, 1.0)
	for i in range(2):
		var shoulder := body_screen + SHOULDER_OFFSET[i]
		_draw_arm(shoulder, hand_screen[i], -1.0 if i == 0 else 1.0, tremble)
	world.draw_texture_rect(CLIMBER_BODY, Rect2(body_screen + Vector2(-36, -54), Vector2(72, 94)), false)

func _draw_rival(off: Vector2) -> void:
	var x := _rival_screen_x(rival_height_m)
	var rival_world := Vector2(x, -rival_height_m * Wall.PX_PER_M)
	var p := _local_screen_pos(rival_world) + off
	world.draw_texture_rect(RIVAL_ART, Rect2(p + Vector2(-30, -50), Vector2(60, 78)), false, Color(1, 1, 1, 0.55))

func _draw_fx(off: Vector2) -> void:
	for fx in fx_list:
		var k: float = clamp(float(fx.age) / float(fx.life), 0.0, 1.0)
		var p: Vector2 = _local_screen_pos(fx.pos) + off
		var art_idx := 0 if String(fx.kind) == "grab" else (1 if String(fx.kind) == "candy" else 2)
		var size := (26.0 + 35.0 * k) if art_idx < 2 else (42.0 + 80.0 * k)
		world.draw_texture_rect(FX_ART[art_idx], Rect2(p - Vector2(size, size) / 2.0, Vector2(size, size)), false, Color(1, 1, 1, 1.0 - k))

# ---------------------------------------------------------------- JSON 出力（自動プレイ）

func _output_autoplay_json() -> void:
	var out := {
		"height_m": _height_m(),
		"max_height_m": max_height_m,
		"first_ledge_time_sec": snappedf(first_ledge_time_sec, 0.01),
		"strategy": autoplay_strategy,
		"top_reached": stat_cleared,
		"falls": falls,
		"grabs": grabs,
		"jumps": jumps,
		"time_sec": snappedf(time_sec, 0.01),
		"rival_time_sec": rival_finish_time if rival_finish_time > 0.0 else -1.0,
		"reset_to_start_ok": reset_to_start_ok,
		"errors": logger.get_errors(),
	}
	print(JSON.stringify(out))
