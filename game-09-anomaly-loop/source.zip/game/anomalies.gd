extends RefCounted
## 異変カタログ（26種）。各異変は Scenery.apply_override() に渡す1件の上書き
## （target/field/value）と、検証カメラの位置 focus_x、通知ノート文を持つだけ。
## dynamic=true は「時間で変わる」異変で、check_anomaly_diff 用に複数の時刻(sample_ts)で撮る。
class_name Anomalies

const DEFAULT_SAMPLE_TS := [2.0, 10.0, 18.0]

const DATA := [
	# --- やさしい -------------------------------------------------------
	{"id": "light_red", "tier": "easy", "target": "light_3", "field": "tint", "value": "red",
		"focus_x": 1015.0, "note": "蛍光灯が1本だけ赤い"},
	{"id": "light_off", "tier": "easy", "target": "light_6", "field": "lit", "value": false,
		"focus_x": 1885.0, "note": "蛍光灯が1本だけ消えている"},
	{"id": "door_missing", "tier": "easy", "target": "door_2", "field": "visible", "value": false,
		"focus_x": 1960.0, "note": "扉が1枚足りない"},
	{"id": "door_extra", "tier": "easy", "target": "door_extra", "field": "visible", "value": true,
		"focus_x": 2470.0, "note": "扉が1枚多い"},
	{"id": "poster_upside_down", "tier": "easy", "target": "poster_mountain", "field": "flipped", "value": true,
		"focus_x": 260.0, "note": "ポスターが逆さま"},
	{"id": "poster_color_swap", "tier": "easy", "target": "poster_event", "field": "palette", "value": "alt",
		"focus_x": 2260.0, "note": "ポスターの色合いがいつもと違う"},
	{"id": "vending_missing", "tier": "easy", "target": "vending_0", "field": "visible", "value": false,
		"focus_x": 1560.0, "note": "自販機が無い"},
	{"id": "vending_color", "tier": "easy", "target": "vending_0", "field": "color_mode", "value": "alt",
		"focus_x": 1560.0, "note": "自販機の色が違う"},
	{"id": "wall_tint", "tier": "easy", "target": "backwall_0", "field": "tint", "value": "alt",
		"focus_x": 1450.0, "note": "壁の色がいつもと違う"},

	# --- ふつう -----------------------------------------------------------
	{"id": "tile_pattern_diff", "tier": "normal", "target": "tile_14", "field": "pattern", "value": "cross",
		"focus_x": 1450.0, "note": "床のタイルの模様が1か所だけ違う"},
	{"id": "clock_reverse", "tier": "normal", "target": "clock_0", "field": "dir", "value": -1,
		"focus_x": 700.0, "note": "時計の針が逆回り", "dynamic": true},
	{"id": "passerby_extra", "tier": "normal", "target": "passerby_extra", "field": "visible", "value": true,
		"focus_x": 2100.0, "note": "すれ違う影が2人いる", "dynamic": true,
		"sample_ts": [13.5, 14.5, 15.5]},
	{"id": "hero_shadow_missing", "tier": "normal", "target": "hero_shadow", "field": "visible", "value": false,
		"focus_x": 150.0, "note": "主人公の影が無い"},
	{"id": "light_extra_flicker", "tier": "normal", "target": "light_7", "field": "flicker_enabled", "value": true,
		"focus_x": 2175.0, "note": "いつもは揺れない蛍光灯がちらついている", "dynamic": true},
	{"id": "door_color", "tier": "normal", "target": "door_1", "field": "color_mode", "value": "scratched",
		"focus_x": 1260.0, "note": "扉の色がいつもと違う"},
	{"id": "arrow_extra", "tier": "normal", "target": "arrow_extra", "field": "visible", "value": true,
		"focus_x": 2350.0, "note": "案内の矢印が1つ多い"},
	{"id": "floor_band_tint", "tier": "normal", "target": "floor_0", "field": "tint", "value": "alt",
		"focus_x": 1450.0, "note": "床の色がいつもと違う"},
	{"id": "poster_frame_color", "tier": "normal", "target": "poster_cat", "field": "frame_color", "value": "alt",
		"focus_x": 1060.0, "note": "ポスターの縁の色が違う"},

	# --- むずかしい -------------------------------------------------------
	{"id": "poster_cat_direction", "tier": "hard", "target": "poster_cat", "field": "cat_dir", "value": -1,
		"focus_x": 1060.0, "note": "ポスターの猫の向きが逆"},
	{"id": "arrow_direction", "tier": "hard", "target": "arrow_1", "field": "dir", "value": "rev",
		"focus_x": 1700.0, "note": "案内の矢印が1つだけ違う向き"},
	{"id": "vent_drip_reverse", "tier": "hard", "target": "vent_0", "field": "drip_dir", "value": -1,
		"focus_x": 1710.0, "note": "通気口から水滴が上へ落ちる", "dynamic": true,
		"sample_ts": [2.5, 9.5, 16.5]},
	{"id": "wall_creep", "tier": "hard", "target": "backwall_0", "field": "creep_enabled", "value": true,
		"focus_x": 1450.0, "note": "奥の壁が少しずつ近づいてくる", "dynamic": true},
	{"id": "floor_tile_missing", "tier": "hard", "target": "tile_20", "field": "visible", "value": false,
		"focus_x": 2050.0, "note": "床のタイルが1枚欠けている"},
	{"id": "hero_shadow_side", "tier": "hard", "target": "hero_shadow", "field": "side", "value": "left",
		"focus_x": 150.0, "note": "主人公の影の向きが逆"},
	{"id": "clock_frozen", "tier": "hard", "target": "clock_0", "field": "frozen", "value": true,
		"focus_x": 700.0, "note": "時計の針が止まっている", "dynamic": true},
	{"id": "light_flicker_missing", "tier": "hard", "target": "light_4", "field": "flicker_enabled", "value": false,
		"focus_x": 1305.0, "note": "いつも揺れる蛍光灯が揺れていない", "dynamic": true},
]

static func by_id(id: String) -> Dictionary:
	for a in DATA:
		if String(a.id) == id:
			return a
	return {}

static func all_ids() -> Array:
	var out := []
	for a in DATA:
		out.append(String(a.id))
	return out

static func sample_ts(a: Dictionary) -> Array:
	if a.has("sample_ts"):
		return a.sample_ts
	return DEFAULT_SAMPLE_TS
