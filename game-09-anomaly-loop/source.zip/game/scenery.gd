extends RefCounted
## 景色は props と周回開始からの t だけで決まる。
class_name Scenery

const CORRIDOR_LEN := 2900.0
const BAND_H := 900.0
const CEIL_H := 110.0
const FLOOR_H := 140.0
const WALL_TOP := CEIL_H
const WALL_BOTTOM := BAND_H - FLOOR_H
const WALK_Y := WALL_BOTTOM - 6.0
const NUM_LIGHTS := 10
const LIGHT_SPACING := 290.0
const LIGHT_X0 := 145.0
const TILE_W := 100.0
const NUM_TILES := 29

const CORRIDOR := preload("res://art/corridor_base.png")
const DOOR := preload("res://art/fixtures_00.png")
const VENDING := preload("res://art/fixtures_02.png")
const VENDING_RED := preload("res://art/vending_red_from_blue.png")
const LIGHT := preload("res://art/fixtures_04.png")
const LIGHT_RED := preload("res://art/light_red_from_normal.png")
const LIGHT_OFF := preload("res://art/fixtures_06.png")
const VENT := preload("res://art/fixtures_07.png")
const MOUNTAIN := preload("res://art/posters_tiles_arrows_00.png")
const CAT := preload("res://art/posters_tiles_arrows_01.png")
const EVENT := preload("res://art/posters_tiles_arrows_04.png")
const TILE := preload("res://art/posters_tiles_arrows_06.png")
const TILE_DIAMOND := preload("res://art/tile_diamond_from_dot.png")
const TILE_HOLE := preload("res://art/posters_tiles_arrows_08.png")
const ARROW := preload("res://art/posters_tiles_arrows_09.png")
const HERO_STILL := preload("res://art/actors_ui_00.png")
const HERO_WALK_A := preload("res://art/actors_ui_01.png")
const HERO_WALK_B := preload("res://art/actors_ui_02.png")
const PASSERBY := preload("res://art/actors_ui_03.png")
const DROP := preload("res://art/actors_ui_04.png")
const SHADOW := preload("res://art/actors_ui_05.png")
const CLOCK := preload("res://art/round_ui_clock_00.png")

static func light_x(i: int) -> float:
	return LIGHT_X0 + float(i) * LIGHT_SPACING

static func tile_x(i: int) -> float:
	return float(i) * TILE_W + TILE_W * 0.5

static func base_props() -> Array:
	var props := []
	for i in NUM_LIGHTS:
		props.append({"id": "light_%d" % i, "kind": "light", "x": light_x(i),
			"tint": "normal", "lit": true, "flicker_enabled": (i == 4), "phase": float(i) * 0.83})
	props.append({"id": "door_0", "kind": "door", "x": 460.0, "visible": true, "color_mode": "normal"})
	props.append({"id": "door_1", "kind": "door", "x": 1260.0, "visible": true, "color_mode": "normal"})
	props.append({"id": "door_2", "kind": "door", "x": 1960.0, "visible": true, "color_mode": "normal"})
	props.append({"id": "door_3", "kind": "door", "x": 2660.0, "visible": true, "color_mode": "normal"})
	props.append({"id": "door_extra", "kind": "door", "x": 2470.0, "visible": false, "color_mode": "normal"})
	props.append({"id": "poster_mountain", "kind": "poster", "x": 260.0, "style": "mountain",
		"flipped": false, "palette": "default", "frame_color": "normal", "cat_dir": 1})
	props.append({"id": "poster_cat", "kind": "poster", "x": 1060.0, "style": "cat",
		"flipped": false, "palette": "default", "frame_color": "normal", "cat_dir": 1})
	props.append({"id": "poster_event", "kind": "poster", "x": 2260.0, "style": "event",
		"flipped": false, "palette": "default", "frame_color": "normal", "cat_dir": 1})
	props.append({"id": "vending_0", "kind": "vending", "x": 1560.0, "visible": true, "color_mode": "normal"})
	props.append({"id": "clock_0", "kind": "clock", "x": 700.0, "dir": 1, "frozen": false})
	props.append({"id": "vent_0", "kind": "vent", "x": 1710.0, "drip_dir": 1})
	props.append({"id": "arrow_0", "kind": "arrow", "x": 900.0, "visible": true, "dir": "fwd"})
	props.append({"id": "arrow_1", "kind": "arrow", "x": 1700.0, "visible": true, "dir": "fwd"})
	props.append({"id": "arrow_2", "kind": "arrow", "x": 2500.0, "visible": true, "dir": "fwd"})
	props.append({"id": "arrow_extra", "kind": "arrow", "x": 2350.0, "visible": false, "dir": "fwd"})
	for i in NUM_TILES:
		props.append({"id": "tile_%d" % i, "kind": "tile", "x": tile_x(i), "visible": true, "pattern": "dot"})
	props.append({"id": "floor_0", "kind": "floor", "tint": "normal"})
	props.append({"id": "passerby_0", "kind": "passerby", "x": 1150.0, "visible": true, "t0": 8.0, "t1": 11.0})
	props.append({"id": "passerby_extra", "kind": "passerby", "x": 2100.0, "visible": false, "t0": 13.0, "t1": 16.0})
	props.append({"id": "backwall_0", "kind": "backwall", "tint": "normal", "creep_enabled": false})
	props.append({"id": "hero_shadow", "kind": "hero_shadow", "visible": true, "side": "right"})
	return props

static func find(props: Array, id: String) -> Dictionary:
	for p in props:
		if String(p.id) == id:
			return p
	return {}

static func apply_override(props: Array, ov: Dictionary) -> Array:
	var out: Array = props.duplicate(true)
	if ov.is_empty():
		return out
	for p in out:
		if String(p.id) == String(ov.target):
			p[String(ov.field)] = ov.value
			break
	return out

## 画像の縦横比と各道具の従来の当たり範囲を保つ。
static func _sprite(w: CanvasItem, tex: Texture2D, rect: Rect2, color: Color = Color.WHITE,
		flip_h: bool = false, angle: float = 0.0) -> void:
	w.draw_set_transform(rect.get_center(), angle, Vector2(-1, 1) if flip_h else Vector2.ONE)
	w.draw_texture_rect(tex, Rect2(-rect.size / 2.0, rect.size), false, color)
	w.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

static func draw(w: CanvasItem, props: Array, t: float, hero_x: float, facing: int) -> void:
	_draw_base(w, props, t)
	_draw_floor(w, props)
	for p in props:
		match String(p.kind):
			"poster": _draw_poster(w, p)
			"door": _draw_door(w, p)
			"vending": _draw_vending(w, p)
			"clock": _draw_clock(w, p, t)
			"vent": _draw_vent(w, p, t)
			"arrow": _draw_arrow(w, p)
	for p in props:
		if String(p.kind) == "light":
			_draw_light(w, p, t)
	for p in props:
		if String(p.kind) == "passerby":
			_draw_passerby(w, p, t)
	_draw_hero(w, hero_x, facing, t, find(props, "hero_shadow"))

static func _draw_base(w: CanvasItem, props: Array, t: float) -> void:
	# 元画像は720x1280。縦900に合わせ、奇数枚を左右反転して同じ端同士を接続する。
	var span: float = BAND_H * float(CORRIDOR.get_width()) / float(CORRIDOR.get_height())
	for i in range(-5, 11):
		_sprite(w, CORRIDOR, Rect2(float(i) * span, 0, span + 0.5, BAND_H), Color.WHITE, posmod(i, 2) == 1)
	var wall := find(props, "backwall_0")
	if String(wall.get("tint", "normal")) != "normal":
		w.draw_rect(Rect2(-2500, WALL_TOP, 8000, WALL_BOTTOM - WALL_TOP), Color(0.36, 0.03, 0.01, 0.42))
	if bool(wall.get("creep_enabled", false)):
		var band_h: float = 18.0 + t * 5.0
		w.draw_rect(Rect2(-2500, WALL_TOP, 8000, band_h), Color(0.04, 0.05, 0.07, 0.7))
		w.draw_rect(Rect2(-2500, WALL_BOTTOM - band_h, 8000, band_h), Color(0.04, 0.05, 0.07, 0.7))
	var floor_p := find(props, "floor_0")
	if String(floor_p.get("tint", "normal")) != "normal":
		w.draw_rect(Rect2(-2500, WALL_BOTTOM, 8000, FLOOR_H), Color(0.25, 0.03, 0.3, 0.36))

static func _draw_floor(w: CanvasItem, props: Array) -> void:
	for p in props:
		if String(p.kind) != "tile":
			continue
		var tex: Texture2D = TILE_HOLE if not bool(p.get("visible", true)) else (TILE_DIAMOND if String(p.get("pattern", "dot")) != "dot" else TILE)
		_sprite(w, tex, Rect2(float(p.x) - 47.0, WALL_BOTTOM + 4.0, 94.0, FLOOR_H - 8.0))

static func _draw_poster(w: CanvasItem, p: Dictionary) -> void:
	var style: String = String(p.get("style", "mountain"))
	var tex: Texture2D = MOUNTAIN if style == "mountain" else (CAT if style == "cat" else EVENT)
	var rect := Rect2(float(p.x) - 75.0, WALL_TOP + 40.0, 150.0, 190.0)
	var tint := Color.WHITE
	if String(p.get("palette", "default")) != "default":
		tint = Color(0.56, 1.38, 1.12)
	_sprite(w, tex, rect, tint, style == "cat" and int(p.get("cat_dir", 1)) < 0,
		PI if bool(p.get("flipped", false)) else 0.0)
	if style == "cat" and String(p.get("frame_color", "normal")) != "normal":
		w.draw_rect(rect.grow(-2.0), Color(0.9, 0.19, 0.22, 0.95), false, 6.0)

static func _draw_door(w: CanvasItem, p: Dictionary) -> void:
	if not bool(p.get("visible", true)):
		return
	var tint := Color.WHITE if String(p.get("color_mode", "normal")) == "normal" else Color(1.28, 1.12, 0.62)
	_sprite(w, DOOR, Rect2(float(p.x) - 50.0, WALL_BOTTOM - 260.0, 100.0, 260.0), tint)

static func _draw_vending(w: CanvasItem, p: Dictionary) -> void:
	if not bool(p.get("visible", true)):
		return
	var tex: Texture2D = VENDING if String(p.get("color_mode", "normal")) == "normal" else VENDING_RED
	_sprite(w, tex, Rect2(float(p.x) - 70.0, WALL_BOTTOM - 220.0, 140.0, 220.0))

static func _draw_clock(w: CanvasItem, p: Dictionary, t: float) -> void:
	var c := Vector2(float(p.x), WALL_TOP + 70.0)
	var r := 52.0
	_sprite(w, CLOCK, Rect2(c - Vector2(r, r), Vector2(r * 2.0, r * 2.0)))
	var dir: int = int(p.get("dir", 1))
	var frozen: bool = bool(p.get("frozen", false))
	var angle: float = PI if frozen else (t * 0.5 * float(dir))
	var hand := c + Vector2(cos(angle - PI / 2.0), sin(angle - PI / 2.0)) * (r * 0.8)
	w.draw_line(c, hand, Color(0.08, 0.08, 0.08), 8.0)
	var hand2 := c + Vector2(cos(angle * 0.3 - PI / 2.0), sin(angle * 0.3 - PI / 2.0)) * (r * 0.5)
	w.draw_line(c, hand2, Color(0.08, 0.08, 0.08), 10.0)
	var sec_angle: float = 5.0 if frozen else (t * 4.3 * float(dir))
	var hand3 := c + Vector2(cos(sec_angle - PI / 2.0), sin(sec_angle - PI / 2.0)) * (r * 0.95)
	w.draw_line(c, hand3, Color(0.75, 0.15, 0.12), 6.0)

static func _draw_vent(w: CanvasItem, p: Dictionary, t: float) -> void:
	var x: float = p.x
	var top := WALL_TOP + 20.0
	_sprite(w, VENT, Rect2(x - 35.0, top, 70.0, 54.0))
	var dir: int = int(p.get("drip_dir", 1))
	var ph := fmod(t, 2.4) / 2.4
	var y0: float = top + 54.0
	var y1: float = WALL_BOTTOM - 20.0
	var y: float = lerp(y0, y1, ph) if dir >= 0 else lerp(y1, y0, ph)
	_sprite(w, DROP, Rect2(x - 28.0, y - 26.0, 56.0, 52.0), Color.WHITE, false, PI if dir < 0 else 0.0)

static func _draw_arrow(w: CanvasItem, p: Dictionary) -> void:
	if not bool(p.get("visible", true)):
		return
	var forward: bool = String(p.get("dir", "fwd")) == "fwd"
	var x: float = float(p.x) + (40.0 if forward else -40.0)
	_sprite(w, ARROW, Rect2(x - 55.0, WALL_BOTTOM + 9.0, 110.0, 70.0), Color.WHITE, not forward)

static func _draw_light(w: CanvasItem, p: Dictionary, t: float) -> void:
	var x: float = p.x
	var y := WALL_TOP - 30.0
	var lit: bool = bool(p.get("lit", true))
	var red: bool = String(p.get("tint", "normal")) == "red"
	var bright := 1.0
	if lit and bool(p.get("flicker_enabled", false)):
		var phase: float = float(p.get("phase", 0.0))
		bright = 0.76 + 0.14 * pow(sin((t * 2.7) + phase), 2.0)
	var tint := Color(bright, bright, bright)
	var tex: Texture2D = (LIGHT_RED if red else LIGHT) if lit else LIGHT_OFF
	_sprite(w, tex, Rect2(x - 55.0, y - 17.0, 110.0, 34.0), tint if lit else Color.WHITE)
	if lit:
		var glow := Color(1.0, 0.22 if red else 0.9, 0.15 if red else 0.65, 0.08 * bright)
		w.draw_rect(Rect2(x - 55.0, y + 12.0, 110.0, 30.0), glow)

static func _draw_passerby(w: CanvasItem, p: Dictionary, t: float) -> void:
	if not bool(p.get("visible", true)):
		return
	var t0: float = float(p.get("t0", 8.0))
	var t1: float = float(p.get("t1", 11.0))
	if t < t0 or t > t1:
		return
	var ph: float = (t - t0) / maxf(0.001, t1 - t0)
	# 壁から降りてくる演出ではなく、主人公と同じ床面を横切る。
	var x: float = float(p.x) + lerp(-105.0, 105.0, ph)
	var y: float = WALK_Y - 64.0
	var a: float = 1.0 - absf(ph - 0.5) * 0.4
	_sprite(w, PASSERBY, Rect2(x - 28.0, y, 56.0, 104.0), Color(1, 1, 1, a))

static func _draw_hero(w: CanvasItem, x: float, facing: int, t: float, shadow: Dictionary) -> void:
	var y := WALK_Y
	var show_shadow: bool = bool(shadow.get("visible", true)) if not shadow.is_empty() else true
	if show_shadow:
		var side: String = String(shadow.get("side", "right")) if not shadow.is_empty() else "right"
		var off: float = 36.0 if side == "right" else -36.0
		_sprite(w, SHADOW, Rect2(x + off - 40.0, y + 30.0, 80.0, 30.0), Color(1, 1, 1, 0.65))
	var frame: Texture2D = HERO_STILL
	if t > 0.0:
		frame = HERO_WALK_A if int(floor(t * 6.0)) % 2 == 0 else HERO_WALK_B
	var bob := sin(t * 6.0) * 4.0
	_sprite(w, frame, Rect2(x - 25.0, y - 53.0 + bob, 50.0, 98.0), Color.WHITE, facing < 0)
