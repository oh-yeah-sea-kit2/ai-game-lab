extends Node2D
## ミカエリ通路 — 本体。景色データ(Scenery)と異変カタログ(Anomalies)は別ファイルにあり、
## ここでは「周(lap)の進行」「入力」「自動プレイ(oracle/random)」「検証用の景色固定表示」だけを扱う。

const ErrorCounter := preload("res://error_counter.gd")
const GAME_FONT := preload("res://fonts/MPLUSRounded1c-Bold-subset.ttf")
const BACKDROP := preload("res://art/screen_backdrop.png")
const BUTTON_ART := preload("res://art/actors_ui_06.png")
const PANEL_ART := preload("res://art/actors_ui_07.png")
const LAMP_OFF := preload("res://art/round_ui_clock_01.png")
const LAMP_ON := preload("res://art/round_ui_clock_02.png")

const BASE := Vector2(720, 1280)
const BEST_PATH := "user://best.json"
const NOTEBOOK_PATH := "user://notebook.json"
const BUTTON_COLOR := Color("e08a3c")

const LIGHTS_TOTAL := 7
const WALK_SPEED := Scenery.CORRIDOR_LEN / 20.0  # 1周(片道)が約20秒
const FIXED_DT := 1.0 / 60.0
const CLOSING_SECONDS := 480.0  # 8分で「閉館」
const TURN_ANOMALY_FRACTION := 0.25  # oracleが異変ラップで引き返し始める位置（通路の割合）
const HUMAN_CHECKPOINTS := [320.0, 650.0, 900.0, 1200.0, 1450.0, 1750.0, 2000.0, 2300.0, 2600.0]

enum State { TITLE, PLAY, NOTE, RESULT }

var state := State.TITLE
var logger: ErrorCounter
var rng := RandomNumberGenerator.new()

# ---- CLI / URL ----
var autoplay := false
var bot := "oracle"
var loops_target := 200
var one_run := false
var seed_val := 1
var timescale := 1.0
var debug_scene_mode := false
var debug_scene_arg := ""
var debug_like_arg := ""
var debug_at := 0.0
var debug_focus_x := 0.0
var debug_hero_x := 0.0
var debug_props: Array = []
var dump_anomalies := false
var demo_mode := false
var demo_timer := 0.0
var human_scan_timer := 0.0
var human_checkpoint := 0
var human_target_seen := false
var human_turn_ready := false
var human_miss_this_lap := false
var human_misses := 0

# ---- ノード ----
var world: Node2D
var hud: Node2D
var ui_layer: CanvasLayer
var title_panel: Control
var title_best: Label
var note_panel: Control
var note_return_state := State.TITLE
var note_list_box: VBoxContainer
var result_panel: Control
var result_text: Label
var result_extra: Label
var start_btn_ref: Button
var note_btn_ref: Button
var close_btn_ref: Button
var retry_btn_ref: Button
var result_note_btn_ref: Button

# ---- 周(lap)の状態 ----
var lap_index := 0
var lap_time := 0.0
var hero_x := 0.0
var max_x_reached := 0.0
var facing := 1
var pointer_holding := false
var keyboard_holding := false
var holding := false
var lap_anomaly_active := false
var lap_anomaly_id := ""
var current_props: Array = []
var bag: Array = []

# ---- 進行・統計 ----
var lights_lit := 0
var flash_timer := 0.0  # 正解: 灯りがともる小さな光の演出
var dark_timer := 0.0   # 不正解: 画面が一瞬暗転する演出
var streak := 0
var max_streak := 0
var stat_correct := 0
var stat_wrong := 0
var loops_done := 0
var cleared_ever := false
var cleared_this_run := false
var session_time := 0.0
var encountered_ids := {}       # 自動プレイの検証用（袋から出た異変を全部記録）
var session_found_ids := {}     # このセッションで「正しく気づけた」異変
var notebook := {}              # user:// に保存する全期間の「見つけた異変」
var best := {"max_streak": 0, "cleared": false}
var new_record := false

# ---- 自動プレイ（random bot）----
var random_action := "forward"
var random_turn_x := 0.0

func _ready() -> void:
	logger = ErrorCounter.new()
	OS.add_logger(logger)
	_parse_args()
	rng.seed = seed_val
	if dump_anomalies:
		_dump_anomalies_json()
		return
	if debug_scene_arg != "":
		_enter_debug_scene(debug_scene_arg, debug_at, debug_like_arg)
		return
	_load_best()
	_load_notebook()
	_build_world()
	_build_hud()
	_build_ui()
	get_viewport().size_changed.connect(_layout)
	_layout()
	if autoplay:
		_start_autoplay_session()
	else:
		_show_title()
	if demo_mode:
		demo_timer = 2.5

func _parse_args() -> void:
	var params := {}
	var args := OS.get_cmdline_user_args()
	args.append_array(OS.get_cmdline_args())
	for a in args:
		if a == "--autoplay":
			autoplay = true
		elif a.begins_with("--loops="):
			loops_target = int(a.get_slice("=", 1))
		elif a.begins_with("--bot="):
			bot = a.get_slice("=", 1)
		elif a == "--one-run":
			one_run = true
		elif a.begins_with("--seed="):
			seed_val = int(a.get_slice("=", 1))
		elif a.begins_with("--timescale="):
			timescale = float(a.get_slice("=", 1))
		elif a.begins_with("--anomaly-scene="):
			params["scene"] = a.get_slice("=", 1)
		elif a.begins_with("--at="):
			params["at"] = a.get_slice("=", 1)
		elif a.begins_with("--like="):
			params["like"] = a.get_slice("=", 1)
		elif a == "--inject-error":
			push_error.call_deferred("inject-error: 検証用のわざとのエラー")
		elif a == "--dump-anomalies":
			dump_anomalies = true
	var web_query := _read_web_query()
	for k in web_query:
		params[k] = web_query[k]
	demo_mode = OS.has_feature("web") and String(web_query.get("demo", "")) == "1"
	if params.has("scene"):
		debug_scene_arg = String(params.get("scene", ""))
		debug_at = float(String(params.get("at", "0")))
		debug_like_arg = String(params.get("like", ""))
	# Web の URL クエリからも timescale を受け付ける（既定 1.0 なので実際の遊びには影響しない。
	# tools/web_check.py が「タイトル→結果」まで待たずに検証できるようにするための debug 用）。
	if params.has("timescale"):
		timescale = float(String(params.get("timescale", "1")))

func _read_web_query() -> Dictionary:
	var out := {}
	if not OS.has_feature("web"):
		return out
	var qs: Variant = JavaScriptBridge.eval("window.location.search", true)
	if typeof(qs) != TYPE_STRING or String(qs) == "":
		return out
	var s := String(qs)
	if s.begins_with("?"):
		s = s.substr(1)
	for part in s.split("&"):
		if part == "":
			continue
		var kv := part.split("=", true, 1)
		var k: String = kv[0]
		var v: String = kv[1] if kv.size() > 1 else ""
		out[k] = v.uri_decode()
	return out

# ---------------------------------------------------------------- 検証用: 異変カタログの出力

## Python 側（capture_scenes.py）が Anomalies.DATA を GDScript から直接もらうための出口。
## 正本は anomalies.gd の1箇所だけにし、検証ツールが独自にカタログを複製しないようにする。
func _dump_anomalies_json() -> void:
	var out := []
	for a in Anomalies.DATA:
		out.append({
			"id": String(a.id),
			"tier": String(a.tier),
			"focus_x": float(a.focus_x),
			"dynamic": bool(a.get("dynamic", false)),
			"sample_ts": Anomalies.sample_ts(a),
		})
	print(JSON.stringify(out))
	get_tree().quit(0)

# ---------------------------------------------------------------- 検証用: 景色の固定表示

func _enter_debug_scene(id: String, at: float, like: String) -> void:
	debug_scene_mode = true
	var focus_x := 0.0
	var props: Array
	if id == "none" or id == "none2":
		if like != "":
			var a := Anomalies.by_id(like)
			if not a.is_empty():
				focus_x = float(a.focus_x)
		props = Scenery.base_props()
	else:
		var a2 := Anomalies.by_id(id)
		if a2.is_empty():
			push_error("unknown --anomaly-scene id: %s" % id)
			props = Scenery.base_props()
		else:
			focus_x = float(a2.focus_x)
			props = Scenery.apply_override(Scenery.base_props(), a2)
	debug_focus_x = focus_x
	# 主人公をちょうど異変の真上に立たせると、通気口など足元の異変が体で隠れてしまうことがあるため、
	# カメラの中心(focus_x)は異変の位置に合わせつつ、主人公自身は少し手前に離して立たせる。
	debug_hero_x = focus_x - 70.0
	debug_props = props
	debug_at = at
	_build_world()
	get_viewport().size_changed.connect(_layout)
	_layout()
	world.queue_redraw()
	call_deferred("_publish_debug_ready")

func _publish_debug_ready() -> void:
	if not OS.has_feature("web"):
		return
	var st := {"ready": true, "scene": debug_scene_arg, "at": debug_at, "errors": logger.get_errors()}
	JavaScriptBridge.eval("window.__anomaly_scene = %s;" % JSON.stringify(st), true)

# ---------------------------------------------------------------- 保存データ

func _load_best() -> void:
	if not FileAccess.file_exists(BEST_PATH):
		return
	var f := FileAccess.open(BEST_PATH, FileAccess.READ)
	if f == null:
		return
	var d: Variant = JSON.parse_string(f.get_as_text())
	if typeof(d) == TYPE_DICTIONARY:
		best["max_streak"] = int(d.get("max_streak", 0))
		best["cleared"] = bool(d.get("cleared", false))

func _save_best() -> void:
	var f := FileAccess.open(BEST_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("best.json を書けなかった: %s" % FileAccess.get_open_error())
		return
	f.store_string(JSON.stringify(best))

func _load_notebook() -> void:
	if not FileAccess.file_exists(NOTEBOOK_PATH):
		return
	var f := FileAccess.open(NOTEBOOK_PATH, FileAccess.READ)
	if f == null:
		return
	var d: Variant = JSON.parse_string(f.get_as_text())
	if typeof(d) == TYPE_DICTIONARY:
		notebook = d

func _save_notebook() -> void:
	var f := FileAccess.open(NOTEBOOK_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("notebook.json を書けなかった: %s" % FileAccess.get_open_error())
		return
	f.store_string(JSON.stringify(notebook))

# ---------------------------------------------------------------- 組み立て

func _build_world() -> void:
	world = Node2D.new()
	world.name = "World"
	add_child(world)
	world.draw.connect(_draw_world)

func _build_hud() -> void:
	hud = Node2D.new()
	hud.name = "Hud"
	add_child(hud)
	hud.draw.connect(_draw_hud)

func _label(size: int, col: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_override("font", GAME_FONT)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0.05, 0.05, 0.06))
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(320, 84)
	b.add_theme_font_override("font", GAME_FONT)
	b.add_theme_font_size_override("font_size", 28)
	var sb := StyleBoxTexture.new()
	sb.texture = BUTTON_ART
	sb.texture_margin_left = 58
	sb.texture_margin_right = 58
	sb.texture_margin_top = 50
	sb.texture_margin_bottom = 50
	b.add_theme_stylebox_override("normal", sb)
	var sb2 := sb.duplicate() as StyleBoxTexture
	sb2.modulate_color = Color(1.0, 0.9, 0.75)
	b.add_theme_stylebox_override("hover", sb2)
	b.add_theme_stylebox_override("pressed", sb2)
	b.add_theme_color_override("font_color", Color(0.14, 0.08, 0.05))
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	return b

func _overlay() -> Control:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.025, 0.035, 0.36)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)
	var card := PanelContainer.new()
	var sb := StyleBoxTexture.new()
	sb.texture = PANEL_ART
	sb.texture_margin_left = 34
	sb.texture_margin_right = 34
	sb.texture_margin_top = 34
	sb.texture_margin_bottom = 34
	sb.set_content_margin_all(30)
	card.add_theme_stylebox_override("panel", sb)
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.custom_minimum_size = Vector2(600, 0)
	center.add_child(card)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 18)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(box)
	root.set_meta("box", box)
	ui_layer.add_child(root)
	return root

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	ui_layer.layer = 10
	add_child(ui_layer)

	title_panel = _overlay()
	var tb := title_panel.get_meta("box") as VBoxContainer
	var t1 := _label(46, Color("ffd27a"))
	t1.text = "ミカエリ通路"
	t1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tb.add_child(t1)
	var t2 := _label(26, Color.WHITE)
	t2.text = "いつもの通路を歩く。\n何も変わっていなければ進む。\nおかしな所があれば引き返す。"
	t2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t2.autowrap_mode = TextServer.AUTOWRAP_WORD
	tb.add_child(t2)
	var t3 := _label(26, Color(0.9, 0.93, 1.0))
	t3.text = "画面を押しつづける → あるく\n「ふりかえる」→ むきを反転\nPC: ←→ でも歩ける"
	t3.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tb.add_child(t3)
	title_best = _label(26, Color("ffd27a"))
	title_best.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tb.add_child(title_best)
	start_btn_ref = _button("はじめる")
	start_btn_ref.pressed.connect(_start_game)
	var start_wrap := CenterContainer.new()
	start_wrap.add_child(start_btn_ref)
	tb.add_child(start_wrap)
	note_btn_ref = _button("異変ノート")
	note_btn_ref.pressed.connect(_open_note)
	var note_wrap := CenterContainer.new()
	note_wrap.add_child(note_btn_ref)
	tb.add_child(note_wrap)
	title_panel.visible = false

	note_panel = _overlay()
	var nb := note_panel.get_meta("box") as VBoxContainer
	var nt := _label(30, Color("ffd27a"))
	nt.text = "異変ノート"
	nt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	nb.add_child(nt)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(520, 560)
	scroll.mouse_filter = Control.MOUSE_FILTER_PASS
	note_list_box = VBoxContainer.new()
	note_list_box.add_theme_constant_override("separation", 6)
	note_list_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	scroll.add_child(note_list_box)
	nb.add_child(scroll)
	close_btn_ref = _button("とじる")
	close_btn_ref.pressed.connect(_close_note)
	var close_wrap := CenterContainer.new()
	close_wrap.add_child(close_btn_ref)
	nb.add_child(close_wrap)
	note_panel.visible = false

	result_panel = _overlay()
	var rb := result_panel.get_meta("box") as VBoxContainer
	result_text = _label(28, Color("ffd27a"))
	result_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rb.add_child(result_text)
	result_extra = _label(26, Color(0.9, 0.94, 1.0))
	result_extra.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rb.add_child(result_extra)
	retry_btn_ref = _button("もういちど")
	retry_btn_ref.pressed.connect(_start_game)
	var retry_wrap := CenterContainer.new()
	retry_wrap.add_child(retry_btn_ref)
	rb.add_child(retry_wrap)
	result_note_btn_ref = _button("異変ノート")
	result_note_btn_ref.pressed.connect(_open_note)
	var result_note_wrap := CenterContainer.new()
	result_note_wrap.add_child(result_note_btn_ref)
	rb.add_child(result_note_wrap)
	result_panel.visible = false

func _refresh_note_list() -> void:
	for c in note_list_box.get_children():
		c.queue_free()
	for a in Anomalies.DATA:
		var id := String(a.id)
		var found: bool = bool(notebook.get(id, false))
		var tier_ja := String({"easy": "やさしい", "normal": "ふつう", "hard": "むずかしい"}.get(String(a.tier), "?"))
		var row := _label(26, Color.WHITE if found else Color(0.7, 0.72, 0.78))
		row.text = "[%s] %s" % [tier_ja, (String(a.note) if found else "？")]
		note_list_box.add_child(row)

# ---------------------------------------------------------------- 画面配置

func _layout() -> void:
	if world == null:
		return
	_position_world()
	queue_redraw()
	if hud:
		hud.queue_redraw()

func _position_world() -> void:
	var vp := get_viewport().get_visible_rect().size
	var scale_factor: float = clampf((vp.y - 230.0) / Scenery.BAND_H, 1.0, 1.5)
	# 縦長画面では余白を減らし、人物や小道具を見つけやすくする。
	# 横長画面は従来の倍率を保ち、通路の見え方を変えない。
	if vp.y > vp.x:
		scale_factor = minf(scale_factor * 1.18, vp.y / Scenery.BAND_H)
	world.scale = Vector2.ONE * scale_factor
	var cam_x: float = debug_focus_x if debug_scene_mode else hero_x
	world.position.x = vp.x * 0.32 - cam_x * scale_factor
	world.position.y = floor((vp.y - Scenery.BAND_H * scale_factor) / 2.0)
	world.queue_redraw()

func _draw() -> void:
	# stretch expand の余剰部分を含む実可視領域を、Canvas の逆変換で取得する。
	var screen := get_viewport().get_visible_rect()
	var inverse := get_global_transform_with_canvas().affine_inverse()
	var p0 := inverse * screen.position
	var p1 := inverse * screen.end
	var visible := Rect2(p0, p1 - p0).abs()
	var tex_size := BACKDROP.get_size()
	var factor: float = maxf(visible.size.x / tex_size.x, visible.size.y / tex_size.y)
	var size := tex_size * factor
	draw_texture_rect(BACKDROP, Rect2(visible.get_center() - size / 2.0, size), false)

# ---------------------------------------------------------------- 状態遷移

func _show_title() -> void:
	state = State.TITLE
	title_best.text = "自己ベスト　連続正解 %d" % int(best.get("max_streak", 0))
	title_panel.visible = true
	note_panel.visible = false
	result_panel.visible = false
	_refresh_web_state()

func _open_note() -> void:
	note_return_state = state
	_refresh_note_list()
	state = State.NOTE
	title_panel.visible = false
	result_panel.visible = false
	note_panel.visible = true
	_refresh_web_state()

func _close_note() -> void:
	if note_return_state == State.RESULT:
		state = State.RESULT
		note_panel.visible = false
		result_panel.visible = true
		_refresh_web_state()
	else:
		_show_title()

func _start_game() -> void:
	state = State.PLAY
	title_panel.visible = false
	note_panel.visible = false
	result_panel.visible = false
	lights_lit = 0
	streak = 0
	max_streak = 0
	loops_done = 0
	cleared_this_run = false
	new_record = false
	session_time = 0.0
	session_found_ids = {}
	lap_index = 0
	_start_lap()
	if demo_mode:
		demo_timer = 0.0
		human_misses = 0
	_refresh_web_state()

func _start_autoplay_session() -> void:
	state = State.PLAY
	lights_lit = 0
	streak = 0
	stat_correct = 0
	stat_wrong = 0
	max_streak = 0
	cleared_ever = false
	loops_done = 0
	lap_index = 0
	encountered_ids = {}
	session_time = 0.0
	_start_lap()

func _start_lap() -> void:
	lap_time = 0.0
	human_scan_timer = 0.0
	human_checkpoint = 0
	human_target_seen = false
	human_turn_ready = false
	hero_x = 0.0
	max_x_reached = 0.0
	facing = 1
	# pointer_holding / keyboard_holding はここでリセットしない。
	# 指を離さずに押しっぱなしのまま次の周へ入ってきた場合、そのまま歩き続けられるようにするため
	# （ここで false に戻すと、指を離して押し直すまでキャラが止まって見えるバグになる）。
	holding = pointer_holding or keyboard_holding
	lap_index += 1
	if lap_index == 1:
		lap_anomaly_active = false
		lap_anomaly_id = ""
	else:
		lap_anomaly_active = rng.randf() < 0.5
		if lap_anomaly_active:
			if bag.is_empty():
				_refill_bag()
			lap_anomaly_id = bag.pop_back()
		else:
			lap_anomaly_id = ""
	if lap_anomaly_active:
		current_props = Scenery.apply_override(Scenery.base_props(), Anomalies.by_id(lap_anomaly_id))
	else:
		current_props = Scenery.base_props()
	var human_play: bool = demo_mode or (autoplay and bot == "human")
	human_miss_this_lap = false
	if human_play and lap_anomaly_active and human_misses == 0 and streak >= 3:
		var tier: String = String(Anomalies.by_id(lap_anomaly_id).get("tier", "easy"))
		if tier == "normal" or tier == "hard":
			human_miss_this_lap = true
			human_misses += 1
	if autoplay and bot == "random":
		random_action = "back" if rng.randf() < 0.5 else "forward"
		random_turn_x = rng.randf_range(0.15, 0.85) * Scenery.CORRIDOR_LEN
	_refresh_web_state()

func _refill_bag() -> void:
	bag = Anomalies.all_ids()
	var i := bag.size() - 1
	while i > 0:
		var j: int = rng.randi_range(0, i)
		var tmp = bag[i]
		bag[i] = bag[j]
		bag[j] = tmp
		i -= 1

func _resolve_lap(went_forward: bool) -> void:
	var correct: bool = went_forward != lap_anomaly_active
	loops_done += 1
	if lap_anomaly_active:
		encountered_ids[lap_anomaly_id] = true
	if correct:
		stat_correct += 1
		streak += 1
		max_streak = maxi(max_streak, streak)
		lights_lit += 1
		if not autoplay:
			flash_timer = 0.35
		if lap_anomaly_active and not autoplay:
			session_found_ids[lap_anomaly_id] = true
			notebook[lap_anomaly_id] = true
			_save_notebook()
		if lights_lit >= LIGHTS_TOTAL:
			cleared_ever = true
			if autoplay:
				if one_run:
					_finish_autoplay()
					return
				lights_lit = 0
			else:
				cleared_this_run = true
				_finish_run_real(true)
				return
	else:
		stat_wrong += 1
		streak = 0
		lights_lit = 0
		if not autoplay:
			dark_timer = 0.6
	if autoplay:
		if loops_done >= loops_target:
			_finish_autoplay()
			return
		_start_lap()
	else:
		_start_lap()

func _finish_run_real(cleared: bool) -> void:
	state = State.RESULT
	if max_streak > int(best.get("max_streak", 0)):
		best["max_streak"] = max_streak
		new_record = true
	if cleared:
		best["cleared"] = true
	_save_best()
	_show_result(cleared)

func _show_result(cleared: bool) -> void:
	title_panel.visible = false
	note_panel.visible = false
	result_panel.visible = true
	if cleared:
		result_text.text = "クリア！ 出口に出られた"
	else:
		result_text.text = "閉館時間になった"
	var mm := int(session_time) / 60
	var ss := int(session_time) % 60
	var extra := "最長連続正解 %d　見つけた異変 %d種\nかかった時間 %d:%02d" % [
		max_streak, session_found_ids.size(), mm, ss]
	extra += "\n自己ベスト 連続正解 %d%s" % [int(best.get("max_streak", 0)), "（新記録！）" if new_record else ""]
	result_extra.text = extra
	if demo_mode:
		demo_timer = 5.0
	_refresh_web_state()

func _finish_autoplay() -> void:
	state = State.RESULT
	var out := {
		"bot": bot, "loops": loops_done, "correct": stat_correct, "wrong": stat_wrong,
		"max_streak": max_streak, "anomaly_kinds_seen": encountered_ids.size(),
		"anomaly_kinds_total": Anomalies.DATA.size(), "cleared": cleared_ever,
		"errors": logger.get_errors(), "seconds": snappedf(session_time, 0.001),
		"human_misses": human_misses,
	}
	print(JSON.stringify(out))
	get_tree().quit(0 if logger.get_errors() == 0 else 1)

# ---------------------------------------------------------------- 入力（ポインターだけで完結。PCの矢印キーは任意の追加）

func _turn_button_rect() -> Rect2:
	var vp := get_viewport_rect().size
	var w := 220.0
	var h := 84.0
	return Rect2(vp.x / 2.0 - w / 2.0, vp.y - 108.0, w, h)

func _input(event: InputEvent) -> void:
	if autoplay or demo_mode or debug_scene_mode:
		return
	if state != State.PLAY:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_handle_press(event.position, event.pressed)
	# emulate_mouse_from_touch=true。タッチ由来の疑似マウスだけを処理して二重発火を防ぐ。

func _handle_press(pos: Vector2, pressed: bool) -> void:
	if pressed:
		if _turn_button_rect().has_point(pos):
			facing = -facing
		else:
			pointer_holding = true
	else:
		pointer_holding = false
	holding = pointer_holding or keyboard_holding

func _poll_keyboard() -> void:
	keyboard_holding = false
	if Input.is_key_pressed(KEY_RIGHT):
		facing = 1
		keyboard_holding = true
	elif Input.is_key_pressed(KEY_LEFT):
		facing = -1
		keyboard_holding = true
	holding = pointer_holding or keyboard_holding

# ---------------------------------------------------------------- 自動プレイ

func _autoplay_decide() -> void:
	holding = true
	if bot == "oracle":
		if lap_anomaly_active and facing == 1 and hero_x >= Scenery.CORRIDOR_LEN * TURN_ANOMALY_FRACTION:
			facing = -1
	elif bot == "random":
		if random_action == "back" and facing == 1 and hero_x >= random_turn_x:
			facing = -1

func _human_decide(dt: float) -> void:
	# 一定間隔の目印を確認し、異変の位置で通常データと現物を比べて引き返す。
	# 同じ判断を Web デモと headless の human bot で使う。
	if human_scan_timer > 0.0:
		human_scan_timer -= dt
		holding = false
		return
	if human_turn_ready:
		facing = -1
		human_turn_ready = false
	if facing == 1:
		if lap_anomaly_active and not human_target_seen:
			var a := Anomalies.by_id(lap_anomaly_id)
			var focus: float = float(a.focus_x)
			if hero_x >= focus + 90.0:
				human_target_seen = true
				human_scan_timer = 1.5 if String(a.tier) == "hard" else 1.0
				var normal_prop := Scenery.find(Scenery.base_props(), String(a.target))
				var seen_prop := Scenery.find(current_props, String(a.target))
				human_turn_ready = not human_miss_this_lap and not normal_prop.is_empty() \
					and seen_prop.get(String(a.field)) != normal_prop.get(String(a.field))
				holding = false
				return
		if human_checkpoint < HUMAN_CHECKPOINTS.size() and hero_x >= HUMAN_CHECKPOINTS[human_checkpoint]:
			human_scan_timer = 0.65 + float(human_checkpoint) * 0.10
			human_checkpoint += 1
			holding = false
			return
	holding = true

# ---------------------------------------------------------------- フレーム更新

func _process(delta: float) -> void:
	if demo_mode and demo_timer > 0.0:
		demo_timer -= delta
		if demo_timer <= 0.0:
			if state == State.TITLE or state == State.RESULT:
				_start_game()
	flash_timer = maxf(0.0, flash_timer - delta)
	dark_timer = maxf(0.0, dark_timer - delta)
	if hud:
		hud.queue_redraw()
	if world and not debug_scene_mode:
		_position_world()
	_refresh_web_state()

func _physics_process(_delta: float) -> void:
	if debug_scene_mode or state != State.PLAY:
		return
	if not autoplay and not demo_mode:
		_poll_keyboard()
	var n := maxi(1, int(timescale))
	for _i in range(n):
		_tick(FIXED_DT)
		if state != State.PLAY:
			break

func _tick(dt: float) -> void:
	lap_time += dt
	session_time += dt
	if autoplay or demo_mode:
		if demo_mode or bot == "human":
			_human_decide(dt)
		else:
			_autoplay_decide()
	if holding:
		hero_x += float(facing) * WALK_SPEED * dt
	max_x_reached = maxf(max_x_reached, hero_x)
	_check_lap_end()
	if state == State.PLAY and not autoplay and session_time >= CLOSING_SECONDS:
		_finish_run_real(false)
	elif state == State.PLAY and autoplay and one_run and session_time >= CLOSING_SECONDS:
		_finish_autoplay()

func _check_lap_end() -> void:
	if hero_x >= Scenery.CORRIDOR_LEN:
		_resolve_lap(true)
	elif hero_x <= 0.0 and max_x_reached > 20.0:
		_resolve_lap(false)

# ---------------------------------------------------------------- 描画

func _draw_world() -> void:
	if debug_scene_mode:
		Scenery.draw(world, debug_props, debug_at, debug_hero_x, 1)
		return
	if state == State.PLAY or state == State.RESULT:
		Scenery.draw(world, current_props, lap_time, hero_x, facing)

func _draw_hud() -> void:
	if state != State.PLAY:
		return
	var vp := get_viewport_rect().size
	hud.draw_rect(Rect2(0, 0, vp.x, 86), Color(0.02, 0.03, 0.05, 0.7))
	hud.draw_rect(Rect2(0, vp.y - 140, vp.x, 140), Color(0.02, 0.03, 0.05, 0.72))
	var n := LIGHTS_TOTAL
	var total_w := 340.0
	var r := 15.0
	var start_x := vp.x / 2.0 - total_w / 2.0
	var y := 50.0
	for i in n:
		var cx: float = start_x + total_w * (float(i) + 0.5) / float(n)
		var lit: bool = i < lights_lit
		var grow := 0.0
		if lit and i == lights_lit - 1 and flash_timer > 0.0:
			grow = 8.0 * sin(PI * (1.0 - flash_timer / 0.35))
		hud.draw_texture_rect(LAMP_ON if lit else LAMP_OFF,
			Rect2(cx - r - 4.0 - grow, y - r - 4.0 - grow,
				(r + 4.0 + grow) * 2.0, (r + 4.0 + grow) * 2.0), false)
	var btn := _turn_button_rect()
	hud.draw_texture_rect(BUTTON_ART, btn, false)
	hud.draw_string(GAME_FONT, btn.position + Vector2(18, btn.size.y * 0.63), "ふりかえる",
		HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color(0.14, 0.08, 0.05))
	hud.draw_string(GAME_FONT, Vector2(vp.x / 2.0 - 190, vp.y - 118), "おす: あるく　　ボタン: ふりむく",
		HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color(1, 1, 1))
	hud.draw_string(GAME_FONT, Vector2(24, 36), "連続正解 %d" % streak, HORIZONTAL_ALIGNMENT_LEFT, -1, 26,
		Color(0.85, 0.87, 1.0))
	if flash_timer > 0.0:
		var a: float = flash_timer / 0.35
		hud.draw_rect(Rect2(Vector2.ZERO, vp), Color(1.0, 0.9, 0.6, a * 0.28))
	if dark_timer > 0.0:
		var da: float = dark_timer / 0.6
		hud.draw_rect(Rect2(Vector2.ZERO, vp), Color(0.0, 0.0, 0.0, da * 0.85))

# ---------------------------------------------------------------- Web検証用の状態公開

## Control等の rect は「canvas_items + expand」でのびた論理キャンバス座標のままなので、
## 実ウィンドウ(ブラウザの実ピクセル)へ倍率をかけて変換してから公開する。
## そのままだと Playwright 等の実ピクセル座標でのクリック位置とずれてしまう。
func _rect_dict(r: Rect2) -> Dictionary:
	var logical: float = maxf(1.0, get_viewport_rect().size.x)
	var real: float = float(DisplayServer.window_get_size().x)
	var scale: float = real / logical if real > 0.0 else 1.0
	return {
		"x": r.position.x * scale, "y": r.position.y * scale,
		"w": r.size.x * scale, "h": r.size.y * scale,
	}

func _refresh_web_state() -> void:
	if not OS.has_feature("web"):
		return
	var st := {
		"state": ["title", "play", "note", "result"][state],
		"lights": lights_lit,
		"streak": streak,
		"loops": loops_done,
		"result_visible": state == State.RESULT,
		"errors": logger.get_errors(),
	}
	match state:
		State.TITLE:
			if start_btn_ref:
				st["start_btn"] = _rect_dict(start_btn_ref.get_global_rect())
			if note_btn_ref:
				st["note_btn"] = _rect_dict(note_btn_ref.get_global_rect())
		State.PLAY:
			st["turn_btn"] = _rect_dict(_turn_button_rect())
			st["facing"] = facing
		State.NOTE:
			if close_btn_ref:
				st["close_btn"] = _rect_dict(close_btn_ref.get_global_rect())
		State.RESULT:
			if retry_btn_ref:
				st["retry_btn"] = _rect_dict(retry_btn_ref.get_global_rect())
	JavaScriptBridge.eval("window.__anomaly_loop = %s;" % JSON.stringify(st), true)
